// stdlib
#include <cstdlib>
#include <vector>
#include <iostream>

// solver
#include "retarget_solver.hpp"

// stb
#include "stb_image.h"
#define STB_IMAGE_WRITE_IMPLEMENTATION
#include "stb_image_write.h"

using namespace std;
using namespace Eigen;

void retarget_image(const char* input, const char* output, const RetargetArgs& args, const VectorXd& x);

int main(int argc, const char* argv[])
{
	if (argc < 6)
	{
		fprintf(stderr, "<image_path> <saliency_path> <grid_x> <grid_y> <out_image_path>");
		return EXIT_FAILURE;
	}

	const char* image_path = argv[1];
	const char* saliency_path = argv[2];
	const char* out_image_path = argv[5];

	Vector2i grid_resolution;
	try
	{
		grid_resolution.x() = std::stoi(argv[3]);
		grid_resolution.y() = std::stoi(argv[4]);
	}
	catch (const std::exception&)
	{
		fprintf(stderr, "Invalid argument for grid resolution %s %s", argv[3], argv[4]);
		return EXIT_FAILURE;
	}

	RetargetArgs args;
	if (!integrate_saliency(saliency_path, grid_resolution, args.saliency))
	{
		fprintf(stderr, "Failed to integrate saliency");
		return EXIT_FAILURE;
	}

	int pos = 0;
	int neg = 0;
	for (int x = 200; x <= 2000; x += 200)
	{
		for (int y = 200; y <= 2000; y += 200)
		{
			args.grid_resolution = grid_resolution;
			args.src_resolution = Vector2i(1000, 1000);
			args.dst_resolution = Vector2i(x, y);
			args.limits = Vector2d(0.01, 0.01);
			args.laplacian_weight = 0.01;
			MatrixXd cell_dimensions;
			if (!retarget_minimize_asap(args, cell_dimensions))
			{
				cout << "Failed to retarget resolution " << x << " " << y << endl;
				++neg;
				continue;
			}

			std::string out_path = std::string(out_image_path) + std::to_string(x) + "x" + std::to_string(y) + ".png";
			retarget_image(image_path, out_path.c_str(), args, cell_dimensions);
			++pos;
		}
	}

	cout << "Positive: " << pos << " Negative: " << neg << endl;
	return EXIT_SUCCESS;
}

void retarget_image(const char* input, const char* output, const RetargetArgs& args, const VectorXd& x)
{
	int src_w, src_h, src_comp;
	uint8_t* src_img = stbi_load(input, &src_w, &src_h, &src_comp, 3);

	int nrows = args.grid_resolution.x();
	int ncols = args.grid_resolution.y();
	int w = args.dst_resolution.x();
	int h = args.dst_resolution.y();
	std::vector<uint8_t> img(w * h * 3, 255);

	// Drawing retargeted image.
	//for (int _y = 0; _y < args.dst_resolution.y(); ++_y)
	//{
	//	for (int _x = 0; _x < args.dst_resolution.x(); ++_x)
	//	{
	//		// Finding integer part of texture coordinate
	//		int ui = 0;
	//		double uacc = x(ui);
	//		while ((double)_x > uacc)
	//			uacc += x(++ui);

	//		int vi = 0;
	//		double vacc = x(ncols + vi);
	//		while ((double)_y > vacc)
	//			vacc += x(ncols + (++vi));

	//		// Finding fractional part
	//		double px = (ui == 0) ? 0 : uacc - x(ui-1);
	//		double py = (vi == 0) ? 0 : vacc - x(ncols + vi - 1);
	//		double uf = (_x - px) / (uacc - px);
	//		double vf = (_y - py) / (vacc - py);

	//		double u = (1.0 / ncols) * ((double)ui + uf);
	//		double v = (1.0 / nrows) * ((double)ui + vf);

	//		//double u = (double)_x / args.dst_resolution.x();
	//		//double v = (double)_y / args.dst_resolution.y();

	//		assert(u >= -0.01 && u <= 1.01);
	//		assert(v >= -0.01 && v <= 1.01);
	//		u = ::std::max(u, 0.0);
	//		v = ::std::max(v, 0.0);
	//		u = ::std::min(u, 1.0);
	//		v = ::std::min(v, 1.0);

	//		int sx = (int)(u * src_w);
	//		int sy = (int)(v * src_h);
	//		uint8_t color[3];
	//		color[0] = src_img[(sy * src_w + sx) * 3 + 0];
	//		color[1] = src_img[(sy * src_w + sx) * 3 + 1];
	//		color[2] = src_img[(sy * src_w + sx) * 3 + 2];

	//		img[(_y * w + _x) * 3 + 0] = color[0];
	//		img[(_y * w + _x) * 3 + 1] = color[1];
	//		img[(_y * w + _x) * 3 + 2] = color[2];
	//	}
	//}

	// Drawing grid
	double acc = 0;
	for (int i = 0; i < nrows; ++i)
	{
		acc += x(i);
		int axis = ::std::min((int)acc, w - 1);
		for (int j = 0; j < h; ++j)
		{
			img[(j * w + axis) * 3 + 0] = 25;
			img[(j * w + axis) * 3 + 1] = 25;
			img[(j * w + axis) * 3 + 2] = 200;
		}
	}

	acc = 0.0;
	for (int i = 0; i < ncols; ++i)
	{
		acc += x(nrows+i);
		int axis = ::std::min((int)acc, h - 1);
		for (int j = 0; j < w; ++j)
		{
			img[(axis * w + j) * 3 + 0] = 25;
			img[(axis * w + j) * 3 + 1] = 25;
			img[(axis * w + j) * 3 + 2] = 200;
		}
	}

	stbi_write_png(output, w, h, 3, img.data(), w * 3);
}