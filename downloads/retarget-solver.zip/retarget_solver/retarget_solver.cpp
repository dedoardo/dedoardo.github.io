// Header
#include "retarget_solver.hpp"

// stb
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

#include "solver_25x25.hpp"

// stdlib
#include <cstdio>
#include <fstream>
#include <iostream>

// Spare linear solver
#include "Eigen/Dense"
#include "Eigen/IterativeLinearSolvers"

// stb
#include "stb_image_write.h"

using namespace std;
using namespace Eigen;

bool integrate_saliency(const char* filename, const Eigen::Vector2i& grid_resolution, Eigen::MatrixXd& integrated_saliency)
{
	int w, h, n;
	stbi_uc* saliency = stbi_load(filename, &w, &h, &n, 3);
	if (saliency == nullptr)
	{
		fprintf(stderr, "Failed lo load file: %s", filename);
		return false;
	}

	int cx = grid_resolution.x();
	int cy = grid_resolution.y();

	integrated_saliency = MatrixXd(cx, cy);

	const int wf = w / cx;
	const int hf = h / cy;
	for (int y = 0; y < cy; ++y)
	{
		const int start_y = y * hf;
		const int end_y = (y + 1) * hf;
		for (int x = 0; x < cx; ++x)
		{
			double acc = .0;
			int counter = 0;

			const int start_x = x * wf;
			const int end_x = (x + 1) * wf;

			for (int py = start_y; py < end_y; ++py)
			{
				for (int px = start_x; px < end_x; ++px)
				{
					uint8_t* d = saliency + (py * w + px) * 3;
					acc += ::std::max(0.0001, ((double)d[0] + (double)d[1] + (double)d[2]) / (255 * 3));
					++counter;
				}
			}

			integrated_saliency(y, x) = ::std::sqrt(acc / counter);
		}
	}

	stbi_image_free(saliency);

	return true;
}

void export_matrix(const string& filename, const MatrixXd& matrix)
{
#ifdef DEBUG_MATRICES
	std::ofstream fs(std::string("matrix/") + filename + ".txt");
	fs << "Dimension: " << matrix.rows() << "x" << matrix.cols() << std::endl;
	fs << "Max Coeff: " << matrix.maxCoeff() << " Min Coeff: " << matrix.minCoeff() << std::endl;
	fs << matrix;

	std::vector<uint8_t> pixels(matrix.rows() * matrix.cols(), 0);
	MatrixXd matrix_t = matrix.transpose();
	for (int i = 0; i < matrix.size(); ++i)
	{
		if (abs(matrix_t.data()[i]) < 1e-15)
			pixels[i] = 0;
		else
			pixels[i] = 255;
	}

	if (!stbi_write_png((std::string("matrix/") + filename + ".png").c_str(), matrix.cols(), matrix.rows(), 1, pixels.data(), matrix.cols()))
		fprintf(stderr, "Failed to dump matrix to file: %s", filename);
#endif
}

void compute_matrices(const RetargetArgs& args, MatrixXd& K, VectorXd& k)
{
	// We are trying to solve
	//	x'Qx + x'b
	// for As-Similar-As-Possible deformations we have
	// b = 0
	// Q = K'K
	// where K is calculated as in equation (7)
	const int nrows = args.grid_resolution.x();
	const int ncols = args.grid_resolution.y();

	const double min_grid_dim = 0.15;

	const double min_w = ::std::min(min_grid_dim, (double)args.dst_resolution.x() / ncols);
	const double min_h = ::std::min(min_grid_dim, (double)args.dst_resolution.y() / nrows);

	const double s_factor = nrows / (double)args.src_resolution.y();
	const double t_factor = ncols / (double)args.src_resolution.x();

	// ASAP
	//cout << "Computing Q.." << endl;
	const double SALIENCY_SCALE = 1.0;
	K = MatrixXd::Constant(ncols * nrows, ncols + nrows, 0.0);
	for (int i = 0; i < ncols; ++i)
	{
		for (int j = 0; j < nrows; ++j)
		{
			int k = i * ncols + j;

			double s = ::std::max(args.saliency(j, i), 0.05) * SALIENCY_SCALE;
			//double s = 1.0;
			K(k, i) = s_factor * s;
			K(k, j + ncols) = t_factor * -s;
		}
	}
	k = VectorXd::Constant(ncols * nrows, 0);

	// Laplacian Regularization
	int newcountx = ncols - 1;
	int newcounty = nrows - 1;
	int newcount = newcountx + newcounty;
	int startx = K.rows();
	int starty = K.rows() + newcountx;

	MatrixXd Kext = MatrixXd::Zero(K.rows() + newcount, K.cols());
	Kext.block(0, 0, K.rows(), K.cols()) = K;
	K = Kext;

	VectorXd kext = VectorXd::Zero(k.size() + newcount);
	kext.head(k.size()) = k;
	k = kext;

	// Add new terms (b is 0 for the new terms!)
	for (int i = 0; i < newcountx; ++i)
	{
		K(i + startx, i) = args.laplacian_weight;
		K(i + startx, i + 1) = -args.laplacian_weight;
	}
	for (int i = 0; i < newcounty; ++i)
	{
		K(i + starty, i + ncols) = args.laplacian_weight;
		K(i + starty, i + ncols + 1) = -args.laplacian_weight;
	}
}

#if 1
// Equality and Inequality constraints are transformed into penalty functions and we
// find the minimum iteratively following the gradient.
bool retarget_minimize_asap(const RetargetArgs& args, MatrixXd& solution)
{
	MatrixXd K;
	VectorXd k;
	const int nrows = args.grid_resolution.x();
	const int ncols = args.grid_resolution.y();
	compute_matrices(args, K, k);

	// Inputs
	MatrixXd G = (K.transpose() * K);
	VectorXd c = -2.0 * k.transpose() * K;
	int N = ncols + nrows;
	int N_iq = N;
	int N_eq = 2;

	export_matrix("G", G);
	export_matrix("c", c);

	// --- Setting up the matrices ---
	// Equality constraints guarantee the requested target resolution
	MatrixXd A = MatrixXd::Zero(N_eq, N);
	A.block(0, 0, 1, nrows) = RowVectorXd::Ones(nrows);
	A.block(1, nrows, 1, ncols) = RowVectorXd::Ones(ncols);
	VectorXd b(N_eq);
	b(0) = args.dst_resolution.x();
	b(1) = args.dst_resolution.y();

	// Initial solution
	VectorXd X = VectorXd::Zero(N);
	for (int i = 0; i < N; ++i)
		X(i) = -10.0;

	double err = std::numeric_limits<double>::max();
	int iter = 0;
	double max_beta = 1e10;
	double max_gamma = 1e10;
	double beta = 1e10;
	double gamma = 1e10;
	while (err > 1e-12)
	{
		MatrixXd Ai = MatrixXd::Identity(N, N);
		for (int i = 0; i < N; ++i)
		{
			double limit = i <= ncols ? args.limits.x() : args.limits.y();
			if (X(i) >= 0.15)
				Ai(i, i) = 0.0;
		}

		VectorXd bi = VectorXd::Constant(N, 0.15);

		beta = beta * 10;
		gamma = gamma * 10;

#if 0 // Direct solution 
		MatrixXd LH1 = G + beta * (A.transpose() * A) + gamma * Ai;
		VectorXd RH1 = c + beta * A.transpose() * b;
#else // Step
		MatrixXd LH1 = G + beta * (A.transpose() * A) + gamma * (Ai);
		MatrixXd RH1 = c + beta * A.transpose() * b + gamma * Ai.transpose() * bi - (G * X + beta * (A.transpose() * A) * X + gamma * (Ai) * X);
#endif 
		VectorXd res1 = LH1.fullPivLu().solve(RH1);
		X = X + res1;

		// Equality constraint error
		err = res1.norm();

		bool ineq_violated = false;
		for (int i = 0; i < N; ++i)
		{
			if (X(i) < args.limits.x() - 1e-6)
				ineq_violated = true;
		}

		cout << "Iteration " << iter << "\n" <<
			"Error " << err << "\n" <<
			"Inequalities violated " << (ineq_violated? "Yes" : "No") << endl;
		++iter;
	}

	double w = 0;
	double h = 0;
	for (int i = 0; i < N; ++i)
	{
		if (i < ncols) w += X(i);
		else h += X(i);
	}

	solution = X;
	return true;
}
#endif

#if 0
// Inequality constraints are ignored here.
// The quadratic equality constrained problem is solved by solving the KKT system.
bool retarget_minimize_asap(const RetargetArgs& args, MatrixXd& solution)
{
	MatrixXd K;
	VectorXd k;
	const int nrows = args.grid_resolution.x();
	const int ncols = args.grid_resolution.y();
	compute_matrices(args, K, k);

	// Inputs
	MatrixXd G = (K.transpose() * K);
	VectorXd c = -2.0 * k.transpose() * K;
	int N = ncols + nrows;
	int N_iq = N;
	int N_eq = 2;

	export_matrix("G", G);
	export_matrix("c", c);

	// --- Setting up the matrices ---
	// Equality constraints guarantee the requested target resolution
	MatrixXd A = MatrixXd::Zero(N_eq, N);
	A.block(0, 0, 1, nrows) = RowVectorXd::Ones(nrows);
	A.block(1, nrows, 1, ncols) = RowVectorXd::Ones(ncols);
	VectorXd b(N_eq);
	b(0) = args.dst_resolution.x();
	b(1) = args.dst_resolution.y();

	// Initial solution
	// x
	VectorXd X = VectorXd::Zero(N + N_eq);
	//for (int i = 0; i < ncols; ++i)
	//	X(i) = args.dst_resolution.x() / ncols;
	//for (int i = 0; i < nrows; ++i)
	//	X(ncols + i) = args.dst_resolution.y() / nrows;

	// y
	for (int i = 0; i < N_eq; ++i)
		X(N + i) = 1.0;

	MatrixXd LH = MatrixXd::Zero(N + N_eq, N + N_eq);
	LH.block(0, 0, N, N) = G;
	LH.block(N, 0, N_eq, N) = A;
	LH.block(0, N, N, N_eq) = A.transpose();
	export_matrix("LH", LH);

	auto fname = [](const std::string& name, int idx) -> std::string
	{
		return std::string("iter") + std::to_string(idx) + "-" + name;
	};

	double err = std::numeric_limits<double>::max();
	const double err_th = 1e-10;
	int iter = 0;
	while (err > err_th)
	{
		VectorXd x = X.block(0, 0, N, 1);

		VectorXd h = A * x - b;
		VectorXd g = c + G * x;

		VectorXd RH(N + N_eq);
		RH << g, h;
		//RH << c, b;
		export_matrix(fname("RH", iter), RH);

		VectorXd P = LH.fullPivLu().solve(RH);
		VectorXd p = -P.block(0, 0, N, 1);

		X.block(0, 0, N, 1) = x + p;

		double eq_residual = (A*X.block(0, 0, N, 1) - b).norm();
		double step_norm = p.norm();

		cout << "Iteration " << iter;

		err = ::std::max(eq_residual, step_norm);
 		++iter;
	}

	solution = X.block(0, 0, N, 1);
	return solution.minCoeff() >= 0;
}
#endif

// Inequality constrained
#if 0
bool retarget_minimize_asap(const RetargetArgs& args, MatrixXd& solution)
{
	// We are trying to solve
	//	x'Qx + x'b
	// for As-Similar-As-Possible deformations we have
	// b = 0
	// Q = K'K
	// where K is calculated as in equation (7)
	const int nrows = args.grid_resolution.x();
	const int ncols = args.grid_resolution.y();

	const double min_grid_dim = 0.15;

	const double min_w = ::std::min(min_grid_dim, (double)args.dst_resolution.x() / ncols);
	const double min_h = ::std::min(min_grid_dim, (double)args.dst_resolution.y() / nrows);

	// Compensating for aspect ratio
	const double s_factor = nrows / (double)args.src_resolution.y();
	const double t_factor = ncols / (double)args.src_resolution.x();

	cout << "Computing Q.." << endl;
	const double SALIENCY_SCALE = 1.0;
	MatrixXd K = MatrixXd::Constant(ncols * nrows, ncols + nrows, 0.0);
	for (int i = 0; i < ncols; ++i)
	{
		for (int j = 0; j < nrows; ++j)
		{
			int k = i * ncols + j;

			double s = args.saliency(j, i) * SALIENCY_SCALE;
			K(k, i) = s_factor * s;
			K(k, j + ncols) = t_factor * -s;
		}
	}

	// Inputs
	MatrixXd Q = (K.transpose() * K).transpose();
	VectorXd q = VectorXd::Constant(ncols + nrows, 0);
	int N = ncols + nrows;
	int N_iq = N;
	int N_eq = 2;

	export_matrix("q0", Q);
	export_matrix("q1", q);

	// --- Setting up the matrices ---
	// Equality constraints guarantee the requested target resolution
	MatrixXd A = MatrixXd::Zero(N_eq, N);
	A.block(0, 0, 1, nrows) = RowVectorXd::Ones(nrows);
	A.block(1, nrows, 1, ncols) = RowVectorXd::Ones(ncols);
	VectorXd b(N_eq);
	b(0) = args.dst_resolution.x();
	b(1) = args.dst_resolution.y();

	// Inequality constraints prevent cells from disappearing
	MatrixXd G = -MatrixXd::Identity(N_iq, N);
	VectorXd h(N_iq);
	h.block(0, 0, nrows, 1) = VectorXd::Constant(nrows, args.limits.x());
	h.block(nrows, 0, ncols, 1) = VectorXd::Constant(ncols, args.limits.y());

	export_matrix("A", A);
	export_matrix("b", b);
	export_matrix("G", G);
	export_matrix("h", h);

	VectorXd X;

	// x
	X = VectorXd::Zero(3 * N + N_eq);
	
	// s
	for (int i = 0; i < N_iq; ++i)
	{
		X(N + i) = 1.0;
	}

	// z
	for (int i = 0; i < N_iq; ++i)
	{
		X(N + N_iq + i) = 1.0;
	}

	// y
	for (int i = 0; i < N_eq; ++i)
	{
		X(N + N_iq + N_iq + i) = 0.0;
	}

	export_matrix("X0-naive", X);

	MatrixXd S = MatrixXd::Identity(N_iq, N_iq); // s along diagonals
	MatrixXd Z = MatrixXd::Identity(N_iq, N_iq); // z along diagonals

	// Each iteration we apply Netwon's method. The left-hand side of the linear system is 
	// almost entirely constant. Here we initialize the static coefficients (everything except Z and S)
	MatrixXd LH = MatrixXd::Zero(N + N_iq + N_iq + N_eq, N + N_iq + N_iq + N_eq);
	LH.block(0, 0, N, N) = Q;
	LH.block(N + N_iq, 0, N_iq, N) = G;
	LH.block(N + N_iq + N_iq, 0, N_eq, N) = A;
	LH.block(N + N_iq, N, N_iq, N) = MatrixXd::Identity(N_iq, N);
	LH.block(0, N + N_iq, N, N_iq) = G.transpose();
	LH.block(0, N + N_iq + N_iq, N, N_eq) = A.transpose();

	export_matrix("LH_static", LH);

	auto fname = [](const std::string& name, int idx) -> std::string
	{
		return std::string("iter") + std::to_string(idx) + "-" + name;
	};

	auto unpack_solution = [=](const VectorXd& m, VectorXd& x, VectorXd& s, VectorXd& z, VectorXd& y)
	{
		x = m.block(0, 0, N, 1);
		s = m.block(N, 0, N_iq, 1);
		z = m.block(N + N_iq, 0, N_iq, 1);
		y = m.block(N + N_iq + N_iq, 0, N_eq, 1);
	};

	double err = std::numeric_limits<double>::max();
	const double err_tolerance = 1e-7;
	int iter = 0;
	while (err > err_tolerance)
	{
		VectorXd x, s, z, y;
		unpack_solution(X, x, s, z, y);

		export_matrix(fname("X", iter), X);

		Z.diagonal() = z;
		S.diagonal() = s;

		// Computing affine scaling directions 
		LH.block(N, N, N_iq, N_iq) = Z;
		LH.block(N, N + N_iq, N_iq, N_iq) = S;

		export_matrix(fname("LH", iter), LH);

		VectorXd RH_aff(N + N_iq + N_iq + N_eq);
		VectorXd nr1 = -(A.transpose() * y + G.transpose() * z + Q * x + q);
		VectorXd nr2 = -(S * z);
		VectorXd nr3 = -(G*x + s - h);
		VectorXd nr4 = -(A * x - b);
		RH_aff.block(0, 0, N, 1) = nr1;
		RH_aff.block(N, 0, N_iq, 1) = nr2;
		RH_aff.block(N + N_iq, 0, N_iq, 1) = nr3;
		RH_aff.block(N + N_iq + N_iq, 0, N_eq, 1) = nr4;

		export_matrix(fname("RH_aff", iter), RH_aff);

		VectorXd X_aff = LH.ldlt().solve(RH_aff);
 		VectorXd x_aff, s_aff, z_aff, y_aff;
		unpack_solution(X_aff, x_aff, s_aff, z_aff, y_aff);

		export_matrix(fname("X_aff", iter), X_aff);

		double sz = s.transpose() * z;
		double mu = sz / N_iq;
		double min_alpha = 0;
		for (int i = 0; i < N_iq; ++i)
			if (s_aff(i) < min_alpha * s(i))
				min_alpha = s_aff(i) / s(i);
		for (int i = 0; i < N_iq; ++i)
			if (z_aff(i) < min_alpha * z(i))
				min_alpha = z_aff(i) / z(i);

		double alpha;
		if (-1 < min_alpha)
			alpha = 1;
		else
			alpha = -1 / min_alpha;

		double sigma_num = ((s + alpha * s_aff).transpose() * (z + alpha * z_aff));
		double sigma = (sigma_num / sz);
		sigma = sigma * sigma * sigma;

		VectorXd RH = VectorXd::Zero(RH_aff.rows());
		VectorXd aff_sz = s_aff.asDiagonal() * z_aff;
		RH.block(N, 0, N_iq, 1) = (VectorXd::Constant(N_iq, mu * sigma)) - aff_sz;

		export_matrix(fname("RH_step", iter), RH);

		VectorXd X_step = LH.ldlt().solve(RH);
		VectorXd x_step, s_step, z_step, y_step;
		unpack_solution(X_step, x_step, s_step, z_step, y_step);

		export_matrix(fname("X_step", iter), X_step);

		VectorXd dx = x_aff + x_step;
		VectorXd ds = s_aff + s_step;
		VectorXd dz = z_aff + z_step;
		VectorXd dy = y_aff + y_step;

		min_alpha = 0;
		for (int i = 0; i < N_iq; ++i)
			if (ds(i) < min_alpha * s(i))
				min_alpha = ds(i) / s(i);
		for (int i = 0; i < N_iq; ++i)
			if (dz(i) < min_alpha * z(i))
				min_alpha = dz(i) / z(i);

		if (-0.99 < min_alpha)
			alpha = 1;
		else
			alpha = -0.99 / min_alpha;

		VectorXd ALPHA = VectorXd::Constant(X.rows(), alpha);
		VectorXd dX(X.rows());
		dX << dx, ds, dy, dz;

		export_matrix(fname("dX", iter), dX);

		X = X + dX.cwiseProduct(ALPHA);

		// Duality gap error (distance between primal and dual solution)
		double duality_gap = s.dot(z);

		// Equality residual
		double eq_residual = (-A * x + b).norm();
		double ineq_residual = (-G * x - s + h).norm();
		
		double err = ::std::max(duality_gap, ::std::max(eq_residual, ineq_residual));

		// Inequality residual
		cout << "---" << endl;
		cout << "Iteration " << iter << " Error " << err << endl;
		cout << "Step (alpha) " << alpha << endl;
		cout << "Duality Gap " << duality_gap << endl;
		cout << "Equality residual |-Ax + b|" << eq_residual << endl;
		cout << "Inequality residual |-Gx - s + h| " << ineq_residual << endl;
		cout << endl;
		++iter;
	}

	return true;
}
#endif