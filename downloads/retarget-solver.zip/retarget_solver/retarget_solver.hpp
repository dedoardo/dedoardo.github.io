#pragma once

// Eigen
#include "Eigen/Core"

struct RetargetArgs
{
	Eigen::Vector2i grid_resolution; 
	Eigen::MatrixXd saliency; // discretized saliency
	Eigen::Vector2d limits; // Minimum cell size
	Eigen::Vector2i src_resolution; // Original resolution
	Eigen::Vector2i dst_resolution; // Target resolution
	double laplacian_weight;
};

bool integrate_saliency(const char* filename, const Eigen::Vector2i& grid_resolution, Eigen::MatrixXd& saliency);
bool retarget_minimize_asap(const RetargetArgs& args, Eigen::MatrixXd& cell_dimensions);