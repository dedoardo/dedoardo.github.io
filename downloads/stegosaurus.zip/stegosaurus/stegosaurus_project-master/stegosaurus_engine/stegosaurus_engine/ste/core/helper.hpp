/*===========================================================================
|> License
|	The MIT License (MIT)
|
|	Copyright (c) 2013 Edoardo Alberto Dominici
|
|	Permission is hereby granted, free of charge, to any person obtaining a copy
|	of this software and associated documentation files (the "Software"), to deal
|	in the Software without restriction, including without limitation the rights
|	to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
|	copies of the Software, and to permit persons to whom the Software is
|	furnished to do so, subject to the following conditions:
|
|	The above copyright notice and this permission notice shall be included in
|	all copies or substantial portions of the Software.
|
|	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
|	IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
|	FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
|	AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
|	LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
|	OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
|	THE SOFTWARE.
=============================================================================*/

#ifndef HELPER_HPP_INCLUDED_
#define HELPER_HPP_INCLUDED_

#include "../common.hpp"

namespace ste
{
	namespace core
	{
		/*===========================================================================*/
		/// \brief Terminates the program displaying the error
		///		Used to terminate the application in case of fatal error. It presents the user with a simple
		///     MessageBox indicating the source of the error.
		/// \param _file Indicates the name of the file the error has originated from
		/// \param _line Indicates the line of the file the error has originated from
		/// \param _function Indicates the name of the function the error has originated from
		/// \param _message Custom error message to provide additional informations
		/*===========================================================================*/
		inline void graceful_termination(const std::string& _file,
			const std::string& _line,
			const std::string& _function,
			const std::string& _message);
	}
}

inline void ste::core::graceful_termination(const std::string& _file,
	const std::string& _line,
	const std::string& _function,
	const std::string& _message)
{
	std::stringstream ss;
	ss << "Program has been terminated : \n";
	ss << "File : " << _file << std::endl;
	ss << "Line : " << _line << std::endl;
	ss << "Function : " << _function << std::endl;
	ss << "Message : " << _message << std::endl;

	std::string msg = ss.str();
	std::wstring wmsg(msg.begin(), msg.end());

	MessageBox(NULL,
		wmsg.c_str(),
		L"Program terminated",
		MB_OK);


	exit(EXIT_FAILURE);
}

#endif // HELPER_HPP_INCLUDED_