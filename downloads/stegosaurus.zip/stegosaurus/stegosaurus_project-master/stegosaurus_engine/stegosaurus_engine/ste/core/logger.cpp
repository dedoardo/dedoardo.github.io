/*===========================================================================
|> License
|	The MIT License (MIT)
|
|	Copyright (c) 2013 Edoardo Alberto Dominici
|
|	Permission is hereby granted, free of charge, to any person obtaining a copy
|	of this software and associated documentation files (the "Software"), to deal
|	in the Software without restriction, including without limitation the rights
|	to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
|	copies of the Software, and to permit persons to whom the Software is
|	furnished to do so, subject to the following conditions:
|
|	The above copyright notice and this permission notice shall be included in
|	all copies or substantial portions of the Software.
|
|	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
|	IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
|	FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
|	AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
|	LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
|	OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
|	THE SOFTWARE.
=============================================================================*/

#include "logger.hpp"
#include <io.h>
#include <fcntl.h>

namespace ste
{
	namespace core
	{
		Logger::Logger() :
#ifdef STE_DEBUG 
			m_logging_level{ LOGGING_LEVEL::LOGGING_LEVEL_DEBUG }
#else
			m_logging_level{LOGGING_LEVEL::LOGGING_LEVEL_RELEASE}
#endif
		{
			std::ofstream stream("log_001.html", std::ios_base::app);
			stream << "New session started with mode : ";
			stream << LOGGING_LEVEL_STRING[m_logging_level] << std::endl;

			stream.close();
		}

		Logger::~Logger()
		{

		}

		void Logger::_log(const std::string& _file,
			const std::string& _line,
			const std::string& _function,
			const std::string& _msg_to_log)
		{
			if (m_logging_level == LOGGING_LEVEL::LOGGING_LEVEL_RELEASE)
				return;

			std::stringstream ss;
			ss << "[TIMESTAMP]";
			ss << "[" << _file << " : " << _function << " : " << _line << "]";
			ss << _msg_to_log;
			std::string formatted_msg = ss.str();

			std::ofstream stream("log_001.html", std::ios_base::app);
			stream << formatted_msg;

			stream.close();
		}
	}
}