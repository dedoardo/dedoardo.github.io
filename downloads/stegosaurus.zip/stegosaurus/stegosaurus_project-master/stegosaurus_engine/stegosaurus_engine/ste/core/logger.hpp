#ifndef LOGGER_HPP_INCLUDED_
#define LOGGER_HPP_INCLUDED_

#include "../common.hpp"

namespace ste
{
	namespace core
	{
		enum LOGGING_LEVEL
		{
			LOGGING_LEVEL_RELEASE = 0x00, // Outputs to console
			LOGGING_LEVEL_TEST = 0x01, // Outputs to file only
			LOGGING_LEVEL_DEBUG = 0x02, // Outputs to console and file
		};

		const std::string LOGGING_LEVEL_STRING[3] =
		{
			"LOGGING LEVEL RELEASE",
			"LOGGING_LEVEL_TEST",
			"LOGGING_LEVEL_DEBUG"
		};

		class Logger
		{
		public : 
			~Logger();

			static Logger* get_instance()
			{
				static Logger logger;
				return &logger;
			}

			static void log(const std::string& _file,
				const std::string& _line,
				const std::string& _function,
				const std::string& _msg_to_log) {
				Logger::get_instance()->_log(_file, _line, _function, _msg_to_log);
			}

			static inline void set_output_level(LOGGING_LEVEL _logging_level) {
				Logger::get_instance()->m_logging_level = _logging_level;
			}
			static inline LOGGING_LEVEL get_output_level() { return Logger::get_instance()->m_logging_level; }

		private : 
			void _log(const std::string& _file,
				const std::string& _line,
				const std::string& _function,
				const std::string& _msg_to_log);

			Logger();

			Logger(const Logger& device) = delete;
			Logger& operator=(const Logger& device) = delete;

			LOGGING_LEVEL m_logging_level;
		};
	}
}

#endif // LOGGER_HPP_INCLUDED_