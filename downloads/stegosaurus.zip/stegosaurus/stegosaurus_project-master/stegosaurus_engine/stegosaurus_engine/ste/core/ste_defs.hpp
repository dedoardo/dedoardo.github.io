/*===========================================================================
|> License
|	The MIT License (MIT)
|
|	Copyright (c) 2013 Edoardo Alberto Dominici
|
|	Permission is hereby granted, free of charge, to any person obtaining a copy
|	of this software and associated documentation files (the "Software"), to deal
|	in the Software without restriction, including without limitation the rights
|	to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
|	copies of the Software, and to permit persons to whom the Software is
|	furnished to do so, subject to the following conditions:
|
|	The above copyright notice and this permission notice shall be included in
|	all copies or substantial portions of the Software.
|
|	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
|	IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
|	FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
|	AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
|	LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
|	OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
|	THE SOFTWARE.
=============================================================================*/

#ifndef STE_DEFS_HPP_INCLUDED_
#define STE_DEFS_HPP_INCLUDED_

/*===========================================================================
| > Includes
=============================================================================*/
#include "helper.hpp"
#include "logger.hpp"

/*===========================================================================
| > Version numbers & framework infos
=============================================================================*/
#define STE_VERSION_MAJOR 0
#define STE_VERSION_MINOR 1
#define STE_BUILD 0001
#define STE_VERSION_TO_STRING L"Stegosaurus Engine : Kimmeridgian"

/*===========================================================================
| > Compiler support
=============================================================================*/
#if !defined(__cplusplus)
	#error C++ Compiler is needed for Stegosaurus Engine to be compiled
#endif
#if !defined(_MSC_VER)
	#error The compiler in use is not supported. Modify the macros and remove \
	this line if you want the library to compile
#endif 

/*===========================================================================
| > Special calling conventions this calling 
=============================================================================*/
#if _MSC_VER >= 1800
#define STE_REGISTER_CCALL __vectorcall
#else
#define STE_REGISTER_CCALL __fastcall
#endif

/*===========================================================================
| > Dinamic Link Library function exports
=============================================================================*/
#ifdef STE_STATIC
	#define STE_EXPORT __declspec(dllexport)
	// #define STE_IMPORT __declspec(dllimport) //! < Required to import variables from library
#else
	#define STE_EXPORT
#endif // STE_STATIC

/*===========================================================================
| > Wrapped defines for commonly used macros 
=============================================================================*/
#if defined(_DEBUG) || defined(DEBUG)
	#define STE_DEBUG
#else
	#define STE_RELEASE
#endif

/*===========================================================================
| > Ensure that assert is used only in debug mode ( STE_DEBUG )
=============================================================================*/
#if defined(STE_DEBUG)
	#define VALID_ASSERT(x) assert(x)
#else
	#ifndef NDEBUG
		#define NDEBUG
	#endif // NDEBUG
	
	#define VALID_ASSERT(x)
#endif 

/*===========================================================================
| > STB_IMAGE library defines
=============================================================================*/
#if defined(STE_DEBUG)
	#define STBI_FAILURE_USERMSG
#else
	#define STBI_NO_FAILURE_STRINGS
#endif 

/*===========================================================================
| > Shorthand macros for functions / methods with HRESULT as return type/
| > Provides multiple macros for different purposes
=============================================================================*/
#define HAS_FAILED(x) ((HRESULT)(x) < 0)
#define RETURN_FALSE_IF_FAILED(x) if (HAS_FAILED(x)) return false;
#define LOG(msg) ste::core::Logger::log(__FILE__,std::to_string(__LINE__),__FUNCTION__,(msg))
#define LOG_AND_RETURN(msg) LOG(msg); return false;
#define LOG_IF_FAILED(x,msg) if (HAS_FAILED(x)) LOG ((msg))
#define LOG_AND_RETURN_IF_FAILED(x,msg) if(HAS_FAILED(x)) {LOG((msg)); return false; }

/*===========================================================================
| > Safely releases a COM object if it's  different from nullptr
=============================================================================*/
#define SAFE_RELEASE_COM(x) { \
	if ((x) != nullptr) \
	{ \
		(x)->Release(); \
		(x) = nullptr; \
	} \
} \

/*===========================================================================
| > Graceful termination macro
=============================================================================*/
#define TERMINATE_GRACEFUL(msg) ste::core::graceful_termination(__FILE__,std::to_string(__LINE__),__FUNCTION__,(msg))

#endif // STE_DEFS_HPP_INCLUDED_