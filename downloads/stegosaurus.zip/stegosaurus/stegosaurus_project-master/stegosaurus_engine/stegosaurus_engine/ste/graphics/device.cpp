/*===========================================================================
|> License
|	The MIT License (MIT)
|
|	Copyright (c) 2013 Edoardo Alberto Dominici
|
|	Permission is hereby granted, free of charge, to any person obtaining a copy
|	of this software and associated documentation files (the "Software"), to deal
|	in the Software without restriction, including without limitation the rights
|	to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
|	copies of the Software, and to permit persons to whom the Software is
|	furnished to do so, subject to the following conditions:
|
|	The above copyright notice and this permission notice shall be included in
|	all copies or substantial portions of the Software.
|
|	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
|	IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
|	FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
|	AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
|	LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
|	OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
|	THE SOFTWARE.
=============================================================================*/

/*===========================================================================
| > Includes
=============================================================================*/
#include "device.hpp"
#include "common_effects.hpp"

ste::graphics::Effect* ste::graphics::render_texture_effect = new ste::graphics::Effect();
ste::graphics::Effect* ste::graphics::render_geometry_effect = new ste::graphics::Effect();
ste::graphics::Effect* ste::graphics::render_sprite_effect = new ste::graphics::Effect();

namespace ste
{
	namespace graphics
	{
		Device::Device()
		{
			m_multisample_sample_count = STE_MAX_MULTISAMPLE_COUNT;

			VALID_ASSERT(m_internal_device == nullptr);
			VALID_ASSERT(m_internal_context == nullptr);
			VALID_ASSERT(m_adapter_in_use == nullptr);
			VALID_ASSERT(m_creator_factory == nullptr);

			D3D_FEATURE_LEVEL fl = D3D_FEATURE_LEVEL_11_0;

			UINT flags{};

#ifdef STE_DEBUG
			flags |= D3D11_CREATE_DEVICE_DEBUG;
#endif

			if (HAS_FAILED(D3D11CreateDevice(NULL,
				D3D_DRIVER_TYPE_HARDWARE,
				NULL,
				flags,
				&fl,
				1,
				D3D11_SDK_VERSION,
				&m_internal_device,
				&m_max_supported_feature_level,
				&m_internal_context)))
			{
				m_internal_device = nullptr;
				m_internal_context = nullptr;
			}

			// checking if required feature level is supported, otherwise releasing the device
			if (m_max_supported_feature_level < STE_REQUIRED_D3D_FEATURE_LEVEL)
			{
				SAFE_RELEASE_COM(m_internal_context);
				m_internal_context = nullptr;

				SAFE_RELEASE_COM(m_internal_device);
				m_internal_device = nullptr;
			}
			else
			{
				m_active_feature_level = m_max_supported_feature_level;
			}

			HRESULT hr = m_internal_device->CheckMultisampleQualityLevels(
				STE_DEFAULT_BUFFER_FORMAT,
				m_multisample_sample_count,
				&m_multisample_quality_levels);

			if (HAS_FAILED(m_internal_device->CheckMultisampleQualityLevels(
				STE_DEFAULT_BUFFER_FORMAT,
				m_multisample_sample_count,
				&m_multisample_quality_levels)))
			{
				m_multisample_quality_levels = 0;
				return;
			}
			
			// No 8xMSAA support for the current format
			if (m_multisample_quality_levels == 0)
			{
				m_multisample_sample_count = 4;
				if (HAS_FAILED(m_internal_device->CheckMultisampleQualityLevels(
					STE_DEFAULT_BUFFER_FORMAT,
					4,
					&m_multisample_quality_levels)))
				{
					m_multisample_quality_levels = 0;
					return;
				}
				
				// Not even 4xMSAA.. there is something wrong.. not returning error.. disabling MSAA
				if (m_multisample_quality_levels == 0)
				{
					m_multisample_sample_count = 1;
				}
			}

			IDXGIDevice* dxgi_device = nullptr;
			if (HAS_FAILED(m_internal_device->QueryInterface(__uuidof(IDXGIDevice),reinterpret_cast<void**>(&dxgi_device))))
				return;
			
			if (HAS_FAILED(dxgi_device->GetParent(__uuidof(IDXGIAdapter), reinterpret_cast<void**>(&m_adapter_in_use))))
			{
				Device::m_adapter_in_use = nullptr;
				return;
			}
			if (HAS_FAILED(m_adapter_in_use->GetParent(__uuidof(IDXGIFactory), reinterpret_cast<void**>(&m_creator_factory))))
			{
				m_creator_factory = nullptr;
				return;
			}

			SAFE_RELEASE_COM(dxgi_device);

			if (!_load_common_effects())
			{
				return; // TODO Logging stuff to add
			}
		}

		Device::~Device()
		{
			SAFE_RELEASE_COM(m_internal_context);
			Device::m_internal_context = nullptr;

			SAFE_RELEASE_COM(m_internal_device);
			Device::m_internal_device = nullptr;

			SAFE_RELEASE_COM(m_adapter_in_use);
			Device::m_adapter_in_use = nullptr;

			SAFE_RELEASE_COM(m_creator_factory);
			Device::m_creator_factory = nullptr;

			_unload_common_effects();
		}

		bool Device::_load_common_effects()
		{
			if (!render_texture_effect->compile_and_load_from_file(L"shaders/render_texture_effect.fx"))
				return false;

			if (!render_geometry_effect->compile_and_load_from_file(L"shaders/render_geometry_effect.fx"))
				return false;

			if (!render_sprite_effect->compile_and_load_from_file(L"shaders/render_sprite_effect.fx"))
				return false;
	
			return true;
		}

		void Device::_unload_common_effects()
		{
			delete render_sprite_effect;
			render_sprite_effect = nullptr;

			delete render_geometry_effect;
			render_geometry_effect = nullptr;

			delete render_texture_effect;
			render_texture_effect = nullptr;
		}
	}
}