/*===========================================================================
|> License
|	The MIT License (MIT)
|
|	Copyright (c) 2013 Edoardo Alberto Dominici
|
|	Permission is hereby granted, free of charge, to any person obtaining a copy
|	of this software and associated documentation files (the "Software"), to deal
|	in the Software without restriction, including without limitation the rights
|	to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
|	copies of the Software, and to permit persons to whom the Software is
|	furnished to do so, subject to the following conditions:
|
|	The above copyright notice and this permission notice shall be included in
|	all copies or substantial portions of the Software.
|
|	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
|	IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
|	FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
|	AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
|	LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
|	OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
|	THE SOFTWARE.
=============================================================================*/
#ifndef DEVICE_HPP_INCLUDED_
#define DEVICE_HPP_INCLUDED_

/*===========================================================================
| > Includes
=============================================================================*/
#include "../common.hpp"

/*===========================================================================
| > Using declarations
=============================================================================*/
using ste::core::uint_32;

namespace ste
{
	namespace graphics
	{
		/*===========================================================================*/
		/// \brief Simple wrapper (singleton) for a ID3D11Device and more device-related functionalities. 
		///		   This class cannot be inherited.
		/*===========================================================================*/
		class Device final
		{
		public :
			/*===========================================================================*/
			/// \brief Releases all the device-associated COM objects
			/*===========================================================================*/
			~Device();

			/*===========================================================================*/
			/// \brief Retrieves a pointer to a Device instance and creates it if it's the first time
			///		   it's called
			/*===========================================================================*/
			static Device* get_instance()
			{
				static Device device;
				return &device;
			}

			/*===========================================================================*/
			/// \brief Retrieves the internal ID3DDevice*
			/*===========================================================================*/
			static inline ID3D11Device* get_d3d_device() { return Device::get_instance()->m_internal_device; }
			
			/*===========================================================================*/
			/// \brief Retrieves the context associated to the Device
			/*===========================================================================*/
			static inline ID3D11DeviceContext* get_d3d_context() { return Device::get_instance()->m_internal_context; }
			
			/*===========================================================================*/
			/// \brief Retrieves the active feature level. It's higher or equal to STE_REQUIRED_D3D_FEATURE_LEVEL
			/*===========================================================================*/
			static inline D3D_FEATURE_LEVEL get_d3d_feature_level() { return Device::get_instance()->m_active_feature_level; }

			/*===========================================================================*/
			/// \brief Retrieves the adapter associated to the Device
			/*===========================================================================*/
			static inline IDXGIAdapter* get_dxgi_adapter() { return Device::get_instance()->m_adapter_in_use; }
			
			/*===========================================================================*/
			/// \brief Retrieves the factory that was used to create the device. It should be used to create the swap chain
			/*===========================================================================*/
			static inline IDXGIFactory* get_dxgi_factory() { return Device::get_instance()->m_creator_factory; }

			/*===========================================================================*/
			/// \brief Retrieves the maximum supported quality level associated to the sample count
			/*===========================================================================*/
			static inline uint_32 get_multisample_quality_levels() { return Device::get_instance()->m_multisample_quality_levels; }
			
			/*===========================================================================*/
			/// \brief Retrieves the maximum supported number of sample counts for multisampling. It's less or equal than STE_MAX_MULTISAMPLE_COUNT
			/*===========================================================================*/
			static inline uint_32 get_multisample_sample_count() { return Device::get_instance()->m_multisample_sample_count; }

		private : 
			Device();

			Device(const Device& device) = delete;
			Device& operator=(const Device& device) = delete;

			bool _load_common_effects();

			void _unload_common_effects();

			ID3D11Device* m_internal_device;
			ID3D11DeviceContext* m_internal_context;
			D3D_FEATURE_LEVEL m_active_feature_level;
			D3D_FEATURE_LEVEL m_max_supported_feature_level;

			IDXGIAdapter* m_adapter_in_use;
			IDXGIFactory* m_creator_factory;

			uint_32 m_multisample_quality_levels;
			uint_32 m_multisample_sample_count;
		};
	}
}

#endif // DEVICE_HPP_INCLUDED_