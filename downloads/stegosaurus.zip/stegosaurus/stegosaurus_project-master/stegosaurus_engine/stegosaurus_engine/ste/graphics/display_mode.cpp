#include "display_mode.hpp"
#include "../common.hpp"

using ste::core::int_32;

namespace ste
{
	namespace graphics
	{
		DisplayMode::DisplayMode() :
			m_width{ 0 },
			m_height{ 0 },
			m_color_resolution{ 0 },
			m_display_frequency{ 0 }
		{

		}

		bool DisplayMode::set_display_mode(uint_32 _width,uint_32 _height)
		{
			DEVMODE dm;
			dm.dmSize = sizeof(dm);
			int_32 count{ 0 };
			while (EnumDisplaySettings(NULL, count, &dm))
			{
				if (dm.dmPelsWidth == _width && dm.dmPelsHeight == _height)
				{
					m_width = dm.dmPelsWidth;
					m_height = dm.dmPelsHeight;
					m_color_resolution = dm.dmBitsPerPel;
					m_display_frequency = dm.dmDisplayFrequency;
					return true;
				}
				++count;
			}

			return false;
		}

		bool DisplayMode::set_nearest_display_mode(uint_32 _width, uint_32 _height)
		{
			if (set_display_mode(_width, _height))
				return true;

			int_32 width_delta{ 0 };
			int_32 height_delta{ 0 };
			int_32 best_color_resolution{ 0 };
			int_32 display_count{ 0 };
			int_32 best_index{ 0 };
			DEVMODE dm;
			dm.dmSize = (sizeof(dm));
			
			if (!EnumDisplaySettings(NULL, display_count, &dm))
				return false;
			++display_count;

			width_delta = std::abs(static_cast<int_32>(_width) - static_cast<int_32>(dm.dmPelsWidth));
			height_delta = std::abs(static_cast<int_32>(_height) - static_cast<int_32>(dm.dmPelsHeight));
			best_color_resolution = dm.dmBitsPerPel;

			while (EnumDisplaySettings(NULL, display_count, &dm))
			{
				int_32 temp_width_delta = std::abs(static_cast<int_32>(_width)-static_cast<int_32>(dm.dmPelsWidth));
				int_32 temp_height_delta = std::abs(static_cast<int_32>(_height)-static_cast<int_32>(dm.dmPelsHeight));
				if (temp_width_delta == width_delta && temp_height_delta == height_delta)
				{
					if (dm.dmBitsPerPel > best_color_resolution)
						best_index = display_count;
				}
				else if (temp_width_delta < width_delta && temp_height_delta < height_delta)
				{
					best_index = display_count;
					width_delta = temp_width_delta;
					height_delta = temp_height_delta;
					best_color_resolution = dm.dmBitsPerPel;
				}
				++display_count;
			}

			if (!EnumDisplaySettings(NULL, best_index, &dm))
				return false;
			m_width = dm.dmPelsWidth;
			m_height = dm.dmPelsHeight;
			m_color_resolution = dm.dmBitsPerPel;
			m_display_frequency = dm.dmDisplayFrequency;

			return true;
		}
	}
}