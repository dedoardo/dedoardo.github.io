/*===========================================================================
|> License
|	The MIT License (MIT)
|
|	Copyright (c) 2013 Edoardo Alberto Dominici
|
|	Permission is hereby granted, free of charge, to any person obtaining a copy
|	of this software and associated documentation files (the "Software"), to deal
|	in the Software without restriction, including without limitation the rights
|	to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
|	copies of the Software, and to permit persons to whom the Software is
|	furnished to do so, subject to the following conditions:
|
|	The above copyright notice and this permission notice shall be included in
|	all copies or substantial portions of the Software.
|
|	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
|	IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
|	FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
|	AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
|	LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
|	OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
|	THE SOFTWARE.
=============================================================================*/

#ifndef DISPLAY_MODE_HPP_INCLUDED_
#define DISPLAY_MODE_HPP_INCLUDED_

/*===========================================================================
| > Includes
=============================================================================*/
#include "../core/types.hpp"

/*===========================================================================
| > Using declarations
=============================================================================*/
using ste::core::uint_32;

namespace ste
{
	namespace graphics
	{
		/*===========================================================================*/
		/// \brief Window display mode necessary to switch to fullscreen mode
		/*===========================================================================*/
		class DisplayMode
		{
		public:
			/*===========================================================================*/
			/// \brief Initializes all the members to zero
			/*===========================================================================*/
			DisplayMode();

			/*===========================================================================*/
			/// \brief Sets the display mode that corresponds to the parameters if it exists
			///
			/// \return True if display mode was found and set. False otherwise
			/*===========================================================================*/
			bool set_display_mode(uint_32 _width,uint_32 _height);

			//! Tries to find the nearest display mode to the specified one if. It returns true if 
			//! it couldn't be found. true otherwise
			/*===========================================================================*/
			/// \brief Tries to find the nearest display mode to the specified one. 
			///
			/// \return True if display mode was found and set. False otherwise
			/*===========================================================================*/
			bool set_nearest_display_mode(uint_32 _width, uint_32 _height);

			/*===========================================================================*/
			/// \brief Retrieves the width associated with the display mode
			/*===========================================================================*/
			inline uint_32 get_width()const { return m_width; }

			/*===========================================================================*/
			/// \brief Retrieves the height associated with the display mode
			/*===========================================================================*/
			inline uint_32 get_height()const { return m_height; }

			/*===========================================================================*/
			/// \brief Retrieves the color resolution associated with the display mode
			/*===========================================================================*/
			inline uint_32 get_color_resolution()const { return m_color_resolution; }

			/*===========================================================================*/
			/// \brief Retrieves the vertical refresh rate associated with the display mode
			/*===========================================================================*/
			inline uint_32 get_display_frequency()const { return m_display_frequency; }

		private:
			uint_32 m_width;
			uint_32 m_height;
			uint_32 m_color_resolution;
			uint_32 m_display_frequency;
		};
	}
}

#endif // DISPLAY_MODE_HPP_INCLUDED_