/*===========================================================================
|> License
|	The MIT License (MIT)
|
|	Copyright (c) 2013 Edoardo Alberto Dominici
|
|	Permission is hereby granted, free of charge, to any person obtaining a copy
|	of this software and associated documentation files (the "Software"), to deal
|	in the Software without restriction, including without limitation the rights
|	to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
|	copies of the Software, and to permit persons to whom the Software is
|	furnished to do so, subject to the following conditions:
|
|	The above copyright notice and this permission notice shall be included in
|	all copies or substantial portions of the Software.
|
|	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
|	IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
|	FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
|	AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
|	LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
|	OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
|	THE SOFTWARE.
=============================================================================*/

/*===========================================================================
| > Includes
=============================================================================*/
#include "effect.hpp"
#include "device.hpp"
#include <D3Dcompiler.h>#

namespace ste
{
	namespace graphics
	{
		Effect::Effect() :
			m_internal_fx{ nullptr },
			m_raw_data{ nullptr }
		{
			
		}

		Effect::~Effect()
		{
			SAFE_RELEASE_COM(m_internal_fx);
			m_internal_fx = nullptr;

			SAFE_RELEASE_COM(m_raw_data);
			m_raw_data = nullptr;
		}

		bool Effect::compile_and_load_from_file(const std::wstring& _filename)
		{
			UINT compile_flags{ 0 };
			#ifdef STE_DEBUG
			compile_flags |= D3DCOMPILE_DEBUG;
			#else
			compile_flags |= D3DCOMPILE_OPTIMIZATION_LEVEL3;
#endif

			ID3D10Blob* compilation_errors{ nullptr };

			HRESULT hr = D3DX11CompileFromFile(
				_filename.c_str(),
				NULL,
				NULL,
				NULL,
				"fx_5_0",
				compile_flags,
				0, NULL,
				&m_raw_data,
				&compilation_errors,
				NULL);
			if (hr == D3D11_ERROR_FILE_NOT_FOUND)
				return false;
			{
				if (compilation_errors != NULL)
				{
					MessageBoxA(NULL,
						(char*)compilation_errors->GetBufferPointer(),
						"error",
						MB_OK);
				}
			}

			return load_from_memory(static_cast<char*>(m_raw_data->GetBufferPointer()),m_raw_data->GetBufferSize());
		}

		bool Effect::load_from_file(const std::wstring& _filename)
		{
			if (_filename.length() == 0)
				return false;

			std::ifstream stream(_filename, std::ios_base::binary);
			stream.seekg(0, std::ios_base::end);
			size_t size = stream.tellg();
			stream.seekg(0, std::ios_base::beg);
			char* buffer = new char[size];

			stream.read(buffer, size);
			stream.close();

			RETURN_FALSE_IF_FAILED(D3DX11CreateEffectFromMemory(
				reinterpret_cast<void*>(buffer),
				size,
				0,
				Device::get_d3d_device(),
				&m_internal_fx));
			delete[] buffer;
		}

		bool Effect::load_from_memory(char* _data,size_t _size)
		{
			if (_data == nullptr)
				return false;

			RETURN_FALSE_IF_FAILED(D3DX11CreateEffectFromMemory(
				reinterpret_cast<void*>(_data),
				_size,
				0,
				Device::get_d3d_device(),
				&m_internal_fx));
			return true;
		}
	}
}