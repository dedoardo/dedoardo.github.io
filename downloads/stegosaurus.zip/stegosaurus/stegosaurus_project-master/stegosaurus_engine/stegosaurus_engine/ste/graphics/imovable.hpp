/*===========================================================================
|> License
|	The MIT License (MIT)
|
|	Copyright (c) 2013 Edoardo Alberto Dominici
|
|	Permission is hereby granted, free of charge, to any person obtaining a copy
|	of this software and associated documentation files (the "Software"), to deal
|	in the Software without restriction, including without limitation the rights
|	to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
|	copies of the Software, and to permit persons to whom the Software is
|	furnished to do so, subject to the following conditions:
|
|	The above copyright notice and this permission notice shall be included in
|	all copies or substantial portions of the Software.
|
|	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
|	IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
|	FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
|	AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
|	LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
|	OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
|	THE SOFTWARE.
=============================================================================*/

#ifndef IMOVABLE_HPP_INCLUDED_
#define IMOVABLE_HPP_INCLUDED_

#include "../common.hpp"

namespace ste
{
	namespace graphics
	{
		class IMovable
		{
		public : 
			friend class Renderer;
			IMovable() :
				m_position{ 0.0f, 0.0f }
			{
			}

			inline void move(FXMVECTOR _offset)
			{
				XMVECTOR to_add = XMLoadFloat2(&m_position);
				to_add = XMVectorAdd(to_add, _offset);
				XMStoreFloat2(&m_position, to_add);
			}

			inline void set_position(FXMVECTOR _new_position)
			{
				XMStoreFloat2(&m_position, _new_position);
			}

			inline XMVECTOR get_position()
			{
				return XMLoadFloat2(&m_position);
			}

		protected :
			friend class Renderer;

			XMFLOAT2		m_position;
		};
	}
}

#endif // IMOVABLE_HPP_INCLUDED_