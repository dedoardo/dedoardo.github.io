#include "renderer.hpp"
#include "window.hpp"
#include "device.hpp"
#include "sprite.hpp"
#include "texture.hpp"
#include "effect.hpp"
#include "common_effects.hpp"

using ste::core::uint_32;

namespace ste
{
	namespace graphics
	{
		XMVECTORF32 magenta = { 1.0f, 0.0f, 1.0f, 1.0f };

		Renderer::Renderer() :
			m_swap_chain{ nullptr },
			m_render_target_view{ nullptr },
		//	m_depth_stencil_view{ nullptr },
			//m_depth_stencil_buffer{ nullptr },
			m_viewport{},
			m_attached_window{ nullptr }
		{

		}

		Renderer::~Renderer()
		{
			detach_current_window();
		}

		bool Renderer::attach_window(Window* _window)
		{
			VALID_ASSERT(Device::get_d3d_device() != nullptr);

			if (_window == nullptr)
				return false;
			m_attached_window = _window;

			DXGI_SWAP_CHAIN_DESC scd;
			scd.BufferDesc.Width = _window->get_current_width();
			scd.BufferDesc.Height = _window->get_current_height();
			scd.BufferDesc.RefreshRate.Numerator = 60;
			scd.BufferDesc.RefreshRate.Denominator = 1;
			scd.BufferDesc.Format = STE_DEFAULT_BUFFER_FORMAT;
			scd.BufferDesc.ScanlineOrdering = DXGI_MODE_SCANLINE_ORDER_UNSPECIFIED;
			scd.BufferDesc.Scaling = DXGI_MODE_SCALING_UNSPECIFIED;
					
			scd.SampleDesc.Count = Device::get_multisample_sample_count();
			scd.SampleDesc.Quality = Device::get_multisample_quality_levels() - 1;
			
			scd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
			scd.BufferCount = 1;
			scd.OutputWindow = m_attached_window->get_wnd_handle();
			scd.Windowed = !m_attached_window->is_fullscreen();
			scd.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;
			scd.Flags = 0;

			ID3D11Device* d = Device::get_d3d_device();

			if (HAS_FAILED((Device::get_dxgi_factory()->CreateSwapChain(Device::get_d3d_device(), &scd, &m_swap_chain))))
				return false;
			
			return _resize_buffers();
		}

		void Renderer::detach_current_window()
		{
			SAFE_RELEASE_COM(m_render_target_view);
			m_render_target_view = nullptr;

			//SAFE_RELEASE_COM(m_depth_stencil_view);
		//	m_render_target_view = nullptr;

			SAFE_RELEASE_COM(m_swap_chain);
			m_render_target_view = nullptr;

			//SAFE_RELEASE_COM(m_depth_stencil_buffer);
		//	m_render_target_view = nullptr;

			m_attached_window = nullptr;
		}

		void Renderer::clear()
		{
			Device::get_d3d_context()->ClearRenderTargetView(m_render_target_view, reinterpret_cast<const float*>(&magenta));
			//Device::get_d3d_context()->ClearDepthStencilView(m_depth_stencil_view, D3D11_CLEAR_DEPTH | D3D11_CLEAR_STENCIL, 1.0f, 0);
		}

		bool Renderer::_resize_buffers()
		{
			VALID_ASSERT(Device::get_d3d_device() != nullptr);
			VALID_ASSERT(m_swap_chain != nullptr);

			// Destroyes the previously created objects
			SAFE_RELEASE_COM(m_render_target_view);
	//		SAFE_RELEASE_COM(m_depth_stencil_view);
//			SAFE_RELEASE_COM(m_depth_stencil_buffer);

			if (HAS_FAILED((m_swap_chain->ResizeBuffers(1, m_attached_window->get_current_width(), m_attached_window->get_current_height(), STE_DEFAULT_BUFFER_FORMAT, 0))))
				return false;
			ID3D11Texture2D* back_buffer;
			if (HAS_FAILED(m_swap_chain->GetBuffer(0,__uuidof(ID3D11Texture2D), reinterpret_cast<void**>(&back_buffer))))
				return false;
			if (HAS_FAILED(Device::get_d3d_device()->CreateRenderTargetView(back_buffer, 0, &m_render_target_view)))
				return false;
			SAFE_RELEASE_COM(back_buffer);

			D3D11_TEXTURE2D_DESC depth_stencil_desc;
			depth_stencil_desc.Width = m_attached_window->get_current_width();
			depth_stencil_desc.Height = m_attached_window->get_current_height();
			depth_stencil_desc.MipLevels = 1;
			depth_stencil_desc.ArraySize = 1;
			depth_stencil_desc.Format = DXGI_FORMAT_D24_UNORM_S8_UINT;
			
			depth_stencil_desc.SampleDesc.Count = Device::get_multisample_sample_count();
			depth_stencil_desc.SampleDesc.Quality = Device::get_multisample_quality_levels() - 1;
			
			depth_stencil_desc.Usage = D3D11_USAGE_DEFAULT;
			depth_stencil_desc.BindFlags = D3D11_BIND_DEPTH_STENCIL;
			depth_stencil_desc.CPUAccessFlags = 0;
			depth_stencil_desc.MiscFlags = 0;
		
		//	if (HAS_FAILED(Device::get_d3d_device()->CreateTexture2D(&depth_stencil_desc, 0, &m_depth_stencil_buffer)))
			//	return false;
	//		if (HAS_FAILED(Device::get_d3d_device()->CreateDepthStencilView(m_depth_stencil_buffer, 0, &m_depth_stencil_view)))
	//			return false;

			Device::get_d3d_context()->OMSetRenderTargets(1, &m_render_target_view, NULL);
			
			m_viewport.TopLeftX = 0;
			m_viewport.TopLeftY = 0;
			m_viewport.Width = static_cast<float>(m_attached_window->get_current_width());
			m_viewport.Height = static_cast<float>(m_attached_window->get_current_height());
			m_viewport.MinDepth = 0.0f;
			m_viewport.MaxDepth = 1.0f;

			Device::get_d3d_context()->RSSetViewports(1, &m_viewport);

			return true;
		}

		void Renderer::render(Sprite& _to_render)
		{
			// Preparing variables
			UINT stride = sizeof(VertexPTC);
			UINT offset = 0;

			// Setting render target

			// Setting IA infos
			Device::get_d3d_context()->IASetVertexBuffers(0, 1, &_to_render.m_vertex_buffer, &stride, &offset);
			Device::get_d3d_context()->IASetIndexBuffer(_to_render.m_index_buffer, DXGI_FORMAT_R16_UINT, 0);
			Device::get_d3d_context()->IASetInputLayout(_to_render.m_input_layout);
			Device::get_d3d_context()->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);

			// Setting the effect
			ID3DX11EffectPass* p = render_sprite_effect->get_internal_fx()->GetTechniqueByIndex(0)->GetPassByIndex(0);
			p->Apply(0, Device::get_d3d_context());

			render_sprite_effect->get_internal_fx()->GetVariableByName("sprite_texture")->AsShaderResource()->SetResource(_to_render.m_texture->m_texture_resource_view);
		
			D3D11_SAMPLER_DESC sd;
			ZeroMemory(&sd, sizeof(D3D11_SAMPLER_DESC));
			sd.AddressU = D3D11_TEXTURE_ADDRESS_WRAP;
			sd.AddressV = D3D11_TEXTURE_ADDRESS_WRAP;
			sd.AddressW = D3D11_TEXTURE_ADDRESS_WRAP;
			sd.Filter = D3D11_FILTER_MIN_MAG_MIP_LINEAR;

			ID3D11SamplerState* ss;
			HRESULT hr = Device::get_d3d_device()->CreateSamplerState(
				&sd,
				&ss);

			render_sprite_effect->get_internal_fx()->GetVariableByName("sprite_texture_sampler")->AsSampler()->SetSampler(0, ss);
			
			//(0, Device::get_d3d_context());
			Device::get_d3d_context()->DrawIndexed(6,0,0);

			m_swap_chain->Present(0, 0);
		}
	}
}