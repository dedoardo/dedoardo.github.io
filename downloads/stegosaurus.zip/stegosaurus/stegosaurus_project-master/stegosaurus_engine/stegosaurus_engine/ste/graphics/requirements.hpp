/*===========================================================================
|> License
|	The MIT License (MIT)
|
|	Copyright (c) 2013 Edoardo Alberto Dominici
|
|	Permission is hereby granted, free of charge, to any person obtaining a copy
|	of this software and associated documentation files (the "Software"), to deal
|	in the Software without restriction, including without limitation the rights
|	to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
|	copies of the Software, and to permit persons to whom the Software is
|	furnished to do so, subject to the following conditions:
|
|	The above copyright notice and this permission notice shall be included in
|	all copies or substantial portions of the Software.
|
|	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
|	IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
|	FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
|	AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
|	LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
|	OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
|	THE SOFTWARE.
=============================================================================*/

#ifndef REQUIREMENTS_HPP_INCLUDED_
#define REQUIREMENTS_HPP_INCLUDED_

/*===========================================================================
| > Includes
=============================================================================*/
#include "../common.hpp"

/*===========================================================================
| > Using declarations
=============================================================================*/
using ste::core::uint_32;

namespace ste
{
	namespace graphics
	{
		static D3D_FEATURE_LEVEL STE_REQUIRED_D3D_FEATURE_LEVEL = D3D_FEATURE_LEVEL_11_0;
		static DXGI_FORMAT STE_DEFAULT_BUFFER_FORMAT = DXGI_FORMAT_R8G8B8A8_UNORM;

		static uint_32 STE_DEFAULT_COLOR_RESOLUTION = 32;
		static uint_32 STE_DEFAULT_REFRESH_RATE = 60;

		static uint_32 STE_MAX_MULTISAMPLE_COUNT = 8;
	}
}

#endif // REQUIREMENTS_HPP_INCLUDED_