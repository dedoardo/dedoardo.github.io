/*===========================================================================
|> License
|	The MIT License (MIT)
|
|	Copyright (c) 2013 Edoardo Alberto Dominici
|
|	Permission is hereby granted, free of charge, to any person obtaining a copy
|	of this software and associated documentation files (the "Software"), to deal
|	in the Software without restriction, including without limitation the rights
|	to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
|	copies of the Software, and to permit persons to whom the Software is
|	furnished to do so, subject to the following conditions:
|
|	The above copyright notice and this permission notice shall be included in
|	all copies or substantial portions of the Software.
|
|	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
|	IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
|	FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
|	AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
|	LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
|	OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
|	THE SOFTWARE.
=============================================================================*/

#include "sprite.hpp"
#include "texture.hpp"
#include "device.hpp"
#include "common_effects.hpp"

namespace ste
{
	namespace graphics
	{
		Sprite::Sprite() :
			m_texture{ nullptr }
		{

			D3DX11_PASS_DESC pass_desc;
			render_sprite_effect->get_internal_fx()->GetTechniqueByIndex(0)->GetPassByIndex(0)->GetDesc(&pass_desc);

			D3D11_INPUT_ELEMENT_DESC layout[] =
			{
				{ "POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, 0, D3D11_INPUT_PER_VERTEX_DATA, 0 },
				{ "TEXCOORD", 0, DXGI_FORMAT_R32G32_FLOAT, 0, 12, D3D11_INPUT_PER_VERTEX_DATA, 0 },
				{ "COLOR", 0, DXGI_FORMAT_R32G32B32A32_FLOAT, 0, 20, D3D11_INPUT_PER_VERTEX_DATA, 0 }
			};

			HRESULT hr = Device::get_d3d_device()->CreateInputLayout(
				layout,
				ARRAYSIZE(layout),
				pass_desc.pIAInputSignature,
				pass_desc.IAInputSignatureSize,
				&m_input_layout);

			m_vertices[0].position = { -1.0f, 0.0f, 0.5f };
			m_vertices[1].position = { -1.0f,1.0f,0.5f };
			m_vertices[2].position = { 0.0f,0.0f,0.5f };
			m_vertices[3].position = { 0.0f,1.0f, 0.5f };

			m_vertices[0].texture = { 0.0f, 1.0f }; // lower left
			m_vertices[1].texture = { 0.0f, 0.0f }; // upper left
			m_vertices[2].texture = { 1.0f, 1.0f }; // lower right
			m_vertices[3].texture = { 1.0f, 0.0f }; // upper right

			m_vertices[0].color = { 1.0f, 1.0f, 1.0f, 1.0f };
			m_vertices[1].color = { 0.0f, 1.0f, 0.0f, 1.0f };
			m_vertices[2].color = { 0.0f, 0.0f, 1.0f, 1.0f };
			m_vertices[3].color = { 0.0f, 0.0f, 0.0f, 1.0f };


			ste::core::uint_16 indices[6];
			indices[0] = 0;
			indices[1] = 1;
			indices[2] = 2;
			indices[3] = 2;
			indices[4] = 1;
			indices[5] = 3;

			D3D11_BUFFER_DESC ib_desc;
			ib_desc.ByteWidth = sizeof(ste::core::uint_16) * 6;
			ib_desc.BindFlags = D3D11_BIND_INDEX_BUFFER;
			ib_desc.CPUAccessFlags = 0;
			ib_desc.StructureByteStride = sizeof(ste::core::uint_16);
			ib_desc.MiscFlags = 0;
			ib_desc.Usage = D3D11_USAGE_IMMUTABLE;

			D3D11_SUBRESOURCE_DATA ib_data;
			ib_data.pSysMem = &indices[0];

			hr = Device::get_d3d_device()->CreateBuffer(
				&ib_desc,
				&ib_data,
				&m_index_buffer);
			

			D3D11_BUFFER_DESC vb_desc;
			vb_desc.ByteWidth = sizeof(VertexPTC) * 4;
			vb_desc.BindFlags = D3D11_BIND_VERTEX_BUFFER;
			vb_desc.CPUAccessFlags = 0;
			vb_desc.MiscFlags = 0;
			vb_desc.Usage = D3D11_USAGE_IMMUTABLE;
			vb_desc.StructureByteStride = sizeof(VertexPTC);

			D3D11_SUBRESOURCE_DATA vb_data;
			ZeroMemory(&vb_data, sizeof(vb_data));
			vb_data.pSysMem = &m_vertices[0];

			hr = Device::get_d3d_device()->CreateBuffer(
				&vb_desc,
				&vb_data,
				&m_vertex_buffer);

			std::cout << hr;
		}

		Sprite::~Sprite()
		{

		}
	}
}