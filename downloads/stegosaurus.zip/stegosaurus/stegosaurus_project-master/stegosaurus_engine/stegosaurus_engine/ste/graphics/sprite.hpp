/*===========================================================================
|> License
|	The MIT License (MIT)
|
|	Copyright (c) 2013 Edoardo Alberto Dominici
|
|	Permission is hereby granted, free of charge, to any person obtaining a copy
|	of this software and associated documentation files (the "Software"), to deal
|	in the Software without restriction, including without limitation the rights
|	to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
|	copies of the Software, and to permit persons to whom the Software is
|	furnished to do so, subject to the following conditions:
|
|	The above copyright notice and this permission notice shall be included in
|	all copies or substantial portions of the Software.
|
|	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
|	IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
|	FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
|	AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
|	LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
|	OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
|	THE SOFTWARE.
=============================================================================*/

#ifndef SPRITE_HPP_INCLUDED_
#define SPRITE_HPP_INCLUDED_

#include "../common.hpp"
#include "irenderable.hpp"
#include "imovable.hpp"

namespace ste
{
	namespace graphics
	{
		struct VertexPTC
		{
			XMFLOAT3 position;
			XMFLOAT2 texture;
			XMFLOAT4 color;
		};

		class Texture;

		class Sprite : public IRenderable, public IMovable
		{
			friend class Renderer;
		public :			
			Sprite();
			~Sprite();

			void attach_texture(Texture& _texture) { m_texture = &_texture; }
			void detach_texture() { m_texture = nullptr; }
			Texture* get_attached_texture()const { return m_texture; }

		private : 
			VertexPTC					m_vertices[4];
			Texture*					m_texture;

			ID3D11Buffer*				m_vertex_buffer;
			ID3D11Buffer*				m_index_buffer;

			ID3D11InputLayout*			m_input_layout;
		};
	}
}

#endif // SPRITE_HPP_INCLUDED_