/*===========================================================================
|> License
|	The MIT License (MIT)
|
|	Copyright (c) 2013 Edoardo Alberto Dominici
|
|	Permission is hereby granted, free of charge, to any person obtaining a copy
|	of this software and associated documentation files (the "Software"), to deal
|	in the Software without restriction, including without limitation the rights
|	to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
|	copies of the Software, and to permit persons to whom the Software is
|	furnished to do so, subject to the following conditions:
|
|	The above copyright notice and this permission notice shall be included in
|	all copies or substantial portions of the Software.
|
|	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
|	IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
|	FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
|	AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
|	LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
|	OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
|	THE SOFTWARE.
=============================================================================*/

/*===========================================================================
| > Includes
=============================================================================*/
#include "texture.hpp"
#include "stb_loader\stb_image.h"
#include "../graphics/device.hpp"

using ste::core::int_32;
using ste::core::uint_8;

namespace ste
{
	namespace graphics
	{
		Texture::Texture() :
			m_width{ 0 },
			m_height{ 0 },
			m_is_created{ false },
			m_texture_resource_view{ nullptr }
		{

		}

		Texture::~Texture()
		{
			SAFE_RELEASE_COM(m_texture_resource_view);
		}

		bool Texture::load_from_file(const std::wstring& _filename)
		{
			if (m_is_created)
				return false;

			ID3D11Resource* tmp_texture;
			HRESULT hr = D3DX11CreateTextureFromFile(
				Device::get_d3d_device(),
				_filename.c_str(),
				NULL,
				NULL,
				&tmp_texture,
				NULL);

			ID3D11Texture2D* tmpt;
			tmp_texture->QueryInterface<ID3D11Texture2D>(&tmpt);
			D3D11_TEXTURE2D_DESC td;
			tmpt->GetDesc(&td);

			hr = Device::get_d3d_device()->CreateShaderResourceView(
				tmp_texture,
				NULL,
				&m_texture_resource_view);

			m_is_created = true;
			return true;
		}

		bool Texture::load_from_memory(const unsigned char* _data, size_t _size)
		{
			if (m_is_created)
				return false;

			int32_t comp;

			uint_8* data = stbi_load_from_memory(_data, _size, &m_width, &m_height, &comp, STBI_rgb_alpha);
			if (data == NULL || (comp != STBI_rgb_alpha))
				return false;

			m_data.resize(4 * m_width * m_height);
			memcpy(&m_data[0], reinterpret_cast<const void*>(data), 4 * m_width * m_height);

			stbi_image_free(data);
			
			D3D11_TEXTURE2D_DESC td;
			td.Width = m_width;
			td.Height = m_height;
			td.MipLevels = td.ArraySize = 1;
			td.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
			td.SampleDesc.Count = 1;
			td.SampleDesc.Quality = 0;
			td.Usage = D3D11_USAGE_DYNAMIC;
			td.BindFlags = D3D11_BIND_SHADER_RESOURCE;
			td.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
			td.MiscFlags = 0;

			D3D11_SUBRESOURCE_DATA sd;
			sd.pSysMem = &m_data[0];
			sd.SysMemPitch = m_width * 4;

			ID3D11Texture2D* tmp_texture;

			HRESULT hr = Device::get_d3d_device()->CreateTexture2D(
				&td,
				&sd,
				&tmp_texture);

			if (HAS_FAILED(hr))
				return false;

			hr = Device::get_d3d_device()->CreateShaderResourceView(
				tmp_texture,
				NULL,
				&m_texture_resource_view);

			if (HAS_FAILED(hr))
				return false;

			// Releasing the texture, we don't need it anymore
			SAFE_RELEASE_COM(tmp_texture);

			m_is_created = true;
			return true;
		}
	}
}