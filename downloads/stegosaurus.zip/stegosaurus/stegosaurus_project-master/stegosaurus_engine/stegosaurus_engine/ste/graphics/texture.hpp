/*===========================================================================
|> License
|	The MIT License (MIT)
|
|	Copyright (c) 2013 Edoardo Alberto Dominici
|
|	Permission is hereby granted, free of charge, to any person obtaining a copy
|	of this software and associated documentation files (the "Software"), to deal
|	in the Software without restriction, including without limitation the rights
|	to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
|	copies of the Software, and to permit persons to whom the Software is
|	furnished to do so, subject to the following conditions:
|
|	The above copyright notice and this permission notice shall be included in
|	all copies or substantial portions of the Software.
|
|	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
|	IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
|	FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
|	AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
|	LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
|	OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
|	THE SOFTWARE.
=============================================================================*/

#ifndef TEXTURE_HPP_INCLUDED_
#define TEXTURE_HPP_INCLUDED_

/*===========================================================================
| > Includes
=============================================================================*/
#include "../common.hpp"

namespace ste
{
	namespace graphics
	{
		struct Pixel
		{
			ste::core::uint_8 red;
			ste::core::uint_8 green;
			ste::core::uint_8 blue;
			ste::core::uint_8 alpha;
		};
		static const DXGI_FORMAT texture_pixel_format = DXGI_FORMAT_R8G8B8A8_UINT;

		class Texture
		{
			friend class Renderer;
		public :
			Texture();
			~Texture();
			
			bool load_from_file(const std::wstring& _filename);
			bool load_from_memory(const unsigned char* _data, size_t _size);

			ID3D11ShaderResourceView* get_internal_resource()const { return m_texture_resource_view; }

			void set_sampler_state(ID3D11SamplerState* _sampler_state){ m_sampler_state = _sampler_state; }
			ID3D11SamplerState* get_sampler_state()const {	return m_sampler_state;}

		private :
			std::vector<Pixel> m_data;
			ste::core::int_32 m_width;
			ste::core::int_32 m_height;

			ID3D11ShaderResourceView* m_texture_resource_view;
			
			ID3D11SamplerState* m_sampler_state;

			bool m_is_created;
		};
	}
}

#endif // TEXTURE_HPP_INCLUDED_