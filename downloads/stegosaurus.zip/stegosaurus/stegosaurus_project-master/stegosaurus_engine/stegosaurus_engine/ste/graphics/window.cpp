/*===========================================================================
|> License
|	The MIT License (MIT)
|
|	Copyright (c) 2013 Edoardo Alberto Dominici
|
|	Permission is hereby granted, free of charge, to any person obtaining a copy
|	of this software and associated documentation files (the "Software"), to deal
|	in the Software without restriction, including without limitation the rights
|	to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
|	copies of the Software, and to permit persons to whom the Software is
|	furnished to do so, subject to the following conditions:
|
|	The above copyright notice and this permission notice shall be included in
|	all copies or substantial portions of the Software.
|
|	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
|	IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
|	FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
|	AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
|	LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
|	OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
|	THE SOFTWARE.
=============================================================================*/

/*===========================================================================
| > Includes
=============================================================================*/
#include "window.hpp"
#include "../common.hpp"

namespace ste
{
	namespace graphics
	{
		namespace
		{
			static std::wstring class_name = L"Stegosaurus Class";
			static uint_32 window_count = {};
		}

		Window::Window(HINSTANCE _hinstance,Window* _parent) :
			m_last_message{ },
			m_hinstance{ _hinstance },
			m_parent{ _parent },
			m_style{ },
			m_is_created{ false },
			m_is_fullscreen{ false },
			m_current_width{ 0 },
			m_current_height{ 0 },
			m_current_style{ 0 },
			m_color_resolution{ STE_DEFAULT_COLOR_RESOLUTION },
			m_display_frequency{ STE_DEFAULT_REFRESH_RATE }
		{
			VALID_ASSERT(m_hinstance != nullptr);
		}

		Window::~Window()
		{
			CloseHandle(m_wnd_handle);
			m_wnd_handle = nullptr;
		}

		bool Window::create(uint_32 _width, uint_32 _height,uint_32 _style, uint_32 _pos_x, uint_32 _pos_y)
		{
			VALID_ASSERT(m_hinstance != nullptr);

			if (m_is_created)
				return false;
			
			if (!_style)
				_style = WS_OVERLAPPEDWINDOW ^ WS_THICKFRAME;
			else
				_style ^= WS_THICKFRAME;

			m_current_width = _width;
			m_current_height = _height;
			m_current_style = _style;

			WNDCLASSEX wc;
			wc.cbSize = sizeof(WNDCLASSEX);
			wc.style = CS_HREDRAW | CS_VREDRAW | CS_OWNDC;
			wc.lpfnWndProc = &Window::RedirectWindowProcedure;
			wc.cbClsExtra = 0;
			wc.cbWndExtra = 0;
			wc.hInstance = m_hinstance;
			wc.hIcon = LoadIcon(NULL, IDC_ARROW);
			wc.hCursor = LoadCursor(NULL, MAKEINTRESOURCE(IDI_APPLICATION));
			wc.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
			wc.lpszClassName = class_name.c_str();
			wc.lpszMenuName = NULL;
			wc.hIconSm = wc.hIcon;

			if (!RegisterClassEx(&wc))
				return false;
			
			m_wnd_handle = CreateWindowEx(WS_EX_APPWINDOW,
				class_name.c_str(),
				L"window",
				_style,
				_pos_x, _pos_y,
				_width, _height,
				NULL, NULL, m_hinstance,
				NULL);
			++window_count;

			if (m_wnd_handle == NULL)
				return false;

			ShowWindow(m_wnd_handle, SW_SHOW);
			SetFocus(m_wnd_handle);
			UpdateWindow(m_wnd_handle);

			m_is_created = true;
			return true;
		}

		void Window::update()
		{
			_process_messages();
		}

		bool Window::set_size_and_position(uint_32 _width, uint_32 _height, uint_32 _pos_x, uint_32 _pos_y)
		{
			if (!m_is_created)
				return false;

			m_current_width = _width;
			m_current_height = _height;

			// Not returning SetWindowPos directly because BOOL is defined as int and this will issue a C4800 Performance Warning
			if (!SetWindowPos(m_wnd_handle,
				HWND_TOP,
				_pos_x, _pos_y,
				m_current_width, m_current_height,
				SWP_SHOWWINDOW | SWP_FRAMECHANGED))
				return false;
			return true;
		}

		bool Window::set_style(uint_32 _style)
		{
			if (!m_is_created)
				return false;

			RECT rect;
			GetWindowRect(m_wnd_handle, &rect);

			m_current_style = _style ^ WS_THICKFRAME;
			
			if (!SetWindowLongPtr(m_wnd_handle, GWL_STYLE, m_current_style ^ WS_THICKFRAME))
				return false;
			if (!SetWindowPos(m_wnd_handle, HWND_TOP, rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, SWP_SHOWWINDOW | SWP_FRAMECHANGED))
				return false;

			return true;
		}

		bool Window::set_fullscreen(bool _value, DisplayMode* _display_mode)
		{
			if (!m_is_created)
				return false;

			if (_value && _display_mode == nullptr)
				return false;
			
			if ((m_is_fullscreen && _value) || (!m_is_fullscreen && !_value))
				return false;

			if (_value)
				return _go_fullscreen(_display_mode);
			else
				return _leave_fullscreen();
		}

		LRESULT CALLBACK Window::RedirectWindowProcedure(HWND _hwnd, UINT _msg, WPARAM _wparam, LPARAM _lparam)
		{
			switch (_msg)
			{
			case WM_DESTROY:
			{
							   exit(1);
							   break;
			}
			case WM_QUIT:
			{
							exit(1);
							break;
			}
			case WM_DISPLAYCHANGE:
			{
									 int w = LOWORD(_lparam);
									 int h = HIWORD(_lparam);
									 break;
			}
			default:
				return DefWindowProc(_hwnd, _msg, _wparam, _lparam);
			}
			return DefWindowProc(_hwnd, _msg, _wparam, _lparam);
		}

		bool Window::_go_fullscreen(DisplayMode* _display_mode)
		{
			if (m_is_fullscreen)
				return false;

			DEVMODE dm;
			dm.dmSize = sizeof(dm);
			dm.dmFields = DM_PELSWIDTH | DM_PELSHEIGHT | DM_BITSPERPEL;
			dm.dmPelsWidth = _display_mode->get_width();
			dm.dmPelsHeight = _display_mode->get_height();
			dm.dmBitsPerPel = 32;

			if (ChangeDisplaySettings(&dm, CDS_FULLSCREEN) != DISP_CHANGE_SUCCESSFUL)
				return false;

			// WS_CLIPCHILDREN WS_CLIPSIBLINGS
			if (!SetWindowLongPtr(m_wnd_handle, GWL_STYLE, WS_POPUP))
				return false;

			//	if (!SetWindowLongPtr(m_wnd_handle, GWL_EXSTYLE, WS_EX_APPWINDOW))
			//	return false;

			if (!SetWindowPos(m_wnd_handle, NULL, 0, 0, _display_mode->get_width(), _display_mode->get_height(), SWP_FRAMECHANGED))
				return false;

			ShowWindow(m_wnd_handle, SW_SHOW);

			m_is_fullscreen = true;
			return true;
		}

		bool Window::_leave_fullscreen()
		{
			if (ChangeDisplaySettings(NULL, 0) != DISP_CHANGE_SUCCESSFUL)
				return false;
			
			set_style(WS_OVERLAPPEDWINDOW);

			m_is_fullscreen = false;

			return true;
		}

		void Window::_process_messages()
		{
			memset(reinterpret_cast<void*>(&m_last_message), 0, sizeof(m_last_message));
			if (PeekMessage(&m_last_message, m_wnd_handle, 0, 0, PM_REMOVE))
			{
				TranslateMessage(&m_last_message);
				DispatchMessage(&m_last_message);
			}
		}
	}
}