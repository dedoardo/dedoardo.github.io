/*===========================================================================
|> License
|	The MIT License (MIT)
|
|	Copyright (c) 2013 Edoardo Alberto Dominici
|
|	Permission is hereby granted, free of charge, to any person obtaining a copy
|	of this software and associated documentation files (the "Software"), to deal
|	in the Software without restriction, including without limitation the rights
|	to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
|	copies of the Software, and to permit persons to whom the Software is
|	furnished to do so, subject to the following conditions:
|
|	The above copyright notice and this permission notice shall be included in
|	all copies or substantial portions of the Software.
|
|	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
|	IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
|	FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
|	AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
|	LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
|	OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
|	THE SOFTWARE.
=============================================================================*/

#ifndef WINDOW_HPP_INCLUDED_
#define WINDOW_HPP_INCLUDED_

/*===========================================================================
| > Includes
=============================================================================*/
#include "../common.hpp"
#include "display_mode.hpp"
#include "coordinate_system.hpp"

namespace ste
{
	namespace graphics
	{
		/*===========================================================================*/
		/// \brief Wrapper for a Win32 HWND. It's needed by the a Renderer instance for rendering
		/*===========================================================================*/
		class Window
		{

		public:
			/*===========================================================================*/
			/// \brief Explicitly deleting the default constructor
			/*===========================================================================*/
			Window() = delete;

			/*===========================================================================*/
			/// \brief Constructs the window class with the specified parameters. This does not
			///		   create the window. You need to call the create(...) method
			/// 
			/// \param _hinstance HINSTANCE associated with the running program. If it's set
			///					  to nullptr it will cause an assertion error in debug mode
			/// \param _parent Window parent if any. This feature is not supported yet. TODO : improve support
			/*===========================================================================*/
			Window(HINSTANCE _hinstance,Window* _parent);

			/*===========================================================================*/
			/// \brief Destroyes the object and closes the HWND handle
			/*===========================================================================*/
			~Window();

			//! creates the window with the specified parameters
			/*===========================================================================*/
			/// \brief Creates the actual window and displays it
			///
			/// \param _width Width ( in pixels ) of the new window
			/// \param _height Height ( in pixels ) of the  new window
			/// \param _style Style of the window. Use default WS or WS_EX styles ORed together.
			///				  Default to 0 or WS_OVERLAPPED ^ WS_THICKFRAME. The window does not 
			///				  allow resizing. the style if filtered, any WS_THICKFRAME is removed
			/// \param _posx X-coordinate of the top-left corner of the window
			/// \param _posy Y-coordinate of the top-left corner of the window
			///
			/// \return True if the creation was successfull, false otherwise. It will try to log any error
			/*===========================================================================*/
			bool create(uint_32 _width, uint_32 _height, uint_32 _style = 0, uint_32 _pos_x = CW_USEDEFAULT, uint_32 _pos_y = CW_USEDEFAULT);


			/*===========================================================================*/
			/// \brief Updates the window by processing the messages. It SHOULD NOT be called 
			///		   by the user if already attached to a renderer. TODO : do not allow the user to do this
			/*===========================================================================*/
			void update();


			/*===========================================================================*/
			/// \brief Sets the size and position of the window. Valid only if the window has already been created
			///
			/// \param _width Width ( in pixels ) of the new window
			/// \param _height Height ( in pixels ) of the  new window
			/// \param _posx X-coordinate of the top-left corner of the window
			/// \param _posy Y-coordinate of the top-left corner of the window
			///
			/// \return True if resizing/repositioning was successful, false otherwise. It will try to log any error
			/*===========================================================================*/
			bool set_size_and_position(uint_32 _width, uint_32 _height, uint_32 _pos_x = 0, uint_32 _pos_y = 0);

			/*===========================================================================*/
			/// \brief Sets the style of the window. Valid only if the window has already been created
			///
			/// \param _style Style of the window. Use default WS or WS_EX styles ORed together.
			///				  Default to 0 or WS_OVERLAPPED ^ WS_THICKFRAME. The window does not 
			///				  allow resizing. the style if filtered, any WS_THICKFRAME is removed
			///
			/// \return True if restyling was successful, false otherwise. It will try to log any error
			/*===========================================================================*/
			bool set_style(uint_32 _style);

			/*===========================================================================*/
			/// \brief Sets fullscreen mode. Valid only if the window has already been created
			///
			/// \param _value True for fullscreen mode. False for windowed
			/// \param _display_mode Display mode required only if _value is true. Ignored otherwise
			/// 
			/// \return True if the operation was successul, false otherwise. It will try to log any error
			/*===========================================================================*/
			bool set_fullscreen(bool _value, DisplayMode* _display_mode = nullptr);

			/*===========================================================================*/
			/// \brief Retrieves the parent of the current window if any
			/*===========================================================================*/
			Window* get_parent()const{ return m_parent; }

			/*===========================================================================*/
			/// \brief Retrieves the current width of the window
			/*===========================================================================*/
			uint_32 get_current_width()const { return m_current_width; } 

			/*===========================================================================*/
			/// \brief Retrieves the current height of the window
			/*===========================================================================*/
			uint_32 get_current_height()const { return m_current_height; }

			/*===========================================================================*/
			/// \brief Retrieves the current color resolution.
			///
			/// \return Color resolution of the passed DisplayMode if fullscreen. STE_DEFAULT_COLOR_RESOLUTION otherwise
			/*===========================================================================*/
			uint_32 get_color_resolution()const { return m_color_resolution; }

			/*===========================================================================*/
			/// \brief Retrieves the numerator of the monitor refreshrate. 
			///
			/// \return Display frequency of the passed DisplayMode if fullscreen. STE_DEFAULT_DISPLAY_FREQUENCY otherwise
			/*===========================================================================*/
			uint_32 get_display_frequency()const { return m_display_frequency; }

			/*===========================================================================*/
			/// \brief Returns the current state of the fullscreen mode.
			/*===========================================================================*/
			bool is_fullscreen()const { return m_is_fullscreen; }

			/*===========================================================================*/
			/// \brief Retrieves the internal HWND handle 
			/*===========================================================================*/
			HWND get_wnd_handle()const { return m_wnd_handle; }

			inline XMVECTOR to_screen_space(FXMVECTOR _to_convert)const
			{
				CoordinateSystem::to_screen_space(_to_convert, m_current_width, m_current_height);
			}

			inline XMVECTOR to_pixel(FXMVECTOR _to_convert)const
			{
				CoordinateSystem::to_pixel(_to_convert, m_current_width, m_current_height);
			}

		private : 
			static LRESULT CALLBACK RedirectWindowProcedure(HWND _hwnd, UINT _msg, WPARAM _wparam, LPARAM _lparam);

			void _process_messages();
			bool _go_fullscreen(DisplayMode* _display_mode);
			bool _leave_fullscreen();

			MSG m_last_message;

			HINSTANCE m_hinstance;
			HWND m_wnd_handle;

			Window* m_parent;
			uint_32 m_style;
			bool m_is_created;
			bool m_is_fullscreen;

			uint_32 m_current_style;
			uint_32 m_current_width;
			uint_32 m_current_height;
			uint_32 m_color_resolution;
			uint_32 m_display_frequency;
		};
	}
}
#endif // WINDOW_HPP_INCLUDED_