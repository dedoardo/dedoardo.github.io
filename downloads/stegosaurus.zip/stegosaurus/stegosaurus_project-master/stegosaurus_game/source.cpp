#define STE_STATIC

#include <Windows.h>
#include <ste/common.hpp>
#include <ste/graphics/display_mode.hpp>
#include <ste/graphics/device.hpp>
#include <ste/graphics/window.hpp>
#include <ste/graphics/renderer.hpp>
#include <ste/graphics/effect.hpp>
#include <ste/core/logger.hpp>
#include <ste/graphics/texture.hpp>
#include <ste/graphics/coordinate_system.hpp>
#include <ste/graphics/sprite.hpp>
#include <ste/common.hpp>
#include <ste/graphics/common_effects.hpp>

int WINAPI WinMain(HINSTANCE hinstance, HINSTANCE hprev_instance, LPSTR lpstr, int cmd_show)
{
	ste::graphics::Effect* eff = ste::graphics::render_sprite_effect;
	ste::graphics::DisplayMode dm;
	dm.set_display_mode(800,600);

	ste::graphics::Device* d = ste::graphics::Device::get_instance();
	ste::graphics::Device* f = ste::graphics::Device::get_instance();

	ste::graphics::Window w(hinstance, nullptr);
	w.create(1920, 1080);

	ste::graphics::Renderer r;
	r.attach_window(&w);

	ste::core::Logger::set_output_level(ste::core::LOGGING_LEVEL_DEBUG);
	LOG("ERRORE 001");

	ste::graphics::Texture t;
	t.load_from_file(L"test.dds");

	size_t ss = sizeof(ste::graphics::Pixel);

	XMVECTOR tc = XMVectorSet(0, 0, 0, 0);
	tc = ste::graphics::CoordinateSystem::to_screen_space(tc, 1920, 1080);
	tc = ste::graphics::CoordinateSystem::to_pixel(tc, 1920, 1080);

	ste::graphics::Sprite sp;
	sp.attach_texture(t);

	while (true)
	{
		w.update();
		r.clear();
		r.render(sp);
	}

	std::cout << "hello world" << std::endl;

	return 0;
}