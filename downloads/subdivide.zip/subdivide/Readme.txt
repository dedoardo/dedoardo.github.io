## CPSC 524 Assignment 1
Edoardo A. Dominici - 97359160 - e4i1b

The code in `geometry.h` implements Loop subdivision on triangular meshes and a Catmull-Cark subdivision scheme for quadrilateral meshes.
The two relevant functions are:
	- `mesh_subdiv_step_loop`
	- `mesh_subdiv_step_catmull_clark`

It is currently pretty slow because the map is way too dumb, I will see if I can finish debugging the one that doesn't require external storage.

(The code works on the models of the assignment included in the directory, but the code responsible for reconstructing a mesh is a bit slow as my map implementation is simple).
(Catmull-clark currently expect quadrilaterals, if you want to test it make sure the obj topology is correct). I have included a cube in the meshes/ directory

There is no viewer, you just specify the input and output obj. After the code has been compiled, the executable can be run with:
`bin/subdivide <input obj address> <iterations> <output obj address>`

## Requirements
Runs on Intel Sandy Bridge+ (>= Intel i* 2nd gen) and AMD Bulldozer+ (>= Ryzen - 1) on Win32 only for now.

```cmake
mkdir build
cd build && cmake .. -DCMAKE_BUILD_TYPE=Release
```
