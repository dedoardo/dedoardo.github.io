// Header
#include "cpu.h"

// libc
#include <stdint.h>
#include <string.h> // memcpy, memset
#include <stdarg.h> // va_list
#include <assert.h>
#include <stdio.h>

#if _MSC_VER

#define WIN32_LEAN_AND_MEAN
#include <Windows.h>

//--------------------------------------------------------------------------------------------------
void* terra_amalloc ( uint64_t bytes ) {
    size_t padded_bytes = ( size_t ) round_pow2 ( bytes, page_size );
    return _aligned_malloc ( padded_bytes, cache_align );
}

//--------------------------------------------------------------------------------------------------
uint64_t terra_amalloc_capacity ( uint64_t bytes ) {
    return round_pow2 ( bytes, page_size );
}

//--------------------------------------------------------------------------------------------------
// Assumes: terra_amalloc_capacity(count, size) == size * (count + k)
// fills the remaining k elements with the `write_pad` value
void terra_amalloc_pad_fill ( uint8_t* write, uint64_t element_size, uint64_t element_count, const void* write_pad ) {
    uint64_t pad_count = terra_amalloc_capacity ( element_size * element_count ) - ( element_size * element_count );
    uint64_t pad_base = element_size * element_count;

    for ( uint64_t pad_offset = 0; pad_offset < pad_count; pad_offset += element_size ) {
        memcpy ( write + pad_base + pad_offset, write_pad, element_size );
    }
}

//--------------------------------------------------------------------------------------------------
void* terra_arealloc ( void* p, uint64_t bytes ) {
    return _aligned_realloc ( p, ( size_t ) round_pow2 ( bytes, page_size ), cache_align );
}

//--------------------------------------------------------------------------------------------------
void terra_afree ( void* p ) {
    _aligned_free ( p );
}

//--------------------------------------------------------------------------------------------------
void terra_amalloc_zero ( uint8_t* p, uint64_t bytes ) {
    uint64_t bytes_padded = terra_amalloc_capacity ( bytes );
    assert_break ( bytes_padded % 256 == 0 );

    __m256i* write = _tcast ( __m256i*, p );
    const __m256i zero_reg = _mm256_set1_epi8 ( 0 );
    int64_t next_reg = ( int64_t ) bytes_padded / mm_register_bytes;

    while ( --next_reg >= 0 ) {
        _mm256_store_si256 ( write + next_reg, zero_reg );
    }
}

//--------------------------------------------------------------------------------------------------
void* mem_stack_incr ( uint64_t bytes ) {
    return terra_amalloc ( bytes );
}

//--------------------------------------------------------------------------------------------------
void  mem_stack_decr ( void* ptr ) {
    terra_afree ( ptr );
}

//--------------------------------------------------------------------------------------------------
double cpu_timer_frequency_secs = 0.;
double cpu_timer_frequency_us = 0.;
double cpu_timer_frequency_ms = 0.;

void cpu_timer_init() {
    LARGE_INTEGER frequency;
    QueryPerformanceFrequency ( &frequency );
    cpu_timer_frequency_secs = 1. / frequency.QuadPart;
    cpu_timer_frequency_ms = 1000. / frequency.QuadPart;
    cpu_timer_frequency_us = ( 1000. * 1000 ) / frequency.QuadPart;
    cpu_timer_frequency_ms = ( 1000. ) / frequency.QuadPart;
}

//--------------------------------------------------------------------------------------------------
uint64_t cpu_timer_split() {
    LARGE_INTEGER counter;
    QueryPerformanceCounter ( &counter );
    return ( uint64_t ) counter.QuadPart;
}

//--------------------------------------------------------------------------------------------------
double cpu_timer_elapsed_us ( uint64_t ticks ) {
    return cpu_timer_frequency_us * ticks;
}

//--------------------------------------------------------------------------------------------------
double cpu_timer_elapsed_ms ( uint64_t ticks ) {
    return cpu_timer_frequency_ms * ticks;
}

double cpu_timer_elapsed_secs ( uint64_t ticks ) {
    return cpu_timer_frequency_secs * ticks;
}
#else
#error ...
#endif
