#ifndef _terra_cpu_h_
#define _terra_cpu_h_

// Terra CPU Intrinsics controls
//--------------------------------------------------------------------------------------------------
// Terra simd intrinsics includes and a few scalar routines. sse2 support is required, but
// sse4.2/avx2/avx512 is optional. avx* are used for larger bvh branching factors, while sse4.2
// just for minor utilities.
// Note: there are 4 options but the different code paths are really only between avx2|512 and sse2/4.2, the fine
// grained versions are just to enable certain features
#define terra_simd_sse2   1 // 128 bit registers xmm0-8(15 on amd) (Pentium+)
#define terra_simd_sse42  1 // 128 bit registers xmm0-8(15 on amd) (1st gen i* core+)
#define terra_simd_avx2   1 // (128+128) bit registers ymm0-15 (Sandy bridge 2nd gen i* core) (Amd zen (ryzen))
#define terra_simd_avx512 0 // (128+128) bit registers ymm0-31

#ifndef _CRT_SECURE_NO_WARNINGS
    #define _CRT_SECURE_NO_WARNINGS 1
#endif

// Includes
//--------------------------------------------------------------------------------------------------
#if !terra_simd_sse2 //...):
    #error
#endif

// libc
#include <stdint.h>
#include <float.h>  // fp_control
#include <assert.h> // todo debugbreak ?
#include <math.h>   // todo move to math.h

// in case avx2 was manually enable, also turn on sse42 code paths
#if terra_simd_avx512
    #define terra_simd_avx2 1
    #define terra_simd_sse42 1
    #include <zmmintrin.h>
#elif terra_simd_avx2
    #include <immintrin.h>
    #define terra_simd_sse42 1
#elif terra_simd_sse42
    #include <nmmintrin.h>
#elif terra_simd_sse2
    #include <emmintrin.h>
#else
    #error
#endif

// Macros
//--------------------------------------------------------------------------------------------------
#ifdef _MSC_VER
    #define terra_win32 1
    #define terra_posix 0
    #define terra_inline __forceinline
    #define terra_breakpoint assert(0)
#elif defined(__GNUC__)
    #define terra_posix 1
    #define terra_win32 0

    #define terra_inline __attribute__((always_inline))
    #define terra_breakpoint __builtin_trap()
#endif

// no mangling when compiling as c++
#ifdef __cplusplus
    //#define terra_api_begin extern "C" {
#else
    #define terra_api_begin
#endif

#ifdef __cplusplus
    //#define terra_api_end }
#else
    #define terra_api_end
#endif

// lanes for single-precision floating point numbers
#if terra_simd_avx512
    #define mm_lanes_32 16
    #define mm_lanes_64 8
    #define mm_registers 32
#elif terra_simd_avx2
    #define mm_lanes_32 8
    #define mm_lanes_64 4
    #define mm_registers 16
#elif terra_simd_sse2
    #define mm_lanes_32 4
    #define mm_lanes_64 2
    #define mm_registers 8
#endif

#define mm_register_bytes (mm_lanes_64 * 8)
#define cache_align 64
#define page_size 4096
#define terra_eps FLT_EPSILON
#define assert_break(expr) if (!(expr)) { terra_breakpoint; }
#define terra_as(x, t) (*((t*)(x)))
#define absvf(a) (((a) < 0.f) ? (-a) : (+a))
#define minf(a, b) ((a) < (b) ? (a) : (b))
#define restrict __restrict
#define io_stream_lookahead page_size * 4
#define is_aligned(addr, pow2) ((((intptr_t)(addr)) & (pow2 - 1)) == 0x0)
#define _tcast(t, p) ((t)(p))
#define round_pow2(v, pow2) ((v & (~(pow2 - 1))) + pow2)
typedef uint8_t byte_t;

terra_api_begin

void*    terra_amalloc          ( uint64_t bytes );
uint64_t terra_amalloc_capacity ( uint64_t bytes );
void     terra_amalloc_pad_fill ( uint8_t* write, uint64_t element_size, uint64_t element_count, const void* write_pad );
void*    terra_arealloc         ( void* p, uint64_t bytes );
void     terra_afree            ( void* p );

void* mem_stack_incr ( uint64_t bytes );
void  mem_stack_decr ( void* );


// Intrisics
//--------------------------------------------------------------------------------------------------
int bitscan_forward64 ( const uint64_t bits );
int bitscan_reverse64 ( const uint64_t bits );

terra_api_end

#endif // _terra_cpu_h_