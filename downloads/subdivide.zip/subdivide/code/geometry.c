// Headers
#include "geometry.h"
#include "map.h"
#include "cpu.h"
#include "simd.h"

//terra_inline void edge_init ( MeshEdge* edge ) {
//    edge->asc.src = vertex_id_null;
//    edge->dsc.src = vertex_id_null;
//
//    edge->asc.next = edge_id_null;
//    edge->dsc.next = edge_id_null;
//}
//
//terra_inline int half_edge_is_invalid ( MeshHalfEdge* edge ) {
//    return edge->src == vertex_id_null ||
//           edge->next == edge_id_null;
//}
//
#define edge_map_capacity 4096

typedef struct _edge_key_t {
    vertex_id src;
    vertex_id dst;
} edge_key_t;

terra_inline edge_key_t edge_key_make ( vertex_id vsrc, vertex_id vdst ) {
    assert_break ( vsrc != vdst );

    edge_key_t key;
    key.src = vsrc;
    key.dst = vdst;
    return key;
}

// Geometry
//--------------------------------------------------------------------------------------------------
void geometry_create ( Geometry* geometry, vertex_id n_vertices, face_id n_faces, edge_id n_edges, int face_primitive ) {
    assert_break ( geometry );

    memset ( geometry, 0, sizeof ( *geometry ) );
    geometry->vx = terra_amalloc ( real_size * n_vertices );
    geometry->vy = terra_amalloc ( real_size * n_vertices );
    geometry->vz = terra_amalloc ( real_size * n_vertices );
    geometry->f0 = terra_amalloc ( index_size * n_faces );
    geometry->f1 = terra_amalloc ( index_size * n_faces );
    geometry->f2 = terra_amalloc ( index_size * n_faces );

    if ( face_primitive == 4 ) {
        geometry->f3 = terra_amalloc ( index_size * n_faces );
    }

    geometry->n_vertices = n_vertices;
    geometry->n_faces = n_faces;
    geometry->n_edges = n_edges;
    geometry->face_primitive = face_primitive;
}
//--------------------------------------------------------------------------------------------------
void geometry_resize ( Geometry* geometry, vertex_id n_vertices, face_id n_faces ) {
    assert_break ( geometry );

    if ( n_vertices != geometry->n_vertices ) {
        geometry->vx = terra_arealloc ( geometry->vx, real_size * n_vertices );
        geometry->vy = terra_arealloc ( geometry->vy, real_size * n_vertices );
        geometry->vz = terra_arealloc ( geometry->vz, real_size * n_vertices );
    }

    if ( n_faces != geometry->n_faces ) {
        geometry->f0 = terra_arealloc ( geometry->f0, index_size * n_faces );
        geometry->f1 = terra_arealloc ( geometry->f1, index_size * n_faces );
        geometry->f2 = terra_arealloc ( geometry->f2, index_size * n_faces );
        geometry->f3 = terra_arealloc ( geometry->f3, index_size * n_faces );
    }

    geometry->n_vertices = n_vertices;
    geometry->n_faces = n_faces;
}

//--------------------------------------------------------------------------------------------------
void geometry_free ( Geometry* geometry ) {
    if ( geometry ) {
        terra_afree ( geometry->vx );
        terra_afree ( geometry->vy );
        terra_afree ( geometry->vz );
        terra_afree ( geometry->f0 );
        terra_afree ( geometry->f1 );
        terra_afree ( geometry->f2 );
        terra_afree ( geometry->f3 );
        memset ( geometry, 0, sizeof ( *geometry ) );
    }
}

//--------------------------------------------------------------------------------------------------
void geometry_calc_aa_bounds ( const Geometry* geometry, vec4f* bounds_min_out, vec4f* bounds_max_out ) {
    assert_break ( geometry && bounds_min_out && bounds_max_out );

    __m128 bounds_min = _mm_set1_ps ( INFINITY );
    __m128 bounds_max = _mm_set1_ps ( -INFINITY );

    for ( vertex_id ivertex = 0; ivertex < geometry->n_vertices; ++ivertex ) {
        const __m128 vertex = mm_vec3f_set ( geometry->vx[ivertex], geometry->vy[ivertex], geometry->vz[ivertex] );
        bounds_min = _mm_min_ps ( bounds_min, vertex );
        bounds_max = _mm_max_ps ( bounds_max, vertex );
    }

    _mm_store_ps ( _tcast ( float*, bounds_min_out ), bounds_min );
    _mm_store_ps ( _tcast ( float*, bounds_max_out ), bounds_max );
}

//--------------------------------------------------------------------------------------------------
vec4f geometry_calc_com ( const Geometry* geom ) {
    vec4f com = vec4f_zero();

    for ( vertex_id ivertex = 0; ivertex < geom->n_vertices; ++ivertex ) {
        com.x += geom->vx[ivertex];
        com.y += geom->vy[ivertex];
        com.z += geom->vz[ivertex];
    }

    return com;
}

//--------------------------------------------------------------------------------------------------
void geometry_move_to_origin ( Geometry* geometry ) {
    const vec4f com = geometry_calc_com ( geometry );

    for ( vertex_id ivertex = 0; ivertex < geometry->n_vertices; ++ivertex ) {
        geometry->vx[ivertex] -= com.x;
        geometry->vy[ivertex] -= com.y;
        geometry->vz[ivertex] -= com.z;
    }
}

//--------------------------------------------------------------------------------------------------
vec4f geometry_scale_to_unit ( Geometry* geometry ) {
    vec4f bounds_min, bounds_max;
    geometry_calc_aa_bounds ( geometry, &bounds_min, &bounds_max );
    const __m128 bounds = _mm_sub_ps ( _mm_load_ps ( _tcast ( const float*, &bounds_min ) ),
                                       _mm_load_ps ( _tcast ( const float*, &bounds_max ) ) );
    const __m128 scale = _mm_div_ps ( _mm_set1_ps ( 1.f ), bounds );
    const __m256 scale_x = _mm256_set1_ps ( mm_vec4f_comp ( scale, 0 ) );
    const __m256 scale_y = _mm256_set1_ps ( mm_vec4f_comp ( scale, 1 ) );
    const __m256 scale_z = _mm256_set1_ps ( mm_vec4f_comp ( scale, 2 ) );

    for ( vertex_id ivertex = 0; ivertex < geometry->n_vertices; ivertex += mm_lanes_32 ) {
        const __m256 vertex_x = _mm256_load_ps ( geometry->vx + ivertex );
        const __m256 vertex_y = _mm256_load_ps ( geometry->vy + ivertex );
        const __m256 vertex_z = _mm256_load_ps ( geometry->vz + ivertex );

        _mm256_store_ps ( geometry->vx + ivertex, _mm256_mul_ps ( scale_x, vertex_x ) );
        _mm256_store_ps ( geometry->vy + ivertex, _mm256_mul_ps ( scale_y, vertex_y ) );
        _mm256_store_ps ( geometry->vz + ivertex, _mm256_mul_ps ( scale_z, vertex_z ) );
    }

    return vec4f_set ( mm_vec4f_comp ( bounds, 0 ), mm_vec4f_comp ( bounds, 1 ), mm_vec4f_comp ( bounds, 2 ), 0.f );
}

//--------------------------------------------------------------------------------------------------
void mesh_create ( Mesh* mesh, const Geometry* geometry ) {
    memset ( mesh, 0, sizeof ( *mesh ) );
    const edge_id n_hedges = geometry->n_edges * 2;
    const uint64_t face_buffer_size = index_size * geometry->n_faces;
    const uint64_t hedges_buffer_size = index_size * n_hedges;

    mesh->face_edge0 = terra_amalloc ( face_buffer_size );
    mesh->face_edge1 = terra_amalloc ( face_buffer_size );
    mesh->face_edge2 = terra_amalloc ( face_buffer_size );
    mesh->face_edge3 = terra_amalloc ( face_buffer_size );
    mesh->edge_src = terra_amalloc ( hedges_buffer_size );
    mesh->edge_next = terra_amalloc ( hedges_buffer_size );
    mesh->edge_face = terra_amalloc ( hedges_buffer_size );
    mesh->vertex_flags = terra_amalloc ( sizeof ( VertexFlag ) * geometry->n_vertices );

    // The only values in the buffer that needs to be cleared are the ones not rounding up
    const uint64_t index_pad_fill = index_null;
    terra_amalloc_pad_fill ( ( uint8_t* ) mesh->face_edge0, index_size, geometry->n_faces, &index_pad_fill );
    terra_amalloc_pad_fill ( ( uint8_t* ) mesh->face_edge1, index_size, geometry->n_faces, &index_pad_fill );
    terra_amalloc_pad_fill ( ( uint8_t* ) mesh->face_edge2, index_size, geometry->n_faces, &index_pad_fill );
    terra_amalloc_pad_fill ( ( uint8_t* ) mesh->edge_src, index_size, n_hedges, &index_pad_fill );
    terra_amalloc_pad_fill ( ( uint8_t* ) mesh->edge_next, index_size, n_hedges, &index_pad_fill );
    terra_amalloc_pad_fill ( ( uint8_t* ) mesh->edge_face, index_size, n_hedges, &index_pad_fill );
    memset ( mesh->vertex_flags, 0, sizeof ( VertexFlag ) * geometry->n_vertices );
}

// Mesh
// Computes connectivity data resolving vertex/topology mappings with a linear map
//--------------------------------------------------------------------------------------------------
int mesh_build ( Mesh* mesh, const Geometry* geometry ) {
    assert_break ( mesh && geometry );
    mesh_create ( mesh, geometry );

    // Temporary storage to resolve vertex <-> edge <-> face mappings
    // (can map_remove() processed edges to save *a lot* of memory)
    map_t edge_map;
    map_create ( &edge_map, sizeof ( edge_key_t ), sizeof ( edge_id ), edge_map_capacity );
    edge_id edge_next = 0;

    // This could be made less redundant...
    if ( geometry->face_primitive == 3 ) {
        // Each face initializes his internal half-edges
        for ( face_id iface = 0; iface < geometry->n_faces; ++iface ) {
            const vertex_id vertex0 = geometry->f0[iface];
            const vertex_id vertex1 = geometry->f1[iface];
            const vertex_id vertex2 = geometry->f2[iface];

            // Checking if we need to reserve an id for the edge by looking up the opposite
            // half edge with the flipped vertex ids
            const edge_key_t edge0_key = edge_key_make ( vertex0, vertex1 );
            const edge_key_t edge0_key_rev = edge_key_make ( vertex1, vertex0 );
            const edge_key_t edge1_key = edge_key_make ( vertex1, vertex2 );
            const edge_key_t edge1_key_rev = edge_key_make ( vertex2, vertex1 );
            const edge_key_t edge2_key = edge_key_make ( vertex2, vertex0 );
            const edge_key_t edge2_key_rev = edge_key_make ( vertex0, vertex2 );

            edge_id* pedge0 = ( edge_id* ) map_find ( &edge_map, &edge0_key_rev );
            edge_id* pedge1 = ( edge_id* ) map_find ( &edge_map, &edge1_key_rev );
            edge_id* pedge2 = ( edge_id* ) map_find ( &edge_map, &edge2_key_rev );
            map_make_space ( &edge_map, 6 );

            edge_id edge0, edge1, edge2;
            int map_remove_edges = 0x0;

            // Initializing half-edges
            if ( !pedge0 ) {
                edge_id iedge0 = edge_next++;
                edge_id iedge0_twin = edge_next++;

                if ( vertex0 > vertex1 ) {
                    swap_xori64 ( &iedge0, &iedge0_twin );
                }

                map_add ( &edge_map, &edge0_key, &iedge0 );
                map_add ( &edge_map, &edge0_key_rev, &iedge0_twin );
                edge0 = iedge0;
                ++mesh->vertex_flags[edge0_key.src].valence;
                ++mesh->vertex_flags[edge0_key.dst].valence;
            } else {
                edge0 = * ( ( edge_id* ) map_find ( &edge_map, &edge0_key ) );
                map_remove_edges |= 0x1;
            }

            if ( !pedge1 ) {
                edge_id iedge1 = edge_next++;
                edge_id iedge1_twin = edge_next++;

                if ( vertex1 > vertex2 ) {
                    swap_xori64 ( &iedge1, &iedge1_twin );
                }

                map_add ( &edge_map, &edge1_key, &iedge1 );
                map_add ( &edge_map, &edge1_key_rev, &iedge1_twin );
                edge1 = iedge1;
                ++mesh->vertex_flags[edge1_key.src].valence;
                ++mesh->vertex_flags[edge1_key.dst].valence;
            } else {
                edge1 = * ( ( edge_id* ) map_find ( &edge_map, &edge1_key ) );
                map_remove_edges |= 0x2;
            }

            if ( !pedge2 ) {
                edge_id iedge2 = edge_next++;
                edge_id iedge2_twin = edge_next++;

                if ( vertex0 > vertex2 ) {
                    swap_xori64 ( &iedge2, &iedge2_twin );
                }

                map_add ( &edge_map, &edge2_key, &iedge2 );
                map_add ( &edge_map, &edge2_key_rev, &iedge2_twin );
                edge2 = iedge2;
                ++mesh->vertex_flags[edge2_key.src].valence;
                ++mesh->vertex_flags[edge2_key.dst].valence;
            } else {
                edge2 = * ( ( edge_id* ) map_find ( &edge_map, &edge2_key ) );
                map_remove_edges |= 0x4;
            }

            if ( map_remove_edges & 0x1 ) {
                map_remove ( &edge_map, &edge0_key );
                map_remove ( &edge_map, &edge0_key_rev );
            }

            if ( map_remove_edges & 0x2 ) {
                map_remove ( &edge_map, &edge1_key );
                map_remove ( &edge_map, &edge1_key_rev );
            }

            if ( map_remove_edges & 0x4 ) {
                map_remove ( &edge_map, &edge2_key );
                map_remove ( &edge_map, &edge2_key_rev );
            }

            // per-face
            mesh->face_edge0[iface] = edge0;
            mesh->face_edge1[iface] = edge1;
            mesh->face_edge2[iface] = edge2;

            // per-edge
            mesh->edge_src[edge0] = vertex0;
            mesh->edge_src[edge1] = vertex1;
            mesh->edge_src[edge2] = vertex2;

            mesh->edge_face[edge0] = iface;
            mesh->edge_face[edge1] = iface;
            mesh->edge_face[edge2] = iface;

            mesh->edge_next[edge0] = edge1;
            mesh->edge_next[edge1] = edge2;
            mesh->edge_next[edge2] = edge0;
        }
    } else if ( geometry->face_primitive == 4 ) {
        for ( face_id iface = 0; iface < geometry->n_faces; ++iface ) {
            const vertex_id vertex0 = geometry->f0[iface];
            const vertex_id vertex1 = geometry->f1[iface];
            const vertex_id vertex2 = geometry->f2[iface];
            const vertex_id vertex3 = geometry->f3[iface];

            //io_msg ( "face %lld %lld %lld %lld\n", vertex0, vertex1, vertex2, vertex3 );

            const edge_key_t edge0_key     = edge_key_make ( vertex0, vertex1 );
            const edge_key_t edge0_key_rev = edge_key_make ( vertex1, vertex0 );
            const edge_key_t edge1_key     = edge_key_make ( vertex1, vertex2 );
            const edge_key_t edge1_key_rev = edge_key_make ( vertex2, vertex1 );
            const edge_key_t edge2_key     = edge_key_make ( vertex2, vertex3 );
            const edge_key_t edge2_key_rev = edge_key_make ( vertex3, vertex2 );
            const edge_key_t edge3_key     = edge_key_make ( vertex3, vertex0 );
            const edge_key_t edge3_key_rev = edge_key_make ( vertex0, vertex3 );

            edge_id* pedge0 = ( edge_id* ) map_find ( &edge_map, &edge0_key_rev );
            edge_id* pedge1 = ( edge_id* ) map_find ( &edge_map, &edge1_key_rev );
            edge_id* pedge2 = ( edge_id* ) map_find ( &edge_map, &edge2_key_rev );
            edge_id* pedge3 = ( edge_id* ) map_find ( &edge_map, &edge3_key_rev );
            map_make_space ( &edge_map, 8 );

            edge_id edge0, edge1, edge2, edge3;

            int map_remove_edges = 0x0;

            if ( !pedge0 ) {
                edge_id iedge0 = edge_next++;
                edge_id iedge0_twin = edge_next++;

                if ( vertex0 > vertex1 ) {
                    swap_xori64 ( &iedge0, &iedge0_twin );
                }

                map_add ( &edge_map, &edge0_key, &iedge0 );
                map_add ( &edge_map, &edge0_key_rev, &iedge0_twin );
                edge0 = iedge0;
                ++mesh->vertex_flags[edge0_key.src].valence;
                ++mesh->vertex_flags[edge0_key.dst].valence;
            } else {
                edge0 = * ( ( edge_id* ) map_find ( &edge_map, &edge0_key ) );
                map_remove_edges |= 0x1;
            }

            if ( !pedge1 ) {
                edge_id iedge1 = edge_next++;
                edge_id iedge1_twin = edge_next++;

                if ( vertex0 > vertex1 ) {
                    swap_xori64 ( &iedge1, &iedge1_twin );
                }

                map_add ( &edge_map, &edge1_key, &iedge1 );
                map_add ( &edge_map, &edge1_key_rev, &iedge1_twin );
                edge1 = iedge1;
                ++mesh->vertex_flags[edge1_key.src].valence;
                ++mesh->vertex_flags[edge1_key.dst].valence;
            } else {
                edge1 = * ( ( edge_id* ) map_find ( &edge_map, &edge1_key ) );
                map_remove_edges |= 0x2;
            }

            if ( !pedge2 ) {
                edge_id iedge2 = edge_next++;
                edge_id iedge2_twin = edge_next++;

                if ( vertex0 > vertex1 ) {
                    swap_xori64 ( &iedge2, &iedge2_twin );
                }

                map_add ( &edge_map, &edge2_key, &iedge2 );
                map_add ( &edge_map, &edge2_key_rev, &iedge2_twin );
                edge2 = iedge2;
                ++mesh->vertex_flags[edge2_key.src].valence;
                ++mesh->vertex_flags[edge2_key.dst].valence;
            } else {
                edge2 = * ( ( edge_id* ) map_find ( &edge_map, &edge2_key ) );
                map_remove_edges |= 0x4;
            }

            if ( !pedge3 ) {
                edge_id iedge3 = edge_next++;
                edge_id iedge3_twin = edge_next++;

                if ( vertex0 > vertex1 ) {
                    swap_xori64 ( &iedge3, &iedge3_twin );
                }

                map_add ( &edge_map, &edge3_key, &iedge3 );
                map_add ( &edge_map, &edge3_key_rev, &iedge3_twin );
                edge3 = iedge3;
                ++mesh->vertex_flags[edge3_key.src].valence;
                ++mesh->vertex_flags[edge3_key.dst].valence;
            } else {
                edge3 = * ( ( edge_id* ) map_find ( &edge_map, &edge3_key ) );
                map_remove_edges |= 0x8;
            }

            if ( map_remove_edges & 0x1 ) {
                map_remove ( &edge_map, &edge0_key );
                map_remove ( &edge_map, &edge0_key_rev );
            }

            if ( map_remove_edges & 0x2 ) {
                map_remove ( &edge_map, &edge1_key );
                map_remove ( &edge_map, &edge1_key_rev );
            }

            if ( map_remove_edges & 0x4 ) {
                map_remove ( &edge_map, &edge2_key );
                map_remove ( &edge_map, &edge2_key_rev );
            }

            if ( map_remove_edges & 0x8 ) {
                map_remove ( &edge_map, &edge3_key );
                map_remove ( &edge_map, &edge3_key_rev );
            }

#if terra_dev_debug
            io_msg ( "e0 (%lld %lld) e1 (%lld %lld) e2 (%lld %lld) e3 (%lld %lld)\n",
                     edge0_key.src, edge0_key.dst, edge1_key.src, edge1_key.dst, edge2_key.src, edge2_key.dst, edge3_key.src, edge3_key.dst );
#endif

            mesh->face_edge0[iface] = edge0;
            mesh->face_edge1[iface] = edge1;
            mesh->face_edge2[iface] = edge2;
            mesh->face_edge3[iface] = edge3;

            mesh->edge_src[edge0] = vertex0;
            mesh->edge_src[edge1] = vertex1;
            mesh->edge_src[edge2] = vertex2;
            mesh->edge_src[edge3] = vertex3;

            mesh->edge_face[edge0] = iface;
            mesh->edge_face[edge1] = iface;
            mesh->edge_face[edge2] = iface;
            mesh->edge_face[edge3] = iface;

            mesh->edge_next[edge0] = edge1;
            mesh->edge_next[edge1] = edge2;
            mesh->edge_next[edge2] = edge3;
            mesh->edge_next[edge3] = edge0;
        }
    } else {
        assert_break ( 0 );
    }


#if terra_dev_debug
    io_msg ( "Finished building mesh\n" );

    for ( edge_id i = 0; i < geometry->n_edges; ++i ) {
        const edge_id hedge0 = mesh_hedge0 ( i );
        const edge_id hedge1 = mesh_hedge1 ( i );

        io_msg ( "Half-edge %lld -> %lld\n", mesh_edge_src ( hedge0 ), mesh_edge_src ( hedge1 ) );

        //   io_msg ( "(%3lld) Edge %3lld -> %3lld next %3lld next-twin %3lld\n",
        //            i, mesh_edge_src ( hedge0 ), mesh_edge_src ( hedge1 ), mesh_edge_next ( hedge0 ), mesh_edge_next ( hedge1 ) );
    }

    io_msg ( "-------------------\n" );
#endif

    assert_break ( ( edge_next / 2 ) == geometry->n_edges );

    map_free ( &edge_map );

    return 1;
}

//--------------------------------------------------------------------------------------------------
// Releases connectivity data
void mesh_free ( Mesh* mesh ) {
    assert_break ( mesh );
    terra_afree ( mesh->face_edge0 );
    terra_afree ( mesh->face_edge1 );
    terra_afree ( mesh->face_edge2 );
    terra_afree ( mesh->face_edge3 );
    terra_afree ( mesh->edge_src );
    terra_afree ( mesh->edge_next );
    terra_afree ( mesh->edge_face );
    memset ( mesh, 0, sizeof ( *mesh ) );
}

//--------------------------------------------------------------------------------------------------
// Performs a single step of surface subdivision using Loop's scheme.
int mesh_subdiv_step_loop ( const Mesh* mesh, const Geometry* geom_in, Geometry* geom_out, Mesh* mesh_out ) {
    if ( geom_in->face_primitive == 4 ) {
        return 0;
    }

    const vertex_id n_vertices_out = geom_in->n_vertices + geom_in->n_edges;
    const face_id n_faces_out = geom_in->n_faces * 4;
    const edge_id n_edges_out = geom_in->n_edges * 4;

    geometry_create ( geom_out, n_vertices_out, n_faces_out, n_edges_out, 3 );
    memset ( geom_out->vx, 0, real_size * geom_out->n_vertices );
    memset ( geom_out->vy, 0, real_size * geom_out->n_vertices );
    memset ( geom_out->vz, 0, real_size * geom_out->n_vertices );

    // Calculating odd vertices and storing neighbor partial sum in output vertex buffer
    const __m256 odd_adj_weight = _mm256_set1_ps ( 3.f / 8 );
    const __m256 odd_opp_weight = _mm256_set1_ps ( 1.f / 8 );

    vertex_id* opp0_addr_buf = mem_stack_incr ( index_size * mm_lanes_32 );
    vertex_id* opp1_addr_buf = mem_stack_incr ( index_size * mm_lanes_32 );
    vertex_id* adj0_addr_buf = mem_stack_incr ( index_size * mm_lanes_32 );
    vertex_id* adj1_addr_buf = mem_stack_incr ( index_size * mm_lanes_32 );

    uint8_t*   valences = mem_stack_incr ( geom_in->n_vertices );
    memset ( valences, 0, geom_in->n_vertices );

    // The source and destination vertices of the edge are already stored, to compute
    // the odd vertices we need to gather the vertices opposite to the edge in the adjacent faces
    for ( edge_id iedge = 0; iedge < geom_in->n_edges; iedge += mm_lanes_32 ) {
        memset ( opp0_addr_buf, 0x0, index_size * mm_lanes_32 );
        memset ( opp1_addr_buf, 0x0, index_size * mm_lanes_32 );
        memset ( adj0_addr_buf, 0x0, index_size * mm_lanes_32 );
        memset ( adj1_addr_buf, 0x0, index_size * mm_lanes_32 );

        // Scalar gather
        for ( int ilane = 0; ilane < mm_lanes_32; ++ilane ) {
            if ( iedge + ilane >= geom_in->n_edges ) {
                break;
            }

            const edge_id hedge0_id = mesh_hedge0 ( iedge + ilane );
            const edge_id hedge1_id = mesh_hedge1 ( iedge + ilane );

            // Adjacent vertices
            adj0_addr_buf[ilane] = mesh_edge_src ( hedge0_id );
            adj1_addr_buf[ilane] = mesh_edge_src ( hedge1_id );

            // Opposite vertices
            uint64_t en = mesh_edge_next ( hedge1_id );
            uint64_t enn = mesh_edge_next ( en );
            uint64_t ennn = mesh_edge_next ( enn );
            opp0_addr_buf[ilane] = mesh_edge_src ( mesh_edge_next ( mesh_edge_next ( hedge0_id ) ) );
            opp1_addr_buf[ilane] = mesh_edge_src ( mesh_edge_next ( mesh_edge_next ( hedge1_id ) ) );
        }

        // Destination memory address
        float* vertex_odd_x_addr = geom_out->vx + geom_in->n_vertices + iedge;
        float* vertex_odd_y_addr = geom_out->vy + geom_in->n_vertices + iedge;
        float* vertex_odd_z_addr = geom_out->vz + geom_in->n_vertices + iedge;

        // ~x
        const __m256 opp0_x = mm256_gather_f32 ( geom_in->vx, opp0_addr_buf );
        const __m256 opp1_x = mm256_gather_f32 ( geom_in->vx, opp1_addr_buf );
        const __m256 adj0_x = mm256_gather_f32 ( geom_in->vx, adj0_addr_buf );
        const __m256 adj1_x = mm256_gather_f32 ( geom_in->vx, adj1_addr_buf );
        const __m256 odd_x_adj = _mm256_mul_ps ( _mm256_add_ps ( adj0_x, adj1_x ), odd_adj_weight );
        const __m256 odd_x_opp = _mm256_mul_ps ( _mm256_add_ps ( opp0_x, opp1_x ), odd_opp_weight );
        _mm256_store_ps ( vertex_odd_x_addr, _mm256_add_ps ( odd_x_adj, odd_x_opp ) );

        // ~y
        const __m256 opp0_y = mm256_gather_f32 ( geom_in->vy, opp0_addr_buf );
        const __m256 opp1_y = mm256_gather_f32 ( geom_in->vy, opp1_addr_buf );
        const __m256 adj0_y = mm256_gather_f32 ( geom_in->vy, adj0_addr_buf );
        const __m256 adj1_y = mm256_gather_f32 ( geom_in->vy, adj1_addr_buf );
        const __m256 odd_y_adj = _mm256_mul_ps ( _mm256_add_ps ( adj0_y, adj1_y ), odd_adj_weight );
        const __m256 odd_y_opp = _mm256_mul_ps ( _mm256_add_ps ( opp0_y, opp1_y ), odd_opp_weight );
        _mm256_store_ps ( vertex_odd_y_addr, _mm256_add_ps ( odd_y_adj, odd_y_opp ) );

        // ~z
        const __m256 opp0_z = mm256_gather_f32 ( geom_in->vz, opp0_addr_buf );
        const __m256 opp1_z = mm256_gather_f32 ( geom_in->vz, opp1_addr_buf );
        const __m256 adj0_z = mm256_gather_f32 ( geom_in->vz, adj0_addr_buf );
        const __m256 adj1_z = mm256_gather_f32 ( geom_in->vz, adj1_addr_buf );
        const __m256 odd_z_adj = _mm256_mul_ps ( _mm256_add_ps ( adj0_z, adj1_z ), odd_adj_weight );
        const __m256 odd_z_opp = _mm256_mul_ps ( _mm256_add_ps ( opp0_z, opp1_z ), odd_opp_weight );
        _mm256_store_ps ( vertex_odd_z_addr, _mm256_add_ps ( odd_z_adj, odd_z_opp ) );

        // Accumulating sum of even neighbors (todo: use mm scatter?)
        for ( int ilane = 0; ilane < mm_lanes_32; ++ilane ) {
            if ( iedge + ilane >= geom_in->n_edges ) {
                break;
            }

            const vertex_id hedge0_src = mesh_edge_src ( mesh_hedge0 ( iedge + ilane ) );
            const vertex_id hedge1_src = mesh_edge_src ( mesh_hedge1 ( iedge + ilane ) );

            geom_out->vx[hedge0_src] += geom_in->vx[hedge1_src];
            geom_out->vy[hedge0_src] += geom_in->vy[hedge1_src];
            geom_out->vz[hedge0_src] += geom_in->vz[hedge1_src];

            geom_out->vx[hedge1_src] += geom_in->vx[hedge0_src];
            geom_out->vy[hedge1_src] += geom_in->vy[hedge0_src];
            geom_out->vz[hedge1_src] += geom_in->vz[hedge0_src];

            ++valences[hedge0_src];
            ++valences[hedge1_src];
        }
    }

    //for ( vertex_id ivertex = 0; ivertex < geom_in->n_vertices; ++ivertex ) {
    //    io_msg ( "Vertex valence %d\n", ( int ) valences[ivertex] );
    //}

    // Reweighting even vertices
    const float weight_valence_eq_3 = 3. / 16;
    const float weight_valence_ge_3 = 3. / 8;
    float weight_even_buf[mm_lanes_32];
    float weight_even_partial_buf[mm_lanes_32];

    for ( vertex_id ivertex = 0; ivertex < geom_in->n_vertices; ivertex += mm_lanes_32 ) {
        const uint8_t store_mask = mm256_mask_32 ( ivertex, geom_in->n_vertices );

        // Stencil weights
        // what a pain... for the data-parallel I am missing the last step...
        //const __m128i valence_i8x16 = _mm_load_si128(valences + ivertex);
        //const __m128i valence_i16x8 = _mm_unpacklo_epi8(valence_i8x16, valence_i8x16);
        //const __m128i valence_i32x4 = _mm_unpacklo_epi16(valence_i16x8, valence_i16x8);
        //const __m256 valence = _mm256_cvtepi32_ps(_mm256_castsi128_si256(valence_i32x4));
        //const __m256 beta_valence_eq_3 = _mm256_div_ps(valence_eq_3, valence);
        //// - valence_mask  = _mm256_cmp_ps ( valence, _mm256_set1_ps ( 3.f - terra_eps ), _MM_CMPINT_GE );
        // - valence_ge_3  = _mm256_div_ps ( beta_valence_ge_3, valence );
        // - beta          = _mm256_blend_ps ( valence_eq_3, valence_ge_3, ???(todo compact valence_mask into int) );
#if 0

        for ( int ilane = 0; ilane < mm_lanes_32; ++ilane ) {
            valence_buf[ilane] = ( float ) valences[ilane];

            if ( valences[ilane] > 3 ) {
                beta_buf[ilane] = weight_valence_ge_3 / valences[ilane];
            } else {
                beta_buf[ilane] = weight_valence_eq_3;
            }
        }

        const __m256 beta = _mm256_loadu_ps ( beta_buf );
        const __m256 valence = _mm256_loadu_ps ( valence_buf );
        const __m256 weight_even_partial = beta;
        const __m256 weight_even = _mm256_sub_ps ( _mm256_set1_ps ( 1.f ), _mm256_mul_ps ( valence, beta ) );
#endif

        // todo compute constant factors outside loop
        for ( int ilane = 0; ilane < mm_lanes_32; ++ilane ) {
            const int valence = valences[ivertex + ilane];
            const float pi = 3.1415927f;
            weight_even_partial_buf[ilane] = ( ( 5.f / 8 ) - powf ( ( 3.f / 8 ) + .25f * cosf ( 2.f * pi / valence ), 2.f ) ) * ( 1.f / valence );
            weight_even_buf[ilane] = 1.f - valence * weight_even_partial_buf[ilane];
        }

        const __m256 weight_even = _mm256_loadu_ps ( weight_even_buf );
        const __m256 weight_even_partial = _mm256_loadu_ps ( weight_even_partial_buf );

        // ~x
        const __m256 vertex_even_x_old     = _mm256_load_ps ( geom_in->vx + ivertex );
        const __m256 vertex_even_partial_x = _mm256_load_ps ( geom_out->vx + ivertex );
        const __m256 vertex_even_x = _mm256_add_ps ( _mm256_mul_ps ( vertex_even_x_old, weight_even ), _mm256_mul_ps ( vertex_even_partial_x, weight_even_partial ) );
        mm256_store_mask ( geom_out->vx + ivertex, vertex_even_x, store_mask );

        // ~y
        const __m256 vertex_even_y_old     = _mm256_load_ps ( geom_in->vy + ivertex );
        const __m256 vertex_even_partial_y = _mm256_load_ps ( geom_out->vy + ivertex );
        const __m256 vertex_even_y = _mm256_add_ps ( _mm256_mul_ps ( vertex_even_y_old, weight_even ), _mm256_mul_ps ( vertex_even_partial_y, weight_even_partial ) );
        mm256_store_mask ( geom_out->vy + ivertex, vertex_even_y, store_mask );

        // ~z
        const __m256 vertex_even_z_old     = _mm256_load_ps ( geom_in->vz + ivertex );
        const __m256 vertex_even_partial_z = _mm256_load_ps ( geom_out->vz + ivertex );
        const __m256 vertex_even_z = _mm256_add_ps ( _mm256_mul_ps ( vertex_even_z_old, weight_even ), _mm256_mul_ps ( vertex_even_partial_z, weight_even_partial ) );
        mm256_store_mask ( geom_out->vz + ivertex, vertex_even_z, store_mask );

#if terra_dev_debug // Debug even vertices
        io_msg ( "Even vertices\n" );

        for ( int ilane = 0; ilane < mm_lanes_32; ++ilane ) {
            io_msg ( "((%lld) Valence %d Neighbors: %.5f %.5f %.5f Position old: %.5f %.5f %.5f Position new: %.5f %.5f %.5f\n", ivertex + ilane,
                     ( int ) valences[ivertex + ilane],
                     mm256_l ( vertex_even_partial_x, ilane ), mm256_l ( vertex_even_partial_y, ilane ), mm256_l ( vertex_even_partial_z, ilane ),
                     mm256_l ( vertex_even_x_old, ilane ), mm256_l ( vertex_even_y_old, ilane ), mm256_l ( vertex_even_z_old, ilane ),
                     mm256_l ( vertex_even_x, ilane ), mm256_l ( vertex_even_y, ilane ), mm256_l ( vertex_even_z, ilane ),
                     geom_out->vx[ivertex + ilane], geom_out->vy[ivertex + ilane], geom_out->vz[ivertex + ilane] );
        }

        io_msg ( "-------------------\n" );
#endif
    }

    mem_stack_decr ( valences );
    mem_stack_decr ( adj1_addr_buf );
    mem_stack_decr ( adj0_addr_buf );
    mem_stack_decr ( opp1_addr_buf );
    mem_stack_decr ( opp0_addr_buf );

    vertex_id* face_v3_addr_buf = mem_stack_incr ( index_size * mm_lanes_64 );
    vertex_id* face_v4_addr_buf = mem_stack_incr ( index_size * mm_lanes_64 );
    vertex_id* face_v5_addr_buf = mem_stack_incr ( index_size * mm_lanes_64 );

    // Generating new topology, this is done in batches of 64 bits as vertex indices are being loaded and written
    // in different order combinations
    for ( face_id iface = 0; iface < geom_in->n_faces; iface += mm_lanes_64 ) {
        memset ( face_v3_addr_buf, vertex_id_null, index_size * mm_lanes_64 );
        memset ( face_v4_addr_buf, vertex_id_null, index_size * mm_lanes_64 );
        memset ( face_v5_addr_buf, vertex_id_null, index_size * mm_lanes_64 );

        // Gathering neighboring edges, we need to guarantee that v0/v1/v2 have the same ordering w.r.t. v3/v4/v5
        for ( int ilane = 0; ilane < mm_lanes_64; ++ilane ) {
            face_v3_addr_buf[ilane] = mesh_edge_to_vertex ( mesh->face_edge0[iface + ilane] );
            face_v4_addr_buf[ilane] = mesh_edge_to_vertex ( mesh->face_edge1[iface + ilane] );
            face_v5_addr_buf[ilane] = mesh_edge_to_vertex ( mesh->face_edge2[iface + ilane] );
        }

        const __m256i face_v3 = _mm256_load_si256 ( _tcast ( const __m256i*, face_v3_addr_buf ) );
        const __m256i face_v4 = _mm256_load_si256 ( _tcast ( const __m256i*, face_v4_addr_buf ) );
        const __m256i face_v5 = _mm256_load_si256 ( _tcast ( const __m256i*, face_v5_addr_buf ) );

        // Edge indices are the same the one of the new odd vertices.
        const __m256i face_v0 = _mm256_load_si256 ( _tcast ( const __m256i*, geom_in->f0 + iface ) );
        const __m256i face_v1 = _mm256_load_si256 ( _tcast ( const __m256i*, geom_in->f1 + iface ) );
        const __m256i face_v2 = _mm256_load_si256 ( _tcast ( const __m256i*, geom_in->f2 + iface ) );

        // The single linear _mm256_store is tempting but it would increase the distance in memory between
        // contiguous edges to 4^k
        for ( int ilane = 0; ilane < mm_lanes_64; ++ilane ) {
            geom_out->f0[ ( iface + ilane ) * 4 + 0] = mm256_comp_i64 ( face_v0, ilane );
            geom_out->f1[ ( iface + ilane ) * 4 + 0] = mm256_comp_i64 ( face_v3, ilane );
            geom_out->f2[ ( iface + ilane ) * 4 + 0] = mm256_comp_i64 ( face_v5, ilane );

            geom_out->f0[ ( iface + ilane ) * 4 + 1] = mm256_comp_i64 ( face_v3, ilane );
            geom_out->f1[ ( iface + ilane ) * 4 + 1] = mm256_comp_i64 ( face_v1, ilane );
            geom_out->f2[ ( iface + ilane ) * 4 + 1] = mm256_comp_i64 ( face_v4, ilane );

            geom_out->f0[ ( iface + ilane ) * 4 + 2] = mm256_comp_i64 ( face_v4, ilane );
            geom_out->f1[ ( iface + ilane ) * 4 + 2] = mm256_comp_i64 ( face_v2, ilane );
            geom_out->f2[ ( iface + ilane ) * 4 + 2] = mm256_comp_i64 ( face_v5, ilane );

            geom_out->f0[ ( iface + ilane ) * 4 + 3] = mm256_comp_i64 ( face_v4, ilane );
            geom_out->f1[ ( iface + ilane ) * 4 + 3] = mm256_comp_i64 ( face_v5, ilane );
            geom_out->f2[ ( iface + ilane ) * 4 + 3] = mm256_comp_i64 ( face_v3, ilane );
        }
    }

    mem_stack_decr ( face_v3_addr_buf );
    mem_stack_decr ( face_v4_addr_buf );
    mem_stack_decr ( face_v5_addr_buf );

    if ( !mesh_out ) {
        return 1;
    }

    mesh_build ( mesh_out, geom_out );

    // Rebuilding the mesh can be done without the map, using knownledge on the subdivision scheme
    // but I am stuck debugging this block of code before even trying a vector version
#if 0

    // Knowing the subdivision operator the connectivity data can be rebuilt without using external memory.
    // Each edge is split in 2 and 3 more edges are inserted in the middle of the face. Edge indices are
    // remapped to 3 * old-index (*2 half-edges).
    // The per-face data is expanded edge by edge to 4 * old-index
    // (todo vectorize this)
    // the last number in the variable name is the half-edge/twin (+ flip usually) (the naming conventions are
    // in a bit of a local family
    for ( face_id iface = 0; iface < geom_in->n_faces; ++iface ) {
        // Getting indices for original face vertices and new edge vertices
        const edge_id old_e0 = mesh->face_edge0[iface] >> 1;
        const edge_id old_e1 = mesh->face_edge1[iface] >> 1;
        const edge_id old_e2 = mesh->face_edge2[iface] >> 1;

        if ( mesh->face_edge0[iface] == 50 && mesh->face_edge1[iface] == 1 && mesh->face_edge2[iface] == 52 ) {
            printf ( "moo" );
        }

        io_msg ( "reading face edges (%llu %llu %llu)\n", mesh->face_edge0[iface], mesh->face_edge1[iface], mesh->face_edge2[iface] );

        const vertex_id v0 = geom_in->f0[iface];
        const vertex_id v1 = geom_in->f1[iface];
        const vertex_id v2 = geom_in->f2[iface];
        const vertex_id v01 = geom_in->n_vertices + old_e0;
        const vertex_id v12 = geom_in->n_vertices + old_e1;
        const vertex_id v20 = geom_in->n_vertices + old_e2;

        // Original face vertices are split into * 2 edges
        const uint64_t map_00_base = 0;
        const uint64_t map_01_base = 2;
        const uint64_t map_f0_base = 4;
        const uint64_t map_f1_base = 6;

        const edge_id he00 = ( old_e0 * 8 ) + map_00_base + ( v0 > v01 ? 1 : 0 );
        const edge_id he01 = ( old_e0 * 8 ) + map_01_base + ( v01 > v1 ? 1 : 0 );
        const edge_id he10 = ( old_e1 * 8 ) + map_00_base + ( v1 > v12 ? 1 : 0 );
        const edge_id he11 = ( old_e1 * 8 ) + map_01_base + ( v12 > v2 ? 1 : 0 );
        const edge_id he20 = ( old_e2 * 8 ) + map_00_base + ( v2 > v20 ? 1 : 0 );
        const edge_id he21 = ( old_e2 * 8 ) + map_01_base + ( v20 > v0 ? 1 : 0 );

        const int f0_offset = v0 > v1 ? map_f1_base : map_f0_base;
        const int f1_offset = v1 > v2 ? map_f1_base : map_f0_base;
        const int f2_offset = v2 > v0 ? map_f1_base : map_f0_base;

        // Internal edges, i0 is the one opposite to the new edge between edges i j -> `heij`
        // +4 offset are the he** that were just caculated (only the half edges belonging to this face)
        const edge_id he01_12 = ( old_e0 * 8 ) + f0_offset + ( v01 > v12 ? 1 : 0 );
        const edge_id he12_01 = ( old_e0 * 8 ) + f0_offset + ( v01 < v12 ? 1 : 0 );
        const edge_id he12_20 = ( old_e1 * 8 ) + f1_offset + ( v12 > v20 ? 1 : 0 );
        const edge_id he20_12 = ( old_e1 * 8 ) + f1_offset + ( v12 < v20 ? 1 : 0 );
        const edge_id he20_01 = ( old_e2 * 8 ) + f2_offset + ( v20 > v01 ? 1 : 0 );
        const edge_id he01_20 = ( old_e2 * 8 ) + f2_offset + ( v20 < v01 ? 1 : 0 );

        // Face indices
        const face_id f_v0 = iface * 4 + 0; // Corner 0
        const face_id f_v1 = iface * 4 + 1; // Corner 1
        const face_id f_v2 = iface * 4 + 2; // Corner 2
        const face_id f_i = iface * 4 + 3; // Internal

#if 0
        io_msg ( "\nface %llu edges(%llu %llu %llu) vertices(%llu %llu %llu)\n", iface, old_e0, old_e1, old_e2, v0, v1, v2 );
        io_msg ( "face %llu: he00    %llu he01    %llu  he10 %llu    he11 %llu    he20 %llu    he21 %llu\n",
                 iface, he00, he01, he10, he11, he20, he21 );
        io_msg ( "face %llu: he01_12 %llu he12_01 %llu  he12_20 %llu he20_12 %llu he20_01 %llu he01_20 %llu\n",
                 iface, he01_12, he12_01, he12_20, he20_12, he20_01, he01_20 );
        io_msg ( "face %llu: f0(%llu %llu %llu) f1(%llu %llu %llu) f2(%llu %llu %llu)\n", iface,
                 he00, he01_20, he21, he01, he10, he12_01, he11, he20, he20_12, he12_20, he20_01, he01_12 );
#endif

        // Per-edge data
        mesh_out->edge_src[he00] = v0;
        mesh_out->edge_src[he01] = v01;
        mesh_out->edge_src[he10] = v1;
        mesh_out->edge_src[he11] = v12;
        mesh_out->edge_src[he20] = v2;
        mesh_out->edge_src[he21] = v20;

        mesh_out->edge_src[he01_12] = v01;
        mesh_out->edge_src[he12_20] = v12;
        mesh_out->edge_src[he20_01] = v20;

        mesh_out->edge_src[he12_01] = v12;
        mesh_out->edge_src[he20_12] = v20;
        mesh_out->edge_src[he01_20] = v01;

        mesh_out->edge_next[he00] = he01_20;
        mesh_out->edge_next[he01] = he10;
        mesh_out->edge_next[he10] = he12_01;
        mesh_out->edge_next[he11] = he20;
        mesh_out->edge_next[he20] = he20_12;
        mesh_out->edge_next[he21] = he00;

        mesh_out->edge_next[he01_12] = he12_20;
        mesh_out->edge_next[he12_20] = he20_01;
        mesh_out->edge_next[he20_01] = he01_12;

        mesh_out->edge_next[he12_01] = he01;
        mesh_out->edge_next[he20_12] = he11;
        mesh_out->edge_next[he01_20] = he21;

        mesh_out->edge_face[he00] = f_v0;
        mesh_out->edge_face[he01] = f_v1;
        mesh_out->edge_face[he10] = f_v1;
        mesh_out->edge_face[he11] = f_v2;
        mesh_out->edge_face[he20] = f_v2;
        mesh_out->edge_face[he21] = f_v0;

        mesh_out->edge_face[he20_01] = f_i;
        mesh_out->edge_face[he01_12] = f_i;
        mesh_out->edge_face[he12_20] = f_i;

        mesh_out->edge_face[he01_20] = f_v0;
        mesh_out->edge_face[he12_01] = f_v1;
        mesh_out->edge_face[he20_12] = f_v2;

        // Per-face data (filling half-edges of internal to the face
        mesh_out->face_edge0[f_v0] = he00;
        mesh_out->face_edge1[f_v0] = he01_20;
        mesh_out->face_edge2[f_v0] = he21;
        geom_out->f0[f_v0] = v0;
        geom_out->f1[f_v0] = v01;
        geom_out->f2[f_v0] = v20;

        mesh_out->face_edge0[f_v1] = he01;
        mesh_out->face_edge1[f_v1] = he10;
        mesh_out->face_edge2[f_v1] = he12_01;
        geom_out->f0[f_v1] = v01;
        geom_out->f1[f_v1] = v1;
        geom_out->f2[f_v1] = v12;

        mesh_out->face_edge0[f_v2] = he11;
        mesh_out->face_edge1[f_v2] = he20;
        mesh_out->face_edge2[f_v2] = he20_12;
        geom_out->f0[f_v2] = v12;
        geom_out->f1[f_v2] = v2;
        geom_out->f2[f_v2] = v20;

        mesh_out->face_edge0[f_i] = he12_20;
        mesh_out->face_edge1[f_i] = he20_01;
        mesh_out->face_edge2[f_i] = he01_12;
        geom_out->f0[f_i] = v01;
        geom_out->f1[f_i] = v12;
        geom_out->f2[f_i] = v20;
    }

    for ( face_id iface = 0; iface < geom_out->n_faces; ++iface ) {
        io_msg ( "face edges (%llu %llu %llu)\n",
                 mesh_out->face_edge0[iface], mesh_out->face_edge1[iface], mesh_out->face_edge2[iface] );
    }

#if 1 // terra_dev_debug

    for ( edge_id iedge = 0; iedge < geom_out->n_edges * 2; ++iedge ) {
        io_msg ( "%llu edge src: %llu next %llu face %llu\n", iedge, mesh_out->edge_src[iedge], mesh_out->edge_next[iedge],
                 mesh_out->edge_face[iedge] );
    }


    // Checking winding consistency
    for ( face_id iface = 0; iface < geom_out->n_faces; ++iface ) {
        const vertex_id v0 = mesh_out->face_edge0[iface];
        const vertex_id v1 = mesh_out->face_edge1[iface];
        const vertex_id v2 = mesh_out->face_edge2[iface];

        for ( face_id iface_other = 0; iface_other < geom_out->n_faces; ++iface_other ) {
            if ( iface == iface_other ) {
                continue;
            }

            const vertex_id v0_other = mesh_out->face_edge0[iface_other];
            const vertex_id v1_other = mesh_out->face_edge1[iface_other];
            const vertex_id v2_other = mesh_out->face_edge2[iface_other];

            assert_break ( ! ( v0 == v1_other && v0_other == v1 ) &&
                           ! ( v1 == v2_other && v1_other == v2 ) &&
                           ! ( v2 == v0_other && v2_other == v0 ) );
        }
    }

    // Checking half edges
    for ( face_id iface = 0; iface < geom_out->n_faces; ++iface ) {
        const edge_id edge0 = mesh_out->face_edge0[iface];
        const edge_id edge1 = mesh_out->face_edge1[iface];
        const edge_id edge2 = mesh_out->face_edge2[iface];
        const edge_id edge0_nx = mesh_out->edge_next[edge0];
        const edge_id edge1_nx = mesh_out->edge_next[edge1];
        const edge_id edge2_nx = mesh_out->edge_next[edge2];

        assert_break ( edge1 == edge0_nx );
        assert_break ( edge2 == edge1_nx );
        assert_break ( edge0 == edge2_nx );
    }

#endif
#endif

    return 1;
}

// Catmull clark subdivision (single-stream)
//--------------------------------------------------------------------------------------------------
/*
    This function implements the Catmull-clark subdivision scheme on quad meshes generating G^2 surfaces everywhere
    except at edge vertices neighboring a boundary where it's G^1. Triangular meshes are currently not supported.

    v'  ~ updated control point
    f   ~ new centroid face point
    e   ~ new edge point
    e_s ~ new sharp edge rule
    v_s ~ updated crease vertex (if < 3 sharp edges)
    v_c ~ updated corner vertex (if >= 3 sharp edges)

    Due to data dependencies, the computation requires 3 passes.

    for face:
        f = 1/k sum_i=0^k(corners)

    for edge
        e = 1/4 (f_rhs + f_lhs + e.src + e.dst)

    for regular vertex:
        v' = 2/3v + 1/36 sum_ring1(e) + 1/36 sum_ring1(f)

    (The following special update rules are performed in the same 3 passes)
    for boundary edge && sharp edge
        e_s = 1/2 (e.src + e.dst)
        (the new edges have sharpness - 1)

    for crease vertex:
        v_s = 1/8 (e_s + e_s + 6 * sum_nhbs())

    for corner vertex:
        v_c = v
*/
int mesh_subdiv_step_catmull_clark ( const Mesh* mesh, const Geometry* geom_in, Geometry* geom_out, Mesh* mesh_out ) {
    if ( geom_in->face_primitive == 3 ) {
        return 0;
    }

    // The vertices in the output mesh are stored contiguously
    // input: |v|
    // output: |v'|v_face|v_edge|
    // The face vertices are first computed using v, then the edges using the face vertices.
    // The updated even vertices v' are recalculated using the the old and new topology. In the first
    // two loops, the partial face and edge vertex sums are accumulated (the valence is known) in v'.
    // The new topology is calculated in the first loop as we are already looping over the faces.
    // It can be moved to its own loop to have less active memory at once.
    const vertex_id n_vertices_out = geom_in->n_vertices + geom_in->n_faces + geom_in->n_edges;
    const face_id n_faces_out = geom_in->n_faces * 4;
    const edge_id n_edges  = geom_in->n_edges * 2 + geom_in->n_faces * 4;
    geometry_create ( geom_out, n_vertices_out, n_faces_out, n_edges, 4 );
    memset ( geom_out->vx, 0, geom_out->n_vertices * real_size );
    memset ( geom_out->vy, 0, geom_out->n_vertices * real_size );
    memset ( geom_out->vz, 0, geom_out->n_vertices * real_size );

    const vertex_id vertex_face_base = geom_in->n_vertices;
    const vertex_id vertex_edge_base = geom_in->n_vertices + geom_in->n_faces;

#if terra_dev_debug
    io_msg ( "Input geometry vertices %llu faces %llu edges %llu\n",
             geom_in->n_vertices, geom_in->n_faces, geom_in->n_edges );

    io_msg ( "Output vertex_face_base %llu vertex_edge_base %llu\n",
             vertex_face_base, vertex_edge_base );
#endif

    vertex_id* corner0_buf = ( vertex_id* ) mem_stack_incr ( index_size * mm_lanes_32 );
    vertex_id* corner1_buf = ( vertex_id* ) mem_stack_incr ( index_size * mm_lanes_32 );
    vertex_id* corner2_buf = ( vertex_id* ) mem_stack_incr ( index_size * mm_lanes_32 );
    vertex_id* corner3_buf = ( vertex_id* ) mem_stack_incr ( index_size * mm_lanes_32 );
    __m256 corners[4];

    // Averaging even face's corners to create v_face. Then splitting every face in 4 faces around the same point
    for ( face_id iface = 0; iface < geom_in->n_faces; iface += mm_lanes_32 ) {
        // Gathering all the face corners (from the source edges)
        int lanes = 0;

        for ( int ilane = 0; ilane < mm_lanes_32; ++ilane ) {
            const int mask = iface + ilane >= geom_in->n_faces;
            corner0_buf[ilane] = mask ? mm_addr_mask : mesh_edge_src ( mesh_face_edge0 ( iface + ilane ) );
            corner1_buf[ilane] = mask ? mm_addr_mask : mesh_edge_src ( mesh_face_edge1 ( iface + ilane ) );
            corner2_buf[ilane] = mask ? mm_addr_mask : mesh_edge_src ( mesh_face_edge2 ( iface + ilane ) );
            corner3_buf[ilane] = mask ? mm_addr_mask : mesh_edge_src ( mesh_face_edge3 ( iface + ilane ) );
        }

        // Averaging face corners and storing partial sum in corners
        const uint64_t vf_base = vertex_face_base + iface;
        const __mmask8 vf_write_mask = mm256_mask_32 ( iface, geom_in->n_faces );

        // ~x
        corners[0] = mm256_gather_f32 ( geom_in->vx, corner0_buf );
        corners[1] = mm256_gather_f32 ( geom_in->vx, corner1_buf );
        corners[2] = mm256_gather_f32 ( geom_in->vx, corner2_buf );
        corners[3] = mm256_gather_f32 ( geom_in->vx, corner3_buf );
        const __m256 vface_x = mm256_add_scale ( corners, 4, .25f );
        mm256_store_mask ( geom_out->vx + vf_base, vface_x, vf_write_mask );

        // ~y
        corners[0] = mm256_gather_f32 ( geom_in->vy, corner0_buf );
        corners[1] = mm256_gather_f32 ( geom_in->vy, corner1_buf );
        corners[2] = mm256_gather_f32 ( geom_in->vy, corner2_buf );
        corners[3] = mm256_gather_f32 ( geom_in->vy, corner3_buf );
        const __m256 vface_y = mm256_add_scale ( corners, 4, .25f );
        mm256_store_mask ( geom_out->vy + vf_base, vface_y, vf_write_mask );

        // ~z
        corners[0] = mm256_gather_f32 ( geom_in->vz, corner0_buf );
        corners[1] = mm256_gather_f32 ( geom_in->vz, corner1_buf );
        corners[2] = mm256_gather_f32 ( geom_in->vz, corner2_buf );
        corners[3] = mm256_gather_f32 ( geom_in->vz, corner3_buf );
        const __m256 vface_z = mm256_add_scale ( corners, 4, .25f );
        mm256_store_mask ( geom_out->vz + vf_base, vface_z, vf_write_mask );

        // The exploded gather/scatter version was freaking unreadable and undebuggable (is any of this **really** debuggable?,
        // I have caught more errors noticing typos in row/cols than stepping through the code
        for ( int ilane = 0; ilane < mm_lanes_32; ++ilane ) {
            if ( iface + ilane >= geom_in->n_faces ) {
                break;
            }

            geom_out->vx[corner0_buf[ilane]] += geom_out->vx[vertex_face_base + iface + ilane];
            geom_out->vx[corner1_buf[ilane]] += geom_out->vx[vertex_face_base + iface + ilane];
            geom_out->vx[corner2_buf[ilane]] += geom_out->vx[vertex_face_base + iface + ilane];
            geom_out->vx[corner3_buf[ilane]] += geom_out->vx[vertex_face_base + iface + ilane];

            geom_out->vy[corner0_buf[ilane]] += geom_out->vy[vertex_face_base + iface + ilane];
            geom_out->vy[corner1_buf[ilane]] += geom_out->vy[vertex_face_base + iface + ilane];
            geom_out->vy[corner2_buf[ilane]] += geom_out->vy[vertex_face_base + iface + ilane];
            geom_out->vy[corner3_buf[ilane]] += geom_out->vy[vertex_face_base + iface + ilane];

            geom_out->vz[corner0_buf[ilane]] += geom_out->vz[vertex_face_base + iface + ilane];
            geom_out->vz[corner1_buf[ilane]] += geom_out->vz[vertex_face_base + iface + ilane];
            geom_out->vz[corner2_buf[ilane]] += geom_out->vz[vertex_face_base + iface + ilane];
            geom_out->vz[corner3_buf[ilane]] += geom_out->vz[vertex_face_base + iface + ilane];
        }

#if terra_dev_debug
        io_msg ( "block %d mask %d\n", iface, vf_write_mask );

        for ( int ilane = 0; ilane < mm_lanes_32; ++ilane ) {
            io_msg ( "Writing vertex %.5f %.5f %.5f mask\n",
                     geom_out->vx[vf_base + ilane], geom_out->vy[vf_base + ilane], geom_out->vz[vf_base + ilane] );
            io_msg ( "Face partial c0(%.5f %.5f %.5f %.5f) c1(%.5f %.5f %.5f %.5f) c2(%.5f %.5f %.5f %.5f)\n",
                     geom_out->vx[corner0_buf[ilane]], geom_out->vy[corner0_buf[ilane]], geom_out->vz[corner0_buf[ilane]],
                     geom_out->vx[corner1_buf[ilane]], geom_out->vy[corner1_buf[ilane]], geom_out->vz[corner1_buf[ilane]],
                     geom_out->vx[corner2_buf[ilane]], geom_out->vy[corner2_buf[ilane]], geom_out->vz[corner2_buf[ilane]],
                     geom_out->vx[corner3_buf[ilane]], geom_out->vy[corner3_buf[ilane]], geom_out->vz[corner3_buf[ilane]] );
        }

#endif

        // For a face where
        // c0, c1, c2, c3 are the corner vertices
        // e0, e1, e2, e3 are the edge vertices (e0 between c0-c1, etc..)
        // f is the face vertex
        // The new topology that is generated is (winding direction is ascending 0..3)
        // | c0 | e0 | f | e3
        // | c1 | e1 | f | e0
        // | c2 | e2 | f | e1
        // | c3 | e3 | f | e2
        // which can be stored nicely vertically
        // face0: c0 c1 c2 c3
        // face1: e0 e1 e2 e3
        // face2: f f f f
        // face3: e3 e0 e1 e2
        // face0 is stored in the corner_buf, face1 is known, face2 is constant and face3 is
        // obtained with a circular shift/shuffle on face1. A shuffle should be cheaper as it's
        // just 1 cycle (todo this can probably be simd'd better, but it doesn't require any masking!)
        for ( int ilane = 0; ilane < mm_lanes_32; ++ilane ) {
            if ( iface + ilane >= geom_in->n_faces ) {
                break;
            }

            const vertex_id iedge = iface + ilane;
            const face_id   fw_base   = ( iface + ilane ) * mm_lanes_64;

            const __m256i face0 = _mm256_set_epi64x ( corner3_buf[ilane], corner2_buf[ilane], corner1_buf[ilane], corner0_buf[ilane] );
            const __m256i face1 = _mm256_set_epi64x ( vertex_edge_base + ( mesh->face_edge3[iedge] >> 1 ), vertex_edge_base + ( mesh->face_edge2[iedge] >> 1 ),
                                                      vertex_edge_base + ( mesh->face_edge1[iedge] >> 1 ), vertex_edge_base + ( mesh->face_edge0[iedge] >> 1 ) );
            const __m256i face2 = _mm256_set1_epi64x ( vertex_face_base + iface + ilane );
            const __m256i face3 = mm256_swizzle_wxyz ( face1 );

            _mm256_store_si256 ( _tcast ( __m256i*, geom_out->f0 + fw_base ), face0 );
            _mm256_store_si256 ( _tcast ( __m256i*, geom_out->f1 + fw_base ), face1 );
            _mm256_store_si256 ( _tcast ( __m256i*, geom_out->f2 + fw_base ), face2 );
            _mm256_store_si256 ( _tcast ( __m256i*, geom_out->f3 + fw_base ), face3 );

#if terra_dev_debug
            io_msg ( "New faces (%d) (%lld %lld %lld %lld)\n"
                     "\t(%lld %lld %lld  %lld)\n"
                     "\t(%lld %lld %lld  %lld)\n"
                     "\t(%lld %lld %lld  %lld)\n"
                     "\t(%lld %lld %lld  %lld)\n", ilane, corner0_buf[ilane], corner1_buf[ilane], corner2_buf[ilane], corner3_buf[ilane],
                     geom_out->f0[fw_base + 0], geom_out->f1[fw_base + 0], geom_out->f2[fw_base + 0], geom_out->f3[fw_base + 0],
                     geom_out->f0[fw_base + 1], geom_out->f1[fw_base + 1], geom_out->f2[fw_base + 1], geom_out->f3[fw_base + 1],
                     geom_out->f0[fw_base + 2], geom_out->f1[fw_base + 2], geom_out->f2[fw_base + 2], geom_out->f3[fw_base + 2],
                     geom_out->f0[fw_base + 3], geom_out->f1[fw_base + 3], geom_out->f2[fw_base + 3], geom_out->f3[fw_base + 3] );
#endif
        }
    }

    mem_stack_decr ( corner0_buf );
    mem_stack_decr ( corner1_buf );
    mem_stack_decr ( corner2_buf );
    mem_stack_decr ( corner3_buf );

    // Calculating edge vertices, which require the source/destination of the current edge, as well as the
    // previously computed edge vertices
    vertex_id* esrc_buf = ( vertex_id* ) mem_stack_incr ( index_size * mm_lanes_32 );
    vertex_id* edst_buf = ( vertex_id* ) mem_stack_incr ( index_size * mm_lanes_32 );
    vertex_id* fsrc_buf = ( vertex_id* ) mem_stack_incr ( index_size * mm_lanes_32 );
    vertex_id* fdst_buf = ( vertex_id* ) mem_stack_incr ( index_size * mm_lanes_32 );

    for ( edge_id iedge = 0; iedge < geom_in->n_edges; iedge += mm_lanes_32 ) {
        // Storing vertex edges consecutively
        for ( int ilane = 0; ilane < mm_lanes_32; ++ilane ) {
            const int mask = iedge + ilane >= geom_in->n_edges;
            esrc_buf[ilane] = mask ? mm_addr_mask : mesh_edge_src ( mesh_hedge0 ( iedge + ilane ) );
            edst_buf[ilane] = mask ? mm_addr_mask : mesh_edge_src ( mesh_hedge1 ( iedge + ilane ) );
            fsrc_buf[ilane] = mask ? mm_addr_mask : vertex_face_base + mesh_edge_face ( mesh_hedge0 ( iedge + ilane ) );
            fdst_buf[ilane] = mask ? mm_addr_mask : vertex_face_base + mesh_edge_face ( mesh_hedge1 ( iedge + ilane ) );
        }

        const uint64_t ve_base = vertex_edge_base + iedge;
        const __mmask8 write_mask = mm256_mask_32 ( iedge, geom_in->n_edges );
        const __m256 average = _mm256_set1_ps ( .25f );

        // ~x
        const __m256 vsrc_face_x = mm256_gather_f32 ( geom_out->vx, fsrc_buf );
        const __m256 vdst_face_x = mm256_gather_f32 ( geom_out->vx, fdst_buf );
        const __m256 vsrc_edge_x  = mm256_gather_f32 ( geom_in->vx, esrc_buf );
        const __m256 vdst_edge_x  = mm256_gather_f32 ( geom_in->vx, edst_buf );
        const __m256 vface_sum_x = _mm256_add_ps ( vsrc_face_x, vdst_face_x );
        const __m256 vedge_sum_x = _mm256_add_ps ( vsrc_edge_x, vdst_edge_x );
        const __m256 vedge_x = _mm256_mul_ps ( _mm256_add_ps ( vface_sum_x, vedge_sum_x ), average );
        mm256_store_mask ( geom_out->vx + ve_base, vedge_x, write_mask );

        // ~y
        const __m256 vsrc_face_y = mm256_gather_f32 ( geom_out->vy, fsrc_buf );
        const __m256 vdst_face_y = mm256_gather_f32 ( geom_out->vy, fdst_buf );
        const __m256 vsrc_edge_y = mm256_gather_f32 ( geom_in->vy, esrc_buf );
        const __m256 vdst_edge_y = mm256_gather_f32 ( geom_in->vy, edst_buf );
        const __m256 vface_sum_y = _mm256_add_ps ( vsrc_face_y, vdst_face_y );
        const __m256 vedge_sum_y = _mm256_add_ps ( vsrc_edge_y, vdst_edge_y );
        const __m256 vedge_y = _mm256_mul_ps ( _mm256_add_ps ( vface_sum_y, vedge_sum_y ), average );
        mm256_store_mask ( geom_out->vy + ve_base, vedge_y, write_mask );

        // ~z
        const __m256 vsrc_face_z = mm256_gather_f32 ( geom_out->vz, fsrc_buf );
        const __m256 vdst_face_z = mm256_gather_f32 ( geom_out->vz, fdst_buf );
        const __m256 vsrc_edge_z = mm256_gather_f32 ( geom_in->vz, esrc_buf );
        const __m256 vdst_edge_z = mm256_gather_f32 ( geom_in->vz, edst_buf );
        const __m256 vface_sum_z = _mm256_add_ps ( vsrc_face_z, vdst_face_z );
        const __m256 vedge_sum_z = _mm256_add_ps ( vsrc_edge_z, vdst_edge_z );
        const __m256 vedge_z = _mm256_mul_ps ( _mm256_add_ps ( vface_sum_z, vedge_sum_z ), average );
        mm256_store_mask ( geom_out->vz + ve_base, vedge_z, write_mask );

        for ( int ilane = 0; ilane < mm_lanes_32; ++ilane ) {
            if ( iedge + ilane >= geom_in->n_edges ) {
                break;
            }

            geom_out->vx[esrc_buf[ilane]] += geom_out->vx[vertex_edge_base + iedge + ilane];
            geom_out->vx[edst_buf[ilane]] += geom_out->vx[vertex_edge_base + iedge + ilane];

            geom_out->vy[esrc_buf[ilane]] += geom_out->vy[vertex_edge_base + iedge + ilane];
            geom_out->vy[edst_buf[ilane]] += geom_out->vy[vertex_edge_base + iedge + ilane];

            geom_out->vz[esrc_buf[ilane]] += geom_out->vz[vertex_edge_base + iedge + ilane];
            geom_out->vz[edst_buf[ilane]] += geom_out->vz[vertex_edge_base + iedge + ilane];
        }

#if terra_dev_debug

        for ( int ilane = 0; ilane < mm_lanes_32; ++ilane ) {
            if ( iedge + ilane >= geom_in->n_edges ) {
                break;
            }

            io_msg ( "Edge partial c0(%.5f %.5f %.5f %.5f) c1(%.5f %.5f %.5f %.5f) c2(%.5f %.5f %.5f %.5f)\n",
                     geom_out->vx[esrc_buf[ilane]], geom_out->vy[esrc_buf[ilane]], geom_out->vz[esrc_buf[ilane]],
                     geom_out->vx[edst_buf[ilane]], geom_out->vy[edst_buf[ilane]], geom_out->vz[edst_buf[ilane]] );
        }

#endif
    }

#if terra_dev_debug

    for ( vertex_id ivertex = 0; ivertex < geom_in->n_vertices; ++ivertex ) {
        io_msg ( "Vertex valences %llu\n", mesh->vertex_flags[ivertex].valence );
    }

#endif

    mem_stack_decr ( fsrc_buf );
    mem_stack_decr ( fdst_buf );
    mem_stack_decr ( esrc_buf );
    mem_stack_decr ( edst_buf );

    // Reweighting even vertices
    float weight_k_valences[2];
    weight_k_valences[0] = 1.f / 3;
    weight_k_valences[1] = 2.f / 4;

    float weight_kk_valences[2];
    weight_kk_valences[0] =  1.f / ( 3 * 3 );
    weight_kk_valences[1] =  1.f / ( 4 * 4 );

    float weights_old_buf[mm_lanes_32];
    float weights_partial_buf[mm_lanes_32];

    for ( vertex_id ivertex = 0; ivertex < geom_in->n_vertices; ivertex += mm_lanes_32 ) {
        for ( int ilane = 0; ilane < mm_lanes_32; ++ilane ) {
            if ( ivertex + ilane >= geom_in->n_vertices ) {
                break;
            }

            weights_partial_buf[ilane] = weight_kk_valences[mesh->vertex_flags[ivertex + ilane].valence - 3];
            weights_old_buf[ilane] = weight_k_valences[mesh->vertex_flags[ivertex + ilane].valence - 3];
        }

        const __mmask8 write_mask = mm256_mask_32 ( ivertex, geom_in->n_vertices );
        const __m256 weights_old = _mm256_loadu_ps ( weights_old_buf );
        const __m256 weights_partial = _mm256_loadu_ps ( weights_partial_buf );

        // ~x
        const __m256 veven_old_x = _mm256_load_ps ( geom_in->vx + ivertex );
        const __m256 veven_partial_x = _mm256_load_ps ( geom_out->vx + ivertex );
        const __m256 veven_new_x = _mm256_add_ps ( _mm256_mul_ps ( weights_old, veven_old_x ),
                                                   _mm256_mul_ps ( weights_partial, veven_partial_x ) );
        mm256_store_mask ( geom_out->vx + ivertex, veven_new_x, write_mask );

        // ~y
        const __m256 veven_old_y = _mm256_load_ps ( geom_in->vy + ivertex );
        const __m256 veven_partial_y = _mm256_load_ps ( geom_out->vy + ivertex );
        const __m256 veven_new_y = _mm256_add_ps ( _mm256_mul_ps ( weights_old, veven_old_y ),
                                                   _mm256_mul_ps ( weights_partial, veven_partial_y ) );
        mm256_store_mask ( geom_out->vy + ivertex, veven_new_y, write_mask );

        // ~x
        const __m256 veven_old_z = _mm256_load_ps ( geom_in->vz + ivertex );
        const __m256 veven_partial_z = _mm256_load_ps ( geom_out->vz + ivertex );
        const __m256 veven_new_z = _mm256_add_ps ( _mm256_mul_ps ( weights_old, veven_old_z ),
                                                   _mm256_mul_ps ( weights_partial, veven_partial_z ) );
        mm256_store_mask ( geom_out->vz + ivertex, veven_new_z, write_mask );
    }

    if ( mesh_out ) {
        memset ( mesh_out, 0, sizeof ( Mesh ) );
        mesh_build ( mesh_out, geom_out );
    }

    return 1;
}

// Iterative versions of the subdivision_step functions
//--------------------------------------------------------------------------------------------------
int mesh_subdiv_iter_loop ( const Geometry* geom_base, Geometry* geom_ret, int iterations ) {
    if ( !geom_ret || !geom_base || !iterations ) {
        return 0;
    }

    Geometry geom_in = *geom_base;
    Geometry geom_out;
    Mesh mesh_in = { 0 }, mesh_out = { 0 };

    mesh_build ( &mesh_in, &geom_in );

    while ( iterations-- > 0 ) {
        int ret = mesh_subdiv_step_loop ( &mesh_in, &geom_in, &geom_out, &mesh_out );
        fprintf ( stderr, "Finished iteration vertices %llu -> %llu\n", geom_in.n_vertices, geom_out.n_vertices );

        mesh_free ( &mesh_in );

        if ( geom_in.vx != geom_base->vx ) {
            geometry_free ( &geom_in );
        }

        memcpy ( &geom_in, &geom_out, sizeof ( Geometry ) );
        memcpy ( &mesh_in, &mesh_out, sizeof ( Mesh ) );
    }

    *geom_ret = geom_out;

    return 1;
}

//--------------------------------------------------------------------------------------------------
int mesh_subdiv_iter_catmull_clark ( const Geometry* geom_base, Geometry* geom_ret, int iterations ) {
    if ( !geom_ret || !geom_base || !iterations ) {
        return 0;
    }

    Geometry geom_in = *geom_base;
    Geometry geom_out;
    Mesh mesh_in = { 0 }, mesh_out;

    mesh_build ( &mesh_in, &geom_in );

    while ( iterations-- > 0 ) {
        int ret = mesh_subdiv_step_catmull_clark ( &mesh_in, &geom_in, &geom_out, &mesh_out );
        fprintf ( stderr, "Finished iteration vertices %llu -> %llu\n", geom_in.n_vertices, geom_out.n_vertices );

        mesh_free ( &mesh_in );

        if ( geom_in.vx != geom_base->vx ) {
            geometry_free ( &geom_in );
        }

        memcpy ( &geom_in, &geom_out, sizeof ( Geometry ) );
        memcpy ( &mesh_in, &mesh_out, sizeof ( Mesh ) );
    }

    *geom_ret = geom_out;

    return 1;
}
