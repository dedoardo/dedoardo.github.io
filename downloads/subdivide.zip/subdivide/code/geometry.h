#ifndef _terra_geometry_h_
#define _terra_geometry_h_

// Terra
#include "cpu.h"
#include "simd.h"

#ifndef terra_simd_avx2
    #error
#endif

// libc
#include <stdint.h>

// Primitive types
typedef uint64_t vertex_id;
typedef uint64_t face_id;
typedef uint64_t edge_id;
typedef uint32_t vertex_tag_t;
#define vertex_id_null ((vertex_id)(~0))
#define edge_id_null ((edge_id)(~0))
#define face_id_null ((face_id)(~0))
#define vertex_size (sizeof(vec3f))
#define face_size (sizeof(vec4i64))
#define real_size (sizeof(float))
#define index_size (sizeof(vertex_id))
#define index_null ((uint64_t)~0)

// Data structures
//--------------------------------------------------------------------------------------------------
#pragma pack(push, 1)

// todo: make hybrid soa with interleaved x/y/z/w in a single linear buffer, as it should keep only one
// cache line busy, rather than one for each coordinate [Intel x86].
typedef struct _Geometry {
    float*    vx;
    float*    vy;
    float*    vz;
    int64_t*  f0;
    int64_t*  f1;
    int64_t*  f2;
    int64_t*  f3;
    vertex_id n_vertices;
    face_id   n_faces;
    edge_id   n_edges;
    uint64_t  face_primitive : 4;
    uint64_t  closed : 1;
    uint64_t  open : 1;
    uint64_t  unused : 28;
} Geometry;

typedef struct _VertexFlag {
    uint64_t valence : 63;
    uint64_t boundary : 1;
} VertexFlag;

// Connectivity data (SoA) storing each face as a list of edges and for
// each edge the src/dst vertices as well as the adjacent faces are stored.
// Space occupied is O(|E| + |F|). The faces in Geometry could be freed and reconstructed
// at the end of any algorithm if needed (It's an API hassle though..)
// The next is encoded by storing twin half edges consecutively (odd/even address)
// **note** One edge per face is perfectly enough, it only requires a few extra gather instructions
// it would save a lot of memory though..
// As mr. chain rule gently pointed out, storing the faces is not necessary, but the ability to linearly
// loop through the edges results in simpler code with linear stores and scalar gathers, without having
// to store extra informations or perform more redirections that necessary (it could be faster though todo)
typedef struct _Mesh {
    edge_id*    face_edge0;
    edge_id*    face_edge1;
    edge_id*    face_edge2;
    edge_id*    face_edge3;
    vertex_id*  edge_src;
    face_id*    edge_face;
    edge_id*    edge_next;
    VertexFlag* vertex_flags;
} Mesh;
#define mesh_hedge0(iedge) (((iedge) << 1) + 0)
#define mesh_hedge1(iedge) (((iedge) << 1) + 1)
#define mesh_edge(ihedge) ((ihedge) >> 1)
#define mesh_edge_src(expr) (mesh->edge_src[(expr)])
#define mesh_edge_next(expr) (mesh->edge_next[(expr)])
#define mesh_edge_face(expr) (mesh->edge_face[(expr)])
#define mesh_edge_to_vertex(expr) (geom_in->n_vertices + ((expr) >> 1))
#define mesh_face_edge0(expr) (mesh->face_edge0[(expr)])
#define mesh_face_edge1(expr) (mesh->face_edge1[(expr)])
#define mesh_face_edge2(expr) (mesh->face_edge2[(expr)])
#define mesh_face_edge3(expr) (mesh->face_edge3[(expr)])

// Geometry-only routines
void geometry_create ( Geometry* geometry, vertex_id n_vertices, face_id n_faces, edge_id n_edges, int face_primitive );
void geometry_resize ( Geometry* geometry, vertex_id n_vertices, face_id n_faces );
void geometry_free   ( Geometry* geometry );

void  geometry_calc_aa_bounds  ( const Geometry* geometry, vec4f* bounds_min, vec4f* bounds_max );
vec4f geometry_calc_com        ( const Geometry* geometry );
void  geometry_move_to_origin  ( Geometry* geometry );
vec4f geometry_scale_to_unit   ( Geometry* geometry );

void mesh_create    ( Mesh* mesh, const Geometry* geometry );
int  mesh_build     ( Mesh* mesh, const Geometry* geometry );
void mesh_free      ( Mesh* mesh );

// Single-stream subdivision
int mesh_subdiv_step_loop          ( const Mesh* mesh, const Geometry* geom_in, Geometry* geom_out, Mesh* mesh_out );
int mesh_subdiv_step_catmull_clark ( const Mesh* mesh, const Geometry* geom_in, Geometry* geom_out, Mesh* mesh_out );
int mesh_subdiv_iter_loop          ( const Geometry* geom_in, Geometry* geom_out, int iterations );
int mesh_subdiv_iter_catmull_clark ( const Geometry* geom_in, Geometry* geom_out, int iterations );

#pragma pack(pop)

#endif // _terra_geometry_h_