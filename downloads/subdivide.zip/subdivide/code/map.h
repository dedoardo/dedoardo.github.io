#ifndef _terra_map_h_
#define _terra_map_h_

// terra
#include "cpu.h"

// libc
#include <stdint.h>
#include <string.h> // memset
#include <stdio.h> // todo: remove 

#define map_capacity_grow_rate 0.66

typedef uint64_t map_hash_t;

typedef struct _map_t {
    map_hash_t* hash;
    uint8_t*    keys;
    uint8_t*    values;
    uint64_t    capacity;
    uint64_t    occupancy;
    uint64_t    key_size;
    uint64_t    value_size;
#if terra_dev_debug
    uint64_t access_acc;
    uint64_t access_count;
    uint64_t insert_count;
    uint64_t remove_count;
#endif
} map_t;

map_hash_t map_hash       ( const void* buf, size_t len );
uint64_t   map_hash_idx   ( const map_t* map, const map_hash_t hash );
void       map_create     ( map_t* map, uint64_t key_size, uint64_t value_size, uint64_t capacity );
void       map_make_space ( map_t* map, uint64_t occupancy_incr );
void       map_free       ( map_t* map );
void*      map_add_key    ( map_t* map, const void* key );
void*      map_add        ( map_t* map, const void* key, const void* value );
void       map_remove     ( map_t* map, const void* key );
void*      map_find       ( map_t* map, const void* key );

// MongoDB's FNV1a implementation
terra_inline map_hash_t map_hash ( const void* buf, size_t len ) {
    uint64_t hval = ( uint64_t ) 0xcbf29ce484222325ULL;
    const unsigned char* bp = ( const unsigned char* ) buf; /* start of buffer */
    const unsigned char* be = bp + len; /* beyond end of buffer */

    while ( bp < be ) {
        hval ^= ( uint64_t ) * bp++;
        hval += ( hval << 1 ) + ( hval << 4 ) + ( hval << 5 ) +
                ( hval << 7 ) + ( hval << 8 ) + ( hval << 40 );
    }

    return ( hval );
}

terra_inline uint64_t map_hash_idx ( const map_t* map, const map_hash_t hash ) {
    return hash & ( map->capacity - 1 );
}

terra_inline void map_create ( map_t* map, uint64_t key_size, uint64_t value_size, uint64_t capacity ) {
    map->hash = terra_amalloc ( sizeof ( map_hash_t ) * capacity );
    map->keys = terra_amalloc ( key_size * capacity );
    map->values = terra_amalloc ( value_size * capacity );
    map->capacity = capacity;
    map->key_size = key_size;
    map->value_size = value_size;
    map->occupancy = 0;

#if terra_dev_debug
    map->access_acc = 0;
    map->access_count = 0;
    map->insert_count = 0;
    map->remove_count = 0;
#endif

    memset ( map->hash, 0, sizeof ( map_hash_t ) * capacity );
}

terra_inline void map_make_space ( map_t* map, uint64_t occupancy_incr ) {
    if ( map->occupancy + occupancy_incr > ( uint64_t ) ( map->capacity * map_capacity_grow_rate ) ) {
        assert_break ( occupancy_incr < map->capacity );

#if terra_dev_debug
        fprintf ( stderr, "--- reallocating %llu -> %llu ---\n", map->capacity, ( uint64_t ) ( map->capacity * map_capacity_grow_rate ) );
        fprintf ( stderr, "avg-find-length %10.5f\n", ( double ) map->access_acc / map->access_count );
        fprintf ( stderr, "map-insert counter %llu\n", map->insert_count );
        fprintf ( stderr, "map-remove counter %llu\n", map->remove_count );
#endif

        map_t new_map;
        map_create ( &new_map, map->key_size, map->value_size, map->capacity * 2 );

        for ( int idx = 0; idx < map->capacity; ++idx ) {
            if ( map->hash[idx] != 0x0 ) {
                void* value = map_add_key ( &new_map, map->keys + idx * map->key_size );
                memcpy ( value, map->values + idx * map->value_size, map->value_size );
            }
        }

        map_free ( map );
        memcpy ( map, &new_map, sizeof ( map_t ) );
    }
}

terra_inline void map_free ( map_t* map ) {
    terra_afree ( map->values );
    terra_afree ( map->keys );
    terra_afree ( map->hash );
}

terra_inline void* map_add_key ( map_t* map, const void* key ) {
    map_make_space ( map, 1 );

    map_hash_t hash = map_hash ( key, map->key_size );
    uint64_t hash_idx = map_hash_idx ( map, hash );

    for ( uint64_t i = 0; i < map->capacity; ++i ) {
        uint64_t idx = ( hash_idx + i ) & ( map->capacity - 1 );

        if ( map->hash[idx] == 0x0 ) {
            ++map->occupancy;
            map->hash[idx] = hash;
            memcpy ( map->keys + map->key_size * idx, key, map->key_size );
#if terra_dev_debug
            ++map->insert_count;
#endif

            return map->values + map->value_size * idx;
        }
    }

    return NULL;
}

terra_inline void* map_add ( map_t* map, const void* key, const void* value ) {
    void* value_ptr = map_add_key ( map, key );
    memcpy ( value_ptr, value, map->value_size );
    return value_ptr;
}

terra_inline void map_remove ( map_t* map, const void* key ) {
    map_hash_t hash = map_hash ( key, map->key_size );
    uint64_t hash_idx = map_hash_idx ( map, hash );

    for ( uint64_t i = 0; i < map->capacity; ++i ) {
        uint64_t idx = ( hash_idx + i ) & ( map->capacity - 1 );
        void* key_idx = map->keys + idx * map->key_size;
        void* value_idx = map->values + idx * map->value_size;

        if ( hash == map->hash[idx] && memcmp ( key_idx, key, map->key_size ) == 0 ) {
            map->hash[idx] = 0x0;
            memset ( key_idx, 0, map->key_size );
            memset ( value_idx, 0, map->value_size );
            --map->occupancy;
#if terra_dev_debug
            ++map->remove_count;
#endif

            return;
        }
    }

    // Key not found
    assert_break ( 0 );
}

terra_inline void* map_find ( map_t* map, const void* key ) {
    map_hash_t hash = map_hash ( key, map->key_size );
    uint64_t hash_idx = map_hash_idx ( map, hash );

    for ( uint64_t i = 0; i < map->capacity; ++i ) {
        uint64_t idx = ( hash_idx + i ) & ( map->capacity - 1 );
        const void* key_idx = map->keys + idx * map->key_size;

        if ( hash == map->hash[idx] && memcmp ( key_idx, key, map->key_size ) == 0 ) {
#if terra_dev_debug
            map->access_acc += i;
            ++map->access_count;
#endif

            return map->values + idx * map->value_size;
        }
    }

    return NULL;
}

#endif // _terra_map_h_