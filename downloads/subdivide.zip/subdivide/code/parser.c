// Header
#include "parser.h"
#include "map.h"
#include "geometry.h"

// libc
#include <stdio.h>
#include <ctype.h>

#define TINYOBJ_LOADER_C_IMPLEMENTATION
#include "tinyobj_loader_c.h"

typedef struct _edge_key_t {
    vertex_id src;
    vertex_id dst;
} edge_key_t;

terra_inline edge_key_t edge_key_make ( vertex_id vsrc, vertex_id vdst ) {
    assert_break ( vsrc != vdst );

    edge_key_t key;
    key.src = vsrc < vdst ? vsrc : vdst;
    key.dst = vsrc < vdst ? vdst : vsrc;
    return key;
}

#define shape_read_obj_line_buf 1024

//--------------------------------------------------------------------------------------------------
terra_inline int64_t str_2_i64 ( const char* str ) {
    int64_t val = 0;

    while ( *str && !isspace ( *str ) ) {
        val = val * 10 + ( *str++ - '0' );
    }

    return val;
}

//--------------------------------------------------------------------------------------------------
terra_inline float str_2_real ( const char* str ) {
    return ( float ) atof ( str );
}

//--------------------------------------------------------------------------------------------------
terra_inline char* skip_whitespaces ( char* str ) {
    while ( *str == ' ' || *str == '\t' ) {
        ++str;
    }

    return str;
}

//--------------------------------------------------------------------------------------------------
terra_inline char* skip_numbers ( char* str ) {
    while ( isdigit ( *str ) || *str == '.' || *str == '-' ) {
        ++str;
    }

    return str;
}

//--------------------------------------------------------------------------------------------------
terra_inline char* str_2_vec3f ( char* str, vec3f* vec ) {
    str = skip_whitespaces ( str );
    vec->x = str_2_real ( str );
    str = skip_numbers ( str );
    str = skip_whitespaces ( str );
    vec->y = str_2_real ( str );
    str = skip_numbers ( str );
    str = skip_whitespaces ( str );
    vec->z = str_2_real ( str );
    return skip_numbers ( str );
}

//--------------------------------------------------------------------------------------------------
terra_inline char* str_2_vec4f ( char* str, vec4f* vec ) {
    str = skip_whitespaces ( str );
    vec->x = str_2_real ( str );
    str = skip_numbers ( str );
    str = skip_whitespaces ( str );
    vec->y = str_2_real ( str );
    str = skip_numbers ( str );
    str = skip_whitespaces ( str );
    vec->z = str_2_real ( str );
    str = skip_numbers ( str );
    str = skip_whitespaces ( str );
    vec->w = str_2_real ( str );
    return skip_numbers ( str );
}

//--------------------------------------------------------------------------------------------------
terra_inline char* str_2_vec3i64 ( char* str, vec3i64* vec ) {
    str = skip_whitespaces ( str );
    vec->x = str_2_i64 ( str );
    str = skip_numbers ( str );
    str = skip_whitespaces ( str );
    vec->y = str_2_i64 ( str );
    str = skip_numbers ( str );
    str = skip_whitespaces ( str );
    vec->z = str_2_i64 ( str );
    return skip_numbers ( str );
}

//--------------------------------------------------------------------------------------------------
terra_inline char* str_2_vec4i64 ( char* str, vec4i64* vec ) {
    str = skip_whitespaces ( str );
    vec->x = str_2_i64 ( str );
    str = skip_numbers ( str );
    str = skip_whitespaces ( str );
    vec->y = str_2_i64 ( str );
    str = skip_numbers ( str );
    str = skip_whitespaces ( str );
    vec->z = str_2_i64 ( str );
    str = skip_numbers ( str );
    str = skip_whitespaces ( str );
    vec->w = str_2_i64 ( str );
    return skip_numbers ( str );
}

int terra_shape_read_obj ( const char* addr, struct _Geometry* geom ) {
    FILE* fp = fopen ( addr, "r" );

    if ( !fp ) {
        return 0;
    }

    fseek ( fp, 0, SEEK_END );
    size_t file_len = ( size_t ) ftell ( fp );
    fseek ( fp, 0, SEEK_SET );
    char* file_buf = terra_amalloc ( file_len + 1 );
    int bytes_read = fread ( file_buf, 1, file_len, fp );
    file_buf[file_len] = '\0';
    fclose ( fp );

    tinyobj_material_t* materials = NULL;
    tinyobj_shape_t* shapes = NULL;
    size_t n_materials, n_shapes;
    tinyobj_attrib_t attribs;
    int parse_ret = tinyobj_parse_obj ( &attribs, &shapes, &n_shapes, &materials, &n_materials, file_buf, file_len, 0x0 );

    if ( parse_ret != TINYOBJ_SUCCESS ) {
        fprintf ( stderr, "tinyobj parsing error %d\n", parse_ret );
        return 0;
    }

    geom->face_primitive = attribs.face_num_verts[0];
    uint64_t n_faces = attribs.num_faces / geom->face_primitive;
    geometry_create ( geom, attribs.num_vertices, n_faces, 0, 4 );
    int is_quad = 0x0;
    edge_id n_edges = 0;

    for ( int ivertex = 0; ivertex < attribs.num_vertices; ++ivertex ) {
        geom->vx[ivertex] = attribs.vertices[ivertex * 3 + 0];
        geom->vy[ivertex] = attribs.vertices[ivertex * 3 + 1];
        geom->vz[ivertex] = attribs.vertices[ivertex * 3 + 2];
    }

    if ( attribs.face_num_verts[0] == 3 ) {
        for ( int iface = 0; iface < n_faces; ++iface ) {
            geom->f0[iface] = attribs.faces[iface * 3 + 0].v_idx;
            geom->f1[iface] = attribs.faces[iface * 3 + 1].v_idx;
            geom->f2[iface] = attribs.faces[iface * 3 + 2].v_idx;
            n_edges += 3;
        }

        geom->face_primitive = 3;
    } else {
        for ( int iface = 0; iface < n_faces; ++iface ) {
            geom->f0[iface] = attribs.faces[iface * 4 + 0].v_idx;
            geom->f1[iface] = attribs.faces[iface * 4 + 1].v_idx;
            geom->f2[iface] = attribs.faces[iface * 4 + 2].v_idx;
            geom->f3[iface] = attribs.faces[iface * 4 + 3].v_idx;
            n_edges += 4;
        }

        geom->face_primitive = 4;
    }


    geom->n_edges = n_edges >> 1;

    terra_afree ( file_buf );
    tinyobj_shapes_free ( shapes, n_shapes );
    tinyobj_materials_free ( materials, n_materials );
    tinyobj_attrib_free ( &attribs );

    return 1;
}

#if 0
//--------------------------------------------------------------------------------------------------
// Reads a ascii obj file
int terra_shape_read_obj ( const char* addr, struct _Geometry* geom ) {
    FILE* fp = fopen ( addr, "r" );

    if ( !fp ) {
        return 0;
    }

    geometry_create ( geom, 4096, 4096, 0, 3 );
    vertex_id next_vertex = 0;
    face_id next_face = 0;

    char line_buf[shape_read_obj_line_buf];

    int flag_quad = 0x0;

    while ( fgets ( line_buf, shape_read_obj_line_buf, fp ) ) {
        char* r = line_buf;

        while ( *r == ' ' ) {
            ++r;
        }

        switch ( *r ) {
            case 'o': {
                // found object
                break;
            }

            case 's': {
                // smoothing group
                break;
            }

            case 'v': {
                vec3f vertex;
                str_2_vec3f ( r + 2, &vertex );

                if ( next_vertex == geom->n_vertices ) {
                    geometry_resize ( geom, geom->n_vertices * 2, geom->n_faces );
                }

                geom->vx[next_vertex] = vertex.x;
                geom->vy[next_vertex] = vertex.y;
                geom->vz[next_vertex] = vertex.z;
                ++next_vertex;
                break;
            }

            case 'f': {
                vec4i64 face;
                face.w = face_id_null;
                char* next = str_2_vec3i64 ( r + 2, _tcast ( vec3i64*, &face ) );
                --face.x;
                --face.y;
                --face.z;
                geom->n_edges += 3;
                assert_break ( face.x >= 0 && face.y >= 0 && face.z >= 0 );

                next = skip_whitespaces ( next );

                if ( isdigit ( *next ) || *next == '-' || *next == '+' ) {
                    face.w = str_2_i64 ( next + 1 );
                    --face.w;
                    ++geom->n_edges;
                    flag_quad = 0x1;
                } else {
                    assert_break ( geom->face_primitive == 3 );
                }

                if ( next_face == geom->n_faces ) {
                    geometry_resize ( geom, geom->n_vertices, geom->n_faces * 2 );
                }

                geom->f0[next_face] = face.x;
                geom->f1[next_face] = face.y;
                geom->f2[next_face] = face.z;

                if ( geom->face_primitive == 4 ) {
                    geom->f3[next_face] = face.w;
                }

                ++next_face;

                break;
            }

            default:
                break;
        }
    }

    geom->n_vertices = next_vertex;
    geom->n_faces = next_face;
    geom->n_edges /= 2;

    if ( flag_quad ) {
        geom->face_primitive = 4;
    } else {
        geom->face_primitive = 3;
    }

    return 1;
}

#endif

//--------------------------------------------------------------------------------------------------
// Writes an ascii obj file
int terra_shape_write_obj ( const char* addr, struct _Geometry* geom ) {
    FILE* fp = fopen ( addr, "w" );

    if ( !fp ) {
        return 0;
    }

    fprintf ( fp, "# Vertices %lld\n", geom->n_vertices );

    for ( vertex_id ivertex = 0; ivertex < geom->n_vertices; ++ivertex ) {
        fprintf ( fp, "v %f %f %f\n", geom->vx[ivertex], geom->vy[ivertex], geom->vz[ivertex] );
    }

    fprintf ( fp, "\n# Triangles %lld\n", geom->n_faces );

    for ( face_id iface = 0; iface < geom->n_faces; ++iface ) {
        if ( ! ( geom->face_primitive == 4 ) ) {
            fprintf ( fp, "f %lld %lld %lld\n", geom->f0[iface] + 1, geom->f1[iface] + 1, geom->f2[iface] + 1 );
        } else {
            fprintf ( fp, "f %lld %lld %lld %lld\n", geom->f0[iface] + 1, geom->f1[iface] + 1, geom->f2[iface] + 1, geom->f3[iface] + 1 );
        }
    }

    fclose ( fp );

    return 1;
}
