#ifndef _terra_format_h_
#define _terra_format_h_

//--------------------------------------------------------------------------------------------------
struct _Geometry;
struct _Texture;

int terra_shape_read_obj   ( const char* addr, struct _Geometry* geom );
int terra_shape_write_obj  ( const char* addr, struct _Geometry* geom );

#endif // _terra_format_h_