#ifndef _terra_math_simd_h_
#define _terra_math_simd_h_

// Terra
#include "cpu.h"

// Data structures
//--------------------------------------------------------------------------------------------------
// storage types (used to make it clear that we are using an array of 4 vectors)
// 1d
#pragma pack(push, 1)

typedef struct _vec2f {
    float x, y;
} vec2f;

typedef struct _vec3f {
    float x, y, z;
} vec3f;

typedef struct _vec4f {
    float x, y, z, w;
} vec4f;

typedef struct _vec8f {
    float v[8];
} vec8f;

typedef struct _vec4d {
    double x, y, z, w;
} vec4d;

typedef struct _vec4i32 {
    int32_t x, y, z, w;
} vec4i32;

typedef struct _vec3i64 {
    int64_t x, y, z;
} vec3i64;

typedef struct _vec4i64 {
    int64_t x, y, z, w;
} vec4i64;

// 2d
typedef struct _vec4x4f {
    vec4f rows[4];
} vec4x4f;

#pragma pack(pop)

// SIMD types
//--------------------------------------------------------------------------------------------------
// used only for declarations, use intrinsic types _m* for operations.
typedef __m128  mm_vec4f;
typedef __m128i mm_vec4i32;

#if terra_simd_avx2
    typedef __m256  mm_vec8f;
    typedef __m256d mm_vec4d;
    typedef __m256i mm_vec4i64;
#elif terra_simd_sse2
    typedef __m128  mm_vec4f;
    typedef vec8f   mm_vec8f;
    typedef vec4i64 mm_vec4i64;
#endif

#define mm_addr_mask ((uint64_t)(~0))
#define mm_l0 0x0
#define mm_l1 0x1
#define mm_l2 0x2
#define mm_l3 0x3
#define mm_l4 0x4
#define mm_l5 0x5
#define mm_l6 0x6
#define mm_l7 0x7

// Scalar routines
//--------------------------------------------------------------------------------------------------
void    fpu_set_precision_single();
void    fpu_set_precision_double();

uint32_t signf_mask  ( float v );
float    xorf        ( float _lhs, float _rhs );
void     swap_xorf   ( float* _a, float* _b );
void     swap_xori32 ( int32_t* a, int32_t* b );
void     swap_xori64 ( int64_t* a, int64_t* b );

vec2f   vec2f_set ( float x, float y );
vec3f   vec3f_set ( const float x, const float y, const float z );
vec3f   vec3f_data ( const float* vec3 );
vec4f   vec4f_set ( float x, float y, float z, float w );
vec4f   vec4f_zero ();
vec4i32 vec4i32_set ( uint32_t x, uint32_t y, uint32_t z, uint32_t w );
vec3i64 vec3i64_set ( int64_t x, int64_t y, int64_t z );

int   vec4f_max_comp ( const vec4f vec );
float vec4f_comp ( const vec4f vec, int idx );
vec4f vec4f_add ( const vec4f lhs, const vec4f rhs );
vec4f vec4f_sub ( const vec4f lhs, const vec4f rhs );
vec4f vec4f_scale ( const vec4f vec, const float scale );
vec4f vec4f_invert ( const vec4f vec );
vec4f vec4f_store_ret ( mm_vec4f vec );

// Vector routines
//--------------------------------------------------------------------------------------------------
mm_vec4f vec4f_load ( const vec4f* vec );
mm_vec4f vec3f_loadu ( const vec3f* vec );
mm_vec4f mm_vec3f_set ( const float x, const float y, const float z );

void vec4f_store ( vec4f* dst, const mm_vec4f vec );
void vec3f_store ( vec3f* dst, const mm_vec4f vec );

// sse (mmx)
float    mm256_l           ( const __m256 vec, int lane );
mm_vec4f mm_dp             ( const __m128 lhs, const __m128 rhs );
int      mm_vec4f_max_comp ( const mm_vec4f vec );
float    mm_vec4f_comp     ( const mm_vec4f vec, int comp );

// avx/avx256 (ymm)
__m256   mm256_gather_f32  ( const float* base, const uint64_t* addr_block );
void     mm256_scatter_f32 ( float* base, const uint64_t* addr_block, const __m256 vec );
__mmask8 mm256_mask_32     ( uint64_t count, uint64_t idx );
void     mm256_store_mask  ( void* addr, const __m256 vec, const __mmask8 mask );
void     mm256_storeu_mask ( void* addr, const __m256 vec, const __mmask8 mask );
__m256   mm256_add_scale   ( const __m256* vecs, const int n_vecs, const float weight );
__m256   mm256_add_weight  ( const __m256 lhs, const __m256 rhs, const float weight );
uint64_t mm256_comp_i64    ( const __m256i vec, int comp );

__m256i  mm256_swizzle_yzwx ( const __m256i vec );
__m256i  mm256_swizzle_wxyz ( const __m256i vec );

#define mm128_decl_zero(name) __m128 name; _mm_xor_ps(name, name);
#define mm256_decl_zero(name) __m256 name; _mm256_xor_ps(name, name);

// Scalar Routines implementation
//--------------------------------------------------------------------------------------------------
// sets the fpu precision to single (24-bit mantissa)
#if terra_win32 && !defined(_CRT_SECURE_NO_WARNINGS)
    #define _CRT_SECURE_NO_WARNINGS
#endif

terra_inline void fpu_set_precision_single() {
    _controlfp ( _PC_24, MCW_PC );
}

//--------------------------------------------------------------------------------------------------
// sets the fpu precision to double precition (53-bit mantissa)
terra_inline void fpu_set_precision_double() {
    _controlfp ( _PC_53, MCW_PC );
}

//--------------------------------------------------------------------------------------------------
terra_inline uint32_t signf_mask ( float v ) {
    const uint32_t sign_bit_mask = 0x80000000;
    return * ( ( uint32_t* ) &v ) & sign_bit_mask;
}

//--------------------------------------------------------------------------------------------------
terra_inline float xorf ( float _lhs, float _rhs ) {
    uint32_t* lhs = ( uint32_t* ) &_lhs;
    uint32_t* rhs = ( uint32_t* ) &_rhs;
    uint32_t res = ( *lhs ) ^ ( *rhs );
    return * ( float* ) &res;
}

//--------------------------------------------------------------------------------------------------
terra_inline void swap_xorf ( float* _a, float* _b ) {
    uint32_t* a = ( uint32_t* ) _a;
    uint32_t* b = ( uint32_t* ) _b;

    *a ^= *b;
    *b ^= *a;
    *a ^= *b;
}

//--------------------------------------------------------------------------------------------------
terra_inline void swap_xori32 ( int32_t* a, int32_t* b ) {
    *a ^= *b;
    *b ^= *a;
    *a ^= *b;
}

//--------------------------------------------------------------------------------------------------
terra_inline void swap_xori64 ( int64_t* a, int64_t* b ) {
    *a ^= *b;
    *b ^= *a;
    *a ^= *b;
}

//--------------------------------------------------------------------------------------------------
terra_inline vec2f vec2f_set ( float x, float y ) {
    vec2f vec;
    vec.x = x;
    vec.y = y;
    return vec;
}

//--------------------------------------------------------------------------------------------------
terra_inline vec3f vec3f_set ( const float x, const float y, const float z ) {
    vec3f vec;
    vec.x = x;
    vec.y = y;
    vec.z = z;
    return vec;
}

//--------------------------------------------------------------------------------------------------
terra_inline vec3f vec3f_data ( const float* v ) {
    vec3f vec;
    vec.x = v[0];
    vec.y = v[1];
    vec.z = v[2];
    return vec;
}

//--------------------------------------------------------------------------------------------------
terra_inline vec4f vec4f_set ( float x, float y, float z, float w ) {
    vec4f v;
    v.x = x;
    v.y = y;
    v.z = z;
    v.w = w;
    return v;
}

//--------------------------------------------------------------------------------------------------
terra_inline vec4f vec4f_zero() {
    vec4f vec = { 0.f };
    return vec;
}

//--------------------------------------------------------------------------------------------------
terra_inline vec4i32 vec4i32_set ( uint32_t x, uint32_t y, uint32_t z, uint32_t w ) {
    vec4i32 v;
    v.x = x;
    v.y = y;
    v.z = z;
    v.w = w;
    return v;
}

//--------------------------------------------------------------------------------------------------
terra_inline vec3i64 vec3i64_set ( int64_t v0, int64_t v1, int64_t v2 ) {
    vec3i64 vec;
    vec.x = v0;
    vec.y = v1;
    vec.z = v2;
    return vec;
}

//--------------------------------------------------------------------------------------------------
terra_inline int vec4f_max_comp ( const vec4f vec ) {
    if ( vec.x > vec.y ) {
        if ( vec.x > vec.z ) {
            return 0;
        } else {
            return 2;
        }
    } else {
        if ( vec.y > vec.z ) {
            return 1;
        } else {
            return 2;
        }
    }
}

//--------------------------------------------------------------------------------------------------
terra_inline float vec4f_comp ( const vec4f vec, int idx ) {
    return ( ( float* ) &vec ) [idx];
}

//--------------------------------------------------------------------------------------------------
terra_inline vec4f vec4f_add ( const vec4f lhs, const vec4f rhs ) {
    return vec4f_store_ret ( _mm_add_ps ( vec4f_load ( &lhs ), vec4f_load ( &rhs ) ) );
}

//--------------------------------------------------------------------------------------------------
terra_inline vec4f vec4f_sub ( const vec4f lhs, const vec4f rhs ) {
    return vec4f_store_ret ( _mm_sub_ps ( vec4f_load ( &lhs ), vec4f_load ( &rhs ) ) );
}

//--------------------------------------------------------------------------------------------------
terra_inline vec4f vec4f_scale ( const vec4f vec, const float scale ) {
    vec4f ret;
    ret.x = vec.x * scale;
    ret.y = vec.y * scale;
    ret.z = vec.z * scale;
    return ret;
}

//--------------------------------------------------------------------------------------------------
terra_inline vec4f vec4f_invert ( const vec4f vec ) {
    vec4f ret;
    ret.x = 1.f / vec.x;
    ret.y = 1.f / vec.y;
    ret.z = 1.f / vec.z;
    return ret;
}

//--------------------------------------------------------------------------------------------------
terra_inline vec4f vec4f_store_ret ( mm_vec4f vec ) {
    vec4f svec;
    _mm_store_ps ( ( float* ) &svec, vec );
    return svec;
}

// Vector routines implementation
//--------------------------------------------------------------------------------------------------
terra_inline mm_vec4f vec4f_load ( const vec4f* vec ) {
    return _mm_load_ps ( ( const float* ) vec );
}

terra_inline mm_vec4f vec3f_loadu ( const vec3f* vec ) {
    return _mm_set_ps ( 0.f, vec->z, vec->y, vec->x );
}

terra_inline mm_vec4f mm_vec3f_set ( const float x, const float y, const float z ) {
    return _mm_set_ps ( 0.f, z, y, x );
}

//--------------------------------------------------------------------------------------------------
terra_inline mm_vec4f vec3f_load ( const vec3f* vec ) {
    return _mm_set_ps ( vec->x, vec->y, vec->z, 0.f );
}

terra_inline void vec4f_store ( vec4f* dst, const mm_vec4f vec ) {
    _mm_store_ps ( ( float* ) dst, vec );
}

terra_inline void vec3f_store ( vec3f* dst, const mm_vec4f vec ) {
    const float* vecv = ( const float* ) &vec;
    dst->x = vecv[0];
    dst->y = vecv[1];
    dst->z = vecv[2];
}

//--------------------------------------------------------------------------------------------------
terra_inline float mm256_l ( const __m256 vec, int lane ) {
    return _tcast ( float*, &vec ) [lane];
}

//--------------------------------------------------------------------------------------------------
terra_inline __m128 mm_dp ( const __m128 lhs, const __m128 rhs ) {
#if terra_simd_sse42
    return _mm_dp_ps ( lhs, rhs, 0xff );
#else
#error :(
#endif
}

//--------------------------------------------------------------------------------------------------
terra_inline int mm_vec4f_max_comp ( const __m128 vec ) {
    // todo: pls.. max/shuffle
    vec4f vecs;
    vec4f_store ( &vecs, vec );
    return vec4f_max_comp ( vecs );
}

//--------------------------------------------------------------------------------------------------
terra_inline float mm_vec4f_comp ( const mm_vec4f vec, int comp ) {
    vec4f vecs;
    _mm_store_ps ( _tcast ( float*, &vecs ), vec );
    return vec4f_comp ( vecs,  comp );
}

//--------------------------------------------------------------------------------------------------
// 512 byte lanes (avx-512) is required to load 8 64-bit addresses in a single gather operation.
// On avx-512 you can use the _mm512_i64gather_ps which takes 8 64-bit addresses as a __m512i argument
terra_inline __m256 mm256_gather_f32 ( const float* base, const uint64_t* addr_block ) {
    const __m256i addr_lo = _mm256_loadu_si256 ( _tcast ( const __m256i*, addr_block ) + 0 );
    const __m256i addr_hi = _mm256_loadu_si256 ( _tcast ( const __m256i*, addr_block ) + 1 );
    __m128 res_lo = _mm256_i64gather_ps ( base, addr_lo, 4 );
    __m128 res_hi = _mm256_i64gather_ps ( base, addr_hi, 4 );

    __m256 res = _mm256_set1_ps ( 0.f );
    res = _mm256_insertf128_ps ( res, res_lo, 0 );
    res = _mm256_insertf128_ps ( res, res_hi, 1 );
    return res;
}
//--------------------------------------------------------------------------------------------------
// avx2 doesn't have scatter, only >= avx512 :(
// avx512pf also includes prefetch variants for gather and scatter
terra_inline void mm256_scatter_f32 ( float* base, const uint64_t* addr_block, const __m256 vec ) {
    for ( int ilane = 0; ilane < mm_lanes_32; ++ilane ) {
        if ( addr_block[ilane] == mm_addr_mask ) {
            break;
        }

        base[addr_block[ilane]] = mm256_l ( vec, ilane );
    }
}

//--------------------------------------------------------------------------------------------------
// Generates a 32-bit (per lane) mask which is supposed to be & with a load/store result. It sets the
// sign bit of all lines that are active read/write and doesn't set it for masked out lanes.
// todo: remove branch/set ?
#define mm_f32_mask_allow 0x00000000
#define mm_f32_mask_block 0x80000000
terra_inline __mmask8 mm256_mask_32 ( uint64_t idx, uint64_t count ) {
    if ( idx + mm_lanes_32 <= count ) {
        return 0;
    }

    return ( __mmask8 ) ( count - idx );
}

//--------------------------------------------------------------------------------------------------
// todo....
terra_inline void mm256_store_mask ( void* addr, const __m256 vec, const __mmask8 mask ) {
    if ( mask == 0x0 ) {
        _mm256_store_ps ( _tcast ( float*, addr ), vec );
    }

    for ( __mmask8 ireg = 0; ireg < mask; ++ireg ) {
        _tcast ( float*, addr ) [ireg] = _tcast ( float*, &vec ) [ireg];
    }
}

//--------------------------------------------------------------------------------------------------
terra_inline void mm256_storeu_mask ( void* addr, const __m256 vec, const __mmask8 mask ) {
    if ( mask == 0x0 ) {
        _mm256_storeu_ps ( _tcast ( float*, addr ), vec );
    }

    for ( __mmask8 ireg = 0; ireg < mask; ++ireg ) {
        _tcast ( float*, addr ) [ireg] = _tcast ( float*, &vec ) [ireg];
    }
}

//--------------------------------------------------------------------------------------------------
terra_inline __m256 mm256_add_scale ( const __m256* vecs, const int n_vecs, const float weight ) {
    assert_break ( n_vecs );
    __m256 acc = vecs[0];

    for ( int ivec = 1; ivec < n_vecs; ++ivec ) {
        acc = _mm256_add_ps ( acc, vecs[ivec] );
    }

    const __m256 ret = _mm256_mul_ps ( _mm256_set1_ps ( weight ), acc );
    return ret;
}

//--------------------------------------------------------------------------------------------------
terra_inline __m256 mm256_add_weight ( const __m256 lhs, const __m256 rhs, const float weight ) {
    return _mm256_mul_ps ( _mm256_set1_ps ( weight ), _mm256_add_ps ( lhs, rhs ) );
}

//--------------------------------------------------------------------------------------------------
terra_inline uint64_t mm256_comp_i64 ( const __m256i vec, int comp ) {
    return _tcast ( const uint64_t*, &vec ) [comp];
}

//--------------------------------------------------------------------------------------------------
#define mm256_swizzle_yzwx_mask ( mm_l1 ) | ( mm_l2 << 2 ) | ( mm_l3 << 4 ) | ( mm_l0 << 6 )
terra_inline __m256i mm256_swizzle_yzwx ( const __m256i vec ) {
    return _mm256_permute4x64_epi64 ( vec, mm256_swizzle_yzwx_mask );
}

//--------------------------------------------------------------------------------------------------
#define mm256_swizzle_wxyz_mask ( mm_l3 ) | ( mm_l0 << 2 ) | ( mm_l1 << 4 ) | ( mm_l2 << 6 )
terra_inline __m256i  mm256_swizzle_wxyz ( const __m256i vec ) {
    return _mm256_permute4x64_epi64 ( vec, mm256_swizzle_wxyz_mask );
}

#endif