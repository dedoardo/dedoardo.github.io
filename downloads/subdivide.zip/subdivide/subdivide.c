#define terra_dev_debug 0

// libc
#include <stdlib.h>
#include <stdio.h>

#include "code/cpu.h"
#include "code/simd.h"
#include "code/parser.h"
#include "code/geometry.h"

#define addr_in_test "D:/code/subdivide/meshes/cube.obj"
#define addr_out_test "D:/code/subdivide/meshes/cube-final.obj"
#define addr_mesh_build_timings "mesh-build-timings.txt"
#define iterations_default 4

Geometry    shape_in, shape_out; // In/out geometry + adjacency data
Mesh        mesh;                // edge <-> face mappings
const char* time_operator;

void subdivide_time ( const char* addr_in, const char* addr_out, int iterations );

/*
    Call with:
    <in obj address> <iterations> <out obj address>

    Otherwise the test is run on all the meshes in the TEST_SCENE_DIR directory
*/
int main ( int argc, char* argv[] ) {
    // Reading arguments
    const char* addr_in = argc == 4 ? argv[1] : addr_in_test;
    const int iterations = argc == 4 ? atoi ( argv[2] ) : iterations_default;
    const char* addr_out = argc == 4 ? argv[3] : addr_out_test;

    subdivide_time ( addr_in, addr_out, iterations );
    terra_shape_write_obj ( addr_out, &shape_out );
    return EXIT_SUCCESS;
}

#define time_start uint64_t _split0 = cpu_timer_split(); uint64_t _split1 = _split0;
#define time_save(elapsed_ms) { _split1 = cpu_timer_split(); elapsed_ms = cpu_timer_elapsed_ms(_split1 - _split0); swap_xori64(&_split0, &_split1);}

void subdivide_time ( const char* addr_in, const char* addr_out, int iterations ) {
#if 1
    double geometry_read_ms = 0., geometry_write_ms = 0.;
    double mesh_build_ms = 0., mesh_subdiv_ms = 0.;

    cpu_timer_init();
    time_start;
#endif

    assert_break ( terra_shape_read_obj ( addr_in, &shape_in ) );
    time_save(geometry_read_ms);

    // Subdivide
    if ( shape_in.face_primitive == 3 ) {
        mesh_subdiv_iter_loop ( &shape_in, &shape_out, iterations );
    } else if ( shape_in.face_primitive == 4 ) {
        mesh_subdiv_iter_catmull_clark ( &shape_in, &shape_out, iterations );
    } else {
        assert_break ( 0 );
    }
    time_save(mesh_subdiv_ms);

    terra_shape_write_obj ( addr_out, &shape_out );
    time_save(geometry_write_ms);

#if 1

    //FILE* fp = fopen ( addr_mesh_build_timings, "a" );
    FILE* fp = stdout;
    assert_break ( fp );
    fprintf ( fp, "---\n" );
    fprintf ( fp, "filename %s\n", addr_in );
    fprintf ( fp, "geometry-read took %10.5f ms (%.5f secs)\n", geometry_read_ms, geometry_read_ms / 1000 );
    fprintf ( fp, "mesh-subdiv(%lld) took %10.5f ms (%.5f secs)\n", shape_in.face_primitive, mesh_subdiv_ms, mesh_subdiv_ms / 1000 );
    fprintf ( fp, "geometry-write took %10.5f ms (%.5f secs)\n", geometry_write_ms, geometry_write_ms / 1000 );
    fclose ( fp );
#endif
}