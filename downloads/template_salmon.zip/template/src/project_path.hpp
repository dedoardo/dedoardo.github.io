#pragma once

// Please don't change the content of this header

#define PROJECT_SOURCE_DIR "C:/Users/luciano/Documents/template/"
