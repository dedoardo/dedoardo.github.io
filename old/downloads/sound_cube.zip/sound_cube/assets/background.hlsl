Texture2D render_target : register(t0);
SamplerState render_target_sampler : register(s0);

struct VS_OUTPUT
{
	float4 Position : SV_POSITION0;
	float2 TexCoord : TEXCOORD0;
};
cbuffer Data
{
float time;
}

float3 rgb2hsv(float3 c)
{
	float4 K = float4(0.0, -1.0 / 3.0, 2.0 / 3.0, -1.0);
	float4 p = lerp(float4(c.bg, K.wz), float4(c.gb, K.xy), step(c.b, c.g));
	float4 q = lerp(float4(p.xyw, c.r), float4(c.r, p.yzx), step(p.x, c.r));

	float d = q.x - min(q.w, q.y);
	float e = 1.0e-10;
	return float3(abs(q.z + (q.w - q.y) / (6.0 * d + e)), d / (q.x + e), q.x);
}

float3 hsv2rgb(float3 c)
{
	float4 K = float4(1.0, 2.0 / 3.0, 1.0 / 3.0, 3.0);
	float3 p = abs(frac(c.xxx + K.xyz) * 6.0 - K.www);
	return c.z * lerp(K.xxx, saturate(p - K.xxx), c.y);
}

float4 main(VS_OUTPUT input) : SV_TARGET
{
	float4 color = render_target.Sample(render_target_sampler, (input.TexCoord / 2.f) + float2(0.5f, 0.5f));
	float3 hsv = rgb2hsv(color.xyz);
	hsv.x = (time % 360)- 180;
	return float4(hsv2rgb(hsv), 1.f);
}