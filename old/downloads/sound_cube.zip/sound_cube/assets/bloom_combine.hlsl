struct VS_OUTPUT
{
	float4 Position : SV_POSITION0;
	float2 TexCoord : TEXCOORD0;	
};

Texture2D color_texture 		: register(t0);
Texture2D bright_texture 		: register(t1);
SamplerState color_sampler 		: register(s0);

float4 adjust_saturation(float4 color, float saturation)
{
	float grey = dot(color, float3(0.3f, 0.59f, 0.11f));
	return lerp(grey, color, saturation);
}

float4 main(VS_OUTPUT input) : SV_TARGET
{
	float bloom_intensity = 1.f;
	float original_intensity = 1.f;
	float bloom_saturation = 1.f;
	float original_saturation = 1.f;

	float4 bloom_color = bright_texture.Sample(color_sampler, input.TexCoord);
	float4 original_color = color_texture.Sample(color_sampler, input.TexCoord);

	bloom_color = adjust_saturation(bloom_color, bloom_saturation) * bloom_intensity;
	original_color = adjust_saturation(original_color, original_saturation) * original_intensity;

	original_color *= (1 - saturate(bloom_color));

	return bloom_color + original_color;
}