struct VS_OUTPUT
{
	float4 Position : SV_POSITION0;
	float4 Color 	: COLOR0;	
};

cbuffer PerCube
{
	float4 base_color;
};

struct PS_OUT
{
	float4 Color : SV_TARGET0;
};

PS_OUT main(VS_OUTPUT input)
{
	PS_OUT output;
	output.Color = base_color;
	return output;
}