struct VS_OUTPUT
{
	float4 Position : SV_POSITION0;
	float4 Color 	: COLOR0;	
};

struct PS_OUT
{
	float4 Color : SV_TARGET0;
};

cbuffer Alpha
{
	float3 floor_color;
};

// TODO : do color operations here
PS_OUT main(VS_OUTPUT input)
{
	PS_OUT output;
	output.Color = float4(floor_color.xyz, 1.f);
	return output;
}