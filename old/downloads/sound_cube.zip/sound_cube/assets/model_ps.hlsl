struct VS_OUTPUT
{
	float4 Position : SV_POSITION0;
	float4 Color 	: COLOR0;	
};

struct PS_OUT
{
	float4 Color : SV_TARGET0;
};

// TODO : do color operations here
PS_OUT main(VS_OUTPUT input)
{
	PS_OUT output;
	output.Color = input.Color;
	return output;
}