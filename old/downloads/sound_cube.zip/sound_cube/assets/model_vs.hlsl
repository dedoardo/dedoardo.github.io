struct VS_INPUT
{
	float3 Position : POSITION0;
	float3 Color 	: COLOR0;	
};

struct VS_OUTPUT
{
	float4 Position : SV_POSITION0;
	float4 Color 	: COLOR0;	
};

cbuffer PerObject
{
	float4x4 World;
	float4x4 View;
	float4x4 Projection;
};

VS_OUTPUT main(VS_INPUT input)
{
	VS_OUTPUT output;
	output.Position = mul(float4(input.Position, 1.f), World);
	output.Position = mul(output.Position, View);
	output.Position = mul(output.Position, Projection);
	output.Color = float4(input.Color, 1.f);
	return output;
}