struct VS_OUTPUT
{
	float4 Position : SV_POSITION0;
	float2 TexCoord : TEXCOORD0;	
};

Texture2D color_texture 		: register(t0);
SamplerState color_sampler 		: register(s0);

float4 main(VS_OUTPUT input) : SV_TARGET
{
	float4 color = color_texture.Sample(color_sampler, input.TexCoord);
	return saturate((color - 0.3f) / (1 - 0.3f)); // Extract bright areas	
}