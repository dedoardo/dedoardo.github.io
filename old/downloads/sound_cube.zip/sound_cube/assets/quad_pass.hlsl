struct VS_OUTPUT
{
	float4 Position : SV_POSITION0;
	float2 TexCoord : TEXCOORD0;	
};

Texture2D color_texture 		: register(t0);
SamplerState color_sampler 		: register(s0);

float4 main(VS_OUTPUT input) : SV_TARGET
{
	return color_texture.Sample(color_sampler, input.TexCoord);
//	return float4(1.f, 1.f, 1.f, 1.f);
}